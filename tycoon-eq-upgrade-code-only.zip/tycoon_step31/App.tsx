import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useSpring, useReducedMotion } from 'framer-motion';
import { GameState, AssetType, MarketItem, Lifestyle, Character, Asset, SideHustle, EducationOption, Liability, PlayerConfig, MonthlyActionId } from './types';
import { INITIAL_GAME_STATE, CHARACTERS, DIFFICULTY_SETTINGS, CAREER_PATHS, LIFESTYLE_OPTS, MARKET_ITEMS, EDUCATION_OPTIONS, SIDE_HUSTLES, MORTGAGE_OPTIONS, AI_CAREER_IMPACT, FINANCIAL_FREEDOM_TARGET_MULTIPLIER, getFinancialFreedomTarget, INITIAL_QUEST_STATE, getQuestById } from './constants';
import { processTurn, calculateMonthlyCashFlowEstimate, applyScenarioOutcome, calculateNetWorth, createMortgage, getEducationSalaryMultiplier, applyMonthlyAction, getQuestProgress, updateQuests, claimQuestReward } from './services/gameLogic';
import { playMoneyGain, playMoneyLoss, playClick, playPurchase, playSell, playAchievement, playLevelUp, playVictory, playWarning, playTick, playNotification, playError, setMuted } from './services/audioService';
import { saveAdultGame, loadAdultGame, getSaveSummaries, deleteSaveSlot, renameSaveSlot, SaveSlotId, SaveSummary } from './services/storageService';
import confetti from 'canvas-confetti';
import { Area, AreaChart, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

import UpgradeEQTab from './components/UpgradeEQTab';

import { 
  Play, Pause, FastForward, TrendingUp, DollarSign, Home, Briefcase, 
  GraduationCap, Heart, PiggyBank, LineChart, AlertTriangle, CheckCircle,
  X, Clock, Wallet, ArrowUpRight, ArrowDownRight, Sparkles, Volume2, VolumeX, 
  Bot, CreditCard, Coffee, Banknote, Plus, Minus, Save as SaveIcon, FolderOpen as FolderOpenIcon, Trash2,
  Users, BookOpen, Zap, HeartPulse, Trophy, Info, Settings
} from 'lucide-react';

// ============================================
// UTILITY FUNCTIONS
// ============================================
const formatMoney = (val: number): string => {
  if (Math.abs(val) >= 1000000) return `$${(val / 1000000).toFixed(2)}M`;
  if (Math.abs(val) >= 1000) return `$${(val / 1000).toFixed(1)}K`;
  return `$${Math.round(val).toLocaleString()}`;
};

const formatMoneyFull = (val: number): string => {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
};

const formatPercent = (val: number): string => `${(val * 100).toFixed(1)}%`;

const getAssetIcon = (type: AssetType) => {
  const icons: Record<AssetType, string> = {
    [AssetType.STOCK]: '📈', [AssetType.INDEX_FUND]: '📊', [AssetType.BOND]: '📜',
    [AssetType.REAL_ESTATE]: '🏠', [AssetType.BUSINESS]: '🏪', [AssetType.CRYPTO]: '₿',
    [AssetType.COMMODITY]: '🥇', [AssetType.SAVINGS]: '🏦'
  };
  return icons[type] || '💰';
};

type TurnPreviewLine = { label: string; value: number };

type TurnPreviewData = {
  nextMonth: number;
  nextYear: number;
  monthOfYear: number;
  incomeLines: TurnPreviewLine[];
  expenseLines: TurnPreviewLine[];
  income: number;
  expenses: number;
  netChange: number;
  projectedEndCash: number;
  shortfall: number;
  warningLevel: 'SAFE' | 'LOW_BUFFER' | 'SHORTFALL';
};

type ConfirmDialogConfig = {
  title: string;
  description: string;
  details?: { label: string; value: string }[];
  confirmLabel: string;
  cancelLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel?: () => void;
};

type AccessibilityPrefs = {
  largeText: boolean;
  highContrast: boolean;
};

// ============================================
// COACH UI (Step 12)
// ============================================
type CoachTarget =
  | 'monthly-actions'
  | 'lifestyle-grid'
  | 'assets-sell'
  | 'sidehustles-list'
  | 'bank-loans';

type CoachHintData = {
  id: string;
  tabId: string;
  title: string;
  message: string;
  target?: CoachTarget;
  allowReopenPreview?: boolean;
};

const getRiskColor = (risk: string) => {
  const colors: Record<string, string> = {
    'VERY_LOW': 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    'LOW': 'bg-green-500/20 text-green-400 border-green-500/30',
    'MEDIUM': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    'HIGH': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    'VERY_HIGH': 'bg-red-500/20 text-red-400 border-red-500/30',
    'EXTREME': 'bg-purple-500/20 text-purple-400 border-purple-500/30'
  };
  return colors[risk] || 'bg-slate-500/20 text-slate-400';
};

const getAIRiskColor = (risk: string) => {
  const colors: Record<string, string> = {
    'LOW': 'text-emerald-400', 'MEDIUM': 'text-amber-400',
    'HIGH': 'text-orange-400', 'CRITICAL': 'text-red-400'
  };
  return colors[risk] || 'text-slate-400';
};

// ============================================
// LOAN OPTIONS
// ============================================
const LOAN_OPTIONS = [
  { id: 'emergency', name: 'Emergency Loan', amount: 2000, rate: 0.15, term: 12, description: 'Quick cash for emergencies' },
  { id: 'personal_small', name: 'Small Personal Loan', amount: 5000, rate: 0.12, term: 24, description: 'For minor expenses' },
  { id: 'personal_medium', name: 'Medium Personal Loan', amount: 10000, rate: 0.10, term: 36, description: 'For larger purchases' },
  { id: 'personal_large', name: 'Large Personal Loan', amount: 25000, rate: 0.09, term: 48, description: 'Major life expenses' },
  { id: 'business', name: 'Business Loan', amount: 50000, rate: 0.08, term: 60, description: 'Start or expand a business' },
];

// ============================================
// TAB INTRO VIDEOS (config-driven onboarding popups)
// ============================================
// NOTE: bumped to v2 so existing installs that marked v1 as seen will see the new standardized
// tab-intro experience at least once.
const INVEST_INTRO_VIDEO_STORAGE_KEY = 'tycoon_seen_invest_intro_video_v2';
const INVEST_INTRO_VIDEO_SRC = '/videos/investment-types-explained.mp4';

const PORTFOLIO_INTRO_VIDEO_STORAGE_KEY = 'tycoon_seen_overview_intro_video_v1';
const PORTFOLIO_INTRO_VIDEO_SRC = '/videos/master-your-game-portfolio.mp4';
const PORTFOLIO_INTRO_VIDEO_POSTER = '/images/financial-planner-poster-16x9.jpg';

const CAREER_INTRO_VIDEO_STORAGE_KEY = 'tycoon_seen_career_intro_video_v1';
const CAREER_INTRO_VIDEO_SRC = '/videos/climb-your-career.mp4';

const BANK_INTRO_VIDEO_STORAGE_KEY = 'tycoon_seen_bank_intro_video_v1';
const BANK_INTRO_VIDEO_SRC = '/videos/bank-tab-guide-tycoon.mp4';


const SIDE_HUSTLE_INTRO_VIDEO_STORAGE_KEY = 'tycoon_seen_side_hustle_intro_video_v1';
const SIDE_HUSTLE_INTRO_VIDEO_SRC = '/videos/side-hustle-updated-tycoon.mp4';

// Education tab intro video
// NOTE: Use a new versioned key so players who previously saw older Education videos
// (or had an Education flag set from earlier builds) will still see this updated onboarding once.
const EDUCATION_INTRO_VIDEO_STORAGE_KEY = 'tycoon_seen_education_intro_video_v4';
const EDUCATION_INTRO_VIDEO_SRC = '/videos/education-tab-updated-tycoon.mp4';

// Upgrade EQ tab intro video
const EQ_INTRO_VIDEO_STORAGE_KEY = 'tycoon_seen_eq_upgrade_intro_video_v1';
const EQ_INTRO_VIDEO_SRC = '/videos/tycoon-eq-upgrade.mp4';

type TabIntroVideoConfig = {
  storageKey: string;
  src: string;
  poster?: string;
  title: string;
  description: string;
  icon?: React.ReactNode;
  continueLabel?: string;
  continueToTab?: string;
};

type MarketSpecialAction =
  | {
      type: 'BUY_DISCOUNT';
      budget: number;
      discount: number; // e.g. 0.3 = 30% off
      title: string;
      description: string;
      allowedTypes?: AssetType[];
    }
  | {
      type: 'PANIC_SELL';
      discount: number; // e.g. 0.3 = 30% fire-sale haircut
      title: string;
      description: string;
    };

// NOTE: Add future tab videos by extending this config (tab id -> src/poster/storage key) by extending this config (tab id -> src/poster/storage key)
const TAB_INTRO_VIDEO_CONFIG: Record<string, TabIntroVideoConfig> = {
  invest: {
    storageKey: INVEST_INTRO_VIDEO_STORAGE_KEY,
    src: INVEST_INTRO_VIDEO_SRC,
    title: 'Investment Types Explained',
    description: 'A quick explainer to help you pick smarter investments in the game.',
    icon: <BookOpen size={18} className="text-emerald-300" />,
    continueLabel: 'Continue to Invest'
  },
  assets: {
    storageKey: PORTFOLIO_INTRO_VIDEO_STORAGE_KEY,
    src: PORTFOLIO_INTRO_VIDEO_SRC,
    poster: PORTFOLIO_INTRO_VIDEO_POSTER,
    title: 'Master Your Game: Portfolio',
    description: 'A quick walkthrough so you know exactly what to track — and what to do next.',
    icon: <Wallet size={18} className="text-emerald-300" />,
    continueLabel: 'Continue to Overview',
    continueToTab: 'overview'
  },
  career: {
    storageKey: CAREER_INTRO_VIDEO_STORAGE_KEY,
    src: CAREER_INTRO_VIDEO_SRC,
    title: 'Climb Your Career',
    description: 'A quick walkthrough to help you choose a career path and grow your income.',
    icon: <Briefcase size={18} className="text-emerald-300" />,
    continueLabel: 'Continue to Career'
  },
  bank: {
    storageKey: BANK_INTRO_VIDEO_STORAGE_KEY,
    src: BANK_INTRO_VIDEO_SRC,
    title: 'Bank Tab Guide',
    description: 'A quick walkthrough of loans, repayments, and how to keep your cashflow healthy.',
    icon: <PiggyBank size={18} className="text-emerald-300" />,
    continueLabel: 'Continue to Bank'
  },
  education: {
    storageKey: EDUCATION_INTRO_VIDEO_STORAGE_KEY,
    src: EDUCATION_INTRO_VIDEO_SRC,
    title: 'Education Tab Guide',
    description: 'A quick walkthrough to help you upgrade your skills, increase income potential, and plan your next steps.',
    icon: <GraduationCap size={18} className="text-emerald-300" />,
    continueLabel: 'Continue to Education'
  },
  sidehustle: {
    storageKey: SIDE_HUSTLE_INTRO_VIDEO_STORAGE_KEY,
    src: SIDE_HUSTLE_INTRO_VIDEO_SRC,
    title: 'Side Hustles Tab Guide',
    description: 'A quick walkthrough to help you start side hustles and boost your monthly cashflow.',
    icon: <Coffee size={18} className="text-emerald-300" />,
    continueLabel: 'Continue to Side Hustles'
  },
  eq: {
    storageKey: EQ_INTRO_VIDEO_STORAGE_KEY,
    src: EQ_INTRO_VIDEO_SRC,
    title: 'Upgrade your EQ',
    description: 'Learn the people-skills that boost your career growth and unlock rewards (100% required).',
    icon: <HeartPulse size={18} className="text-emerald-300" />,
    continueLabel: 'Continue to Upgrade EQ'
  }
};

// Calculate loan payment
const calculateLoanPayment = (principal: number, annualRate: number, termMonths: number): number => {
  const monthlyRate = annualRate / 12;
  if (monthlyRate === 0) return principal / termMonths;
  return Math.round(principal * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1));
};

// ============================================
// FLOATING NUMBER COMPONENT
// ============================================
const FloatingNumber: React.FC<{ value: number; onComplete: () => void }> = ({ value, onComplete }) => {
  useEffect(() => { const t = setTimeout(onComplete, 1500); return () => clearTimeout(t); }, [onComplete]);
  return (
    <motion.div initial={{ opacity: 1, y: 0 }} animate={{ opacity: 0, y: -80 }} transition={{ duration: 1.5 }}
      className={`fixed z-50 font-bold text-3xl pointer-events-none left-1/2 top-1/4 -translate-x-1/2 ${value >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
      {value >= 0 ? '+' : ''}{formatMoney(value)}
    </motion.div>
  );
};

// ============================================
// MAIN APP COMPONENT
// ============================================
interface AppProps {
  onBackToMenu?: () => void;
  initialGameState?: GameState;
  playerConfig?: PlayerConfig;
  isMultiplayer?: boolean;
  onTurnComplete?: (newState: GameState) => void;
}

const App: React.FC<AppProps> = ({ onBackToMenu, initialGameState, playerConfig, isMultiplayer, onTurnComplete }) => {
  const isResumingFromSave = !isMultiplayer && !!initialGameState && !!initialGameState.character;
  const [gameStarted, setGameStarted] = useState(isMultiplayer ? true : isResumingFromSave);
  const [gameState, setGameState] = useState<GameState>(initialGameState || INITIAL_GAME_STATE);
  const [multiplayerTurnsTaken, setMultiplayerTurnsTaken] = useState(0);
  const MULTIPLAYER_TURNS_PER_ROUND = 3; // Each player takes 3 months per turn
  const [isProcessing, setIsProcessing] = useState(false);
  const [autoPlaySpeed, setAutoPlaySpeed] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [investmentFilter, setInvestmentFilter] = useState<string>('ALL');

  // Batch buying (securities): build a small 'cart' and confirm once
  const [batchBuyMode, setBatchBuyMode] = useState(false);
  const [batchBuyQuantities, setBatchBuyQuantities] = useState<Record<string, number>>({});

  const [floatingNumbers, setFloatingNumbers] = useState<{ id: string; value: number }[]>([]);
  const [notification, setNotification] = useState<{ title: string; message: string; type: string } | null>(null);
  const [monthlyReport, setMonthlyReport] = useState<any>(null);
  const [showCharacterSelect, setShowCharacterSelect] = useState(false);
  const [selectedDifficulty, setSelectedDifficulty] = useState<keyof typeof DIFFICULTY_SETTINGS>('NORMAL');
  const [soundEnabled, setSoundEnabled] = useState(initialGameState?.soundEnabled ?? true);
  const [showMortgageModal, setShowMortgageModal] = useState<MarketItem | null>(null);
  const [selectedMortgage, setSelectedMortgage] = useState<string>('');

  // ============================================
  // NEXT MONTH PREVIEW (Step 10)
  // ============================================
  const [showTurnPreview, setShowTurnPreview] = useState(false);
  const [turnPreview, setTurnPreview] = useState<TurnPreviewData | null>(null);
  const [skipTurnPreview, setSkipTurnPreview] = useState<boolean>(() => {
    if (isMultiplayer) return true;
    try {
      return localStorage.getItem('tycoon_skip_turn_preview') === '1';
    } catch {
      return false;
    }
  });

  // ============================================
  // CONFIRMATION PROMPTS (prevent costly mis-clicks)
  // ============================================
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialogConfig | null>(null);

  // Tooltips (tap/click) for stats explanations
  const [openTooltipId, setOpenTooltipId] = useState<string | null>(null);

  // Special market event flows (Buy the Dip / Panic Sell)
  const [marketSpecialAction, setMarketSpecialAction] = useState<MarketSpecialAction | null>(null);
  const [discountBuyItemId, setDiscountBuyItemId] = useState<string | null>(null);
  const [discountBuyQuantity, setDiscountBuyQuantity] = useState<number>(1);
  const [panicSellSelection, setPanicSellSelection] = useState<Record<string, boolean>>({});

  // ============================================
  // ACCESSIBILITY (larger text, higher contrast)
  // ============================================
  const [showAccessibility, setShowAccessibility] = useState(false);
  const [accessibilityPrefs, setAccessibilityPrefs] = useState<AccessibilityPrefs>(() => {
    try {
      const raw = localStorage.getItem('tycoon_accessibility_v1');
      if (raw) return { largeText: false, highContrast: false, ...JSON.parse(raw) } as AccessibilityPrefs;
    } catch {
      // ignore
    }
    return { largeText: false, highContrast: false };
  });

  // ============================================
  // COACH HINTS + HIGHLIGHTS (Step 12)
  // ============================================
  const [coachHint, setCoachHint] = useState<CoachHintData | null>(null);
  const coachTimeoutRef = useRef<number | null>(null);

  // After a "Quick Fix" jump, offer a convenient "Re-open Preview" pill for a short time.
  const [showReopenPreviewPill, setShowReopenPreviewPill] = useState(false);
  const reopenPreviewTimeoutRef = useRef<number | null>(null);

  // Coach focus refs (used to scroll + highlight the exact spot)
  const coachMonthlyActionsRef = useRef<HTMLDivElement | null>(null);
  const coachLifestyleGridRef = useRef<HTMLDivElement | null>(null);
  const coachAssetsSellRef = useRef<HTMLDivElement | null>(null);
  const coachSideHustlesRef = useRef<HTMLDivElement | null>(null);
  const coachBankLoansRef = useRef<HTMLDivElement | null>(null);
  // ============================================
  // TAB INTRO VIDEOS (config-driven onboarding popups)
  // - Shows ONLY the first time a user opens a tab (per-device via localStorage)
  // - "Show later" closes without saving (shows again next time they open the tab)
  // - "Don't show again" / "Continue" saves a per-tab localStorage flag
  // ============================================
  const [introVideoTabId, setIntroVideoTabId] = useState<string | null>(null);
  const [introVideoMuted, setIntroVideoMuted] = useState(true);
  const [introVideoIsPlaying, setIntroVideoIsPlaying] = useState(false);
  const [introVideoHasStarted, setIntroVideoHasStarted] = useState(false);
  const [introVideoPlaybackError, setIntroVideoPlaybackError] = useState<string | null>(null);
  const [introVideoDismissedThisVisit, setIntroVideoDismissedThisVisit] = useState<Record<string, boolean>>({});
  const [introVideoAutoplayOnOpen, setIntroVideoAutoplayOnOpen] = useState(false);
  const [minimizedTabVideos, setMinimizedTabVideos] = useState<Record<string, boolean>>({});
  const introVideoRef = useRef<HTMLVideoElement | null>(null);
  const prevActiveTabRef = useRef<string>(activeTab);

  // Event image enhancements
  const reduceMotion = useReducedMotion();
  const scenarioImageContainerRef = useRef<HTMLDivElement | null>(null);
  const scenarioImageX = useMotionValue(0);
  const scenarioImageY = useMotionValue(0);
  const scenarioImageXSpring = useSpring(scenarioImageX, { stiffness: 160, damping: 22, mass: 0.3 });
  const scenarioImageYSpring = useSpring(scenarioImageY, { stiffness: 160, damping: 22, mass: 0.3 });
  const [imageLightbox, setImageLightbox] = useState<{ src: string; alt: string } | null>(null);

  // Initialize audio mute state from saved preference
  useEffect(() => {
    setMuted(!soundEnabled);
  }, [soundEnabled]);

  // Persist accessibility preferences
  useEffect(() => {
    try {
      localStorage.setItem('tycoon_accessibility_v1', JSON.stringify(accessibilityPrefs));
    } catch {
      // ignore
    }
  }, [accessibilityPrefs]);

  // Apply accessibility classes (root-level so Tailwind rem-based sizes scale)
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('tycoon-text-lg', !!accessibilityPrefs.largeText);
    root.classList.toggle('tycoon-high-contrast', !!accessibilityPrefs.highContrast);
  }, [accessibilityPrefs.largeText, accessibilityPrefs.highContrast]);

  // Persist Next Month preview preference
  useEffect(() => {
    if (isMultiplayer) return;
    try {
      localStorage.setItem('tycoon_skip_turn_preview', skipTurnPreview ? '1' : '0');
    } catch {
      // ignore
    }
  }, [skipTurnPreview, isMultiplayer]);

  // ============================================
  // COACH HINTS (Step 12)
  // ============================================
  const offerReopenPreview = useCallback(() => {
    setShowReopenPreviewPill(true);
    if (reopenPreviewTimeoutRef.current) {
      window.clearTimeout(reopenPreviewTimeoutRef.current);
    }
    reopenPreviewTimeoutRef.current = window.setTimeout(() => {
      setShowReopenPreviewPill(false);
      reopenPreviewTimeoutRef.current = null;
    }, 25000);
  }, []);

  const triggerCoachHint = useCallback((hint: Omit<CoachHintData, 'id'>) => {
    const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    setCoachHint({ id, ...hint });
    if (coachTimeoutRef.current) {
      window.clearTimeout(coachTimeoutRef.current);
    }
    coachTimeoutRef.current = window.setTimeout(() => {
      setCoachHint(null);
      coachTimeoutRef.current = null;
    }, 5000);

    if (hint.allowReopenPreview) {
      offerReopenPreview();
    }
  }, [offerReopenPreview]);

  const coachHighlight = useCallback((target: CoachTarget) => {
    const active = !!coachHint && coachHint.tabId === activeTab && coachHint.target === target;
    return active
      ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-slate-900 shadow-[0_0_0_4px_rgba(16,185,129,0.12)] animate-pulse'
      : '';
  }, [activeTab, coachHint]);

  // Scroll the exact focused UI section into view when a coach hint lands.
  useEffect(() => {
    if (!coachHint?.target) return;
    if (coachHint.tabId !== activeTab) return;

    const behavior: ScrollBehavior = reduceMotion ? 'auto' : 'smooth';
    const opts: ScrollIntoViewOptions = { behavior, block: 'center' };

    const getRef = (): React.RefObject<HTMLDivElement> | null => {
      switch (coachHint.target) {
        case 'monthly-actions':
          return coachMonthlyActionsRef;
        case 'lifestyle-grid':
          return coachLifestyleGridRef;
        case 'assets-sell':
          return coachAssetsSellRef;
        case 'sidehustles-list':
          return coachSideHustlesRef;
        case 'bank-loans':
          return coachBankLoansRef;
        default:
          return null;
      }
    };

    const r = getRef();
    if (r?.current) {
      try {
        r.current.scrollIntoView(opts);
      } catch {
        // ignore
      }
    }
  }, [activeTab, coachHint?.id, coachHint?.tabId, coachHint?.target, reduceMotion]);

  // Cleanup timers
  useEffect(() => {
    return () => {
      if (coachTimeoutRef.current) window.clearTimeout(coachTimeoutRef.current);
      if (reopenPreviewTimeoutRef.current) window.clearTimeout(reopenPreviewTimeoutRef.current);
    };
  }, []);

  // If a preview is opened, hide the "Re-open Preview" pill.
  useEffect(() => {
    if (showTurnPreview) {
      setShowReopenPreviewPill(false);
    }
  }, [showTurnPreview]);

  // ============================================
  // TAB INTRO VIDEOS (config-driven onboarding popups)
  // ============================================
  const activeIntroVideoConfig = useMemo(() => {
    if (!introVideoTabId) return null;
    return TAB_INTRO_VIDEO_CONFIG[introVideoTabId] || null;
  }, [introVideoTabId]);

  const markIntroVideoAsSeen = useCallback((tabId: string) => {
    const cfg = TAB_INTRO_VIDEO_CONFIG[tabId];
    if (!cfg) return;
    try {
      localStorage.setItem(cfg.storageKey, '1');
    } catch {
      // ignore
    }
  }, []);

  const openIntroVideoModal = useCallback((tabId: string, opts?: { autoplay?: boolean }) => {
    const cfg = TAB_INTRO_VIDEO_CONFIG[tabId];
    if (!cfg) return;

    setIntroVideoMuted(true);
    setIntroVideoIsPlaying(false);
    setIntroVideoHasStarted(false);
    setIntroVideoPlaybackError(null);
    setIntroVideoAutoplayOnOpen(!!opts?.autoplay);

    // If the tab has a minimized "replay" panel showing, hide it while the modal is open.
    setMinimizedTabVideos((prev) => ({ ...prev, [tabId]: false }));

    setIntroVideoTabId(tabId);
  }, []);

  // Close behavior rule:
  // - Only clicking "Show later" should allow the popup to appear again next time.
  // - Any other dismissal (X / backdrop / Escape / Continue / Don't show again)
  //   should permanently mark the intro as seen.
  const closeIntroVideoModal = useCallback((opts?: { remember?: boolean }) => {
    const tabId = introVideoTabId;
    if (!tabId) return;

    const remember = opts?.remember !== undefined ? opts.remember : true;
    if (remember) markIntroVideoAsSeen(tabId);

    // Prevent immediate re-open while the user remains on this tab.
    setIntroVideoDismissedThisVisit((prev) => ({ ...prev, [tabId]: true }));

    setIntroVideoAutoplayOnOpen(false);

    setIntroVideoTabId(null);

    const vid = introVideoRef.current;
    if (vid) {
      try {
        vid.pause();
        vid.currentTime = 0;
      } catch {
        // ignore
      }
    }

    setIntroVideoIsPlaying(false);
    setIntroVideoHasStarted(false);
    setIntroVideoPlaybackError(null);
  }, [introVideoTabId, markIntroVideoAsSeen]);

  const requestIntroVideoPlayback = useCallback(async () => {
    const vid = introVideoRef.current;
    if (!vid) return;

    setIntroVideoPlaybackError(null);

    try {
      // If we're paused because we've reached the end, restart before playing.
      const nearEnd = Number.isFinite(vid.duration) && vid.duration > 0
        ? vid.currentTime >= Math.max(0, vid.duration - 0.05)
        : false;

      if (vid.ended || nearEnd) {
        try {
          vid.currentTime = 0;
        } catch {
          // ignore
        }
      }

      // If the user clicks Play, automatically unmute (applies to all tab intro videos).
      try {
        vid.muted = false;
      } catch {
        // ignore
      }
      setIntroVideoMuted(false);

      const p = vid.play();
      // Some browsers return undefined; some return a Promise
      if (p && typeof (p as Promise<void>).then === 'function') {
        await (p as Promise<void>);
      }
    } catch (err: any) {
      const name = err?.name ? String(err.name) : '';
      const msg = err?.message ? String(err.message) : '';
      const pretty = name && msg ? `${name}: ${msg}` : name || msg || 'Unable to start playback.';
      setIntroVideoPlaybackError(pretty);
      setIntroVideoIsPlaying(false);
    }
  }, []);

  const tryEnterIntroVideoFullscreen = useCallback((vid: HTMLVideoElement | null) => {
    if (!vid) return;
    try {
      // Only force fullscreen on small screens (mobile/tablet).
      const isSmall = typeof window !== 'undefined'
        && typeof window.matchMedia === 'function'
        && window.matchMedia('(max-width: 768px)').matches;

      if (!isSmall) return;

      // Avoid repeated fullscreen requests if already fullscreen.
      if (typeof document !== 'undefined' && (document as any).fullscreenElement) return;

      const anyVid = vid as any;

      // iOS Safari supports this on <video> elements.
      if (typeof anyVid.webkitEnterFullscreen === 'function') {
        anyVid.webkitEnterFullscreen();
        return;
      }

      // Standard Fullscreen API
      if (typeof vid.requestFullscreen === 'function') {
        const p = vid.requestFullscreen();
        if (p && typeof (p as Promise<void>).catch === 'function') {
          (p as Promise<void>).catch(() => {});
        }
        return;
      }

      // Older WebKit fallback
      if (typeof anyVid.webkitRequestFullscreen === 'function') {
        anyVid.webkitRequestFullscreen();
      }
    } catch {
      // ignore
    }
  }, []);

  // When the user explicitly clicks "Watch Video", we attempt to autoplay
  // (this is considered a user gesture in most browsers).
  useEffect(() => {
    if (!introVideoTabId) return;
    if (!introVideoAutoplayOnOpen) return;
    const vid = introVideoRef.current;
    if (!vid) return;

    let cancelled = false;
    const tryPlay = () => {
      if (cancelled) return;
      void requestIntroVideoPlayback();
      setIntroVideoAutoplayOnOpen(false);
    };

    // If the video is already ready, try immediately on next tick.
    if (vid.readyState >= 2) {
      const t = window.setTimeout(tryPlay, 0);
      return () => {
        cancelled = true;
        window.clearTimeout(t);
      };
    }

    vid.addEventListener('canplay', tryPlay, { once: true });
    return () => {
      cancelled = true;
      vid.removeEventListener('canplay', tryPlay);
    };
  }, [introVideoAutoplayOnOpen, introVideoTabId, requestIntroVideoPlayback]);

  const toggleIntroVideoPlayback = useCallback(() => {
    const vid = introVideoRef.current;
    if (!vid) return;
    try {
      if (vid.paused) {
        tryEnterIntroVideoFullscreen(vid);
        void requestIntroVideoPlayback();
      } else {
        vid.pause();
      }
    } catch {
      // ignore
    }
  }, [requestIntroVideoPlayback, tryEnterIntroVideoFullscreen]);

  // Reset "dismissed this visit" after leaving a tab so "Show later" works as intended.
  useEffect(() => {
    const prev = prevActiveTabRef.current;
    if (prev !== activeTab) {
      setIntroVideoDismissedThisVisit((m) => {
        if (!m[prev]) return m;
        const next = { ...m };
        delete next[prev];
        return next;
      });
      prevActiveTabRef.current = activeTab;
    }
  }, [activeTab]);

  // Open the intro video when the user opens a tab (first time only).
  useEffect(() => {
    if (!gameStarted) return;

    const cfg = TAB_INTRO_VIDEO_CONFIG[activeTab];
    if (!cfg) return;

    if (gameState.pendingScenario || isProcessing || showTurnPreview) return;
    if (introVideoTabId) return;
    if (introVideoDismissedThisVisit[activeTab]) return;

    let seen = false;
    try {
      seen = localStorage.getItem(cfg.storageKey) === '1';
    } catch {
      seen = false;
    }
    if (seen) return;

    // Auto-triggered intro videos do NOT autoplay.
    openIntroVideoModal(activeTab, { autoplay: false });
  }, [
    activeTab,
    gameStarted,
    gameState.pendingScenario,
    isProcessing,
    showTurnPreview,
    introVideoTabId,
    introVideoDismissedThisVisit,
    openIntroVideoModal
  ]);

  // Close Intro video on Escape (counts as "seen" unless the user explicitly chose "Show later")
  useEffect(() => {
    if (!introVideoTabId) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeIntroVideoModal();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [closeIntroVideoModal, introVideoTabId]);

  // Close lightbox on Escape
  useEffect(() => {
    if (!imageLightbox) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setImageLightbox(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [imageLightbox]);

  // If the scenario modal closes, ensure any open lightbox also closes
  useEffect(() => {
    if (!gameState.pendingScenario && imageLightbox) {
      setImageLightbox(null);
      scenarioImageX.set(0);
      scenarioImageY.set(0);
    }
  }, [gameState.pendingScenario, imageLightbox, scenarioImageX, scenarioImageY]);

  const openImageLightbox = useCallback((src: string, alt: string) => {
    setImageLightbox({ src, alt });
  }, []);

  const closeImageLightbox = useCallback(() => {
    setImageLightbox(null);
  }, []);

  const handleScenarioImagePointerMove = useCallback((e: React.PointerEvent) => {
    if (reduceMotion) return;
    // Keep the effect subtle and avoid odd movement on touch devices
    if (e.pointerType && e.pointerType !== 'mouse') return;
    const el = scenarioImageContainerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const relX = (e.clientX - rect.left) / rect.width;
    const relY = (e.clientY - rect.top) / rect.height;
    // Centered offsets, clamped to keep motion subtle
    const offsetX = Math.max(-0.5, Math.min(0.5, relX - 0.5)) * 18; // px
    const offsetY = Math.max(-0.5, Math.min(0.5, relY - 0.5)) * 12; // px
    scenarioImageX.set(offsetX);
    scenarioImageY.set(offsetY);
  }, [reduceMotion, scenarioImageX, scenarioImageY]);

  const resetScenarioImageParallax = useCallback(() => {
    scenarioImageX.set(0);
    scenarioImageY.set(0);
  }, [scenarioImageX, scenarioImageY]);

  // Save / Load
  const SAVE_SLOTS: SaveSlotId[] = ['autosave', 'slot1', 'slot2', 'slot3'];
  const [showSaveManager, setShowSaveManager] = useState(false);
  const [saveSummaries, setSaveSummaries] = useState<SaveSummary[]>([]);

  
  // Tutorial state - track which tips have been shown
  const [showTutorial, setShowTutorial] = useState(true);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [tutorialDismissed, setTutorialDismissed] = useState(false);
  
  // Tutorial tips content
  const tutorialTips = [
    { 
      title: '👋 Welcome to Tycoon!', 
      message: `Your goal: Build enough passive income to cover ${Math.round(FINANCIAL_FREEDOM_TARGET_MULTIPLIER * 100)}% of your expenses. Click "Next Month" to advance time and watch your finances grow!`,
      highlight: 'next-month'
    },
    {
      title: '💰 Track Your Progress',
      message: 'The Overview tab shows your net worth, cash flow, and important stats. Watch your passive income grow!',
      highlight: 'overview'
    },
    {
      title: '📈 Invest to Build Wealth',
      message: 'Go to the Invest tab to buy stocks, real estate, and businesses. These generate passive income!',
      highlight: 'invest'
    },
    {
      title: '💼 Career & Education',
      message: 'Boost your salary through education and side hustles. Higher income = more to invest!',
      highlight: 'career'
    },
    {
      title: '❤️ Watch Your Health!',
      message: 'Check the Lifestyle tab for health, stress, and energy. Low health can trigger expensive medical emergencies!',
      highlight: 'lifestyle'
    },
    {
      title: '🧠 Financial IQ',
      message: 'Increase Financial IQ by making smart investment decisions and surviving market events. Higher IQ = better negotiation outcomes!',
      highlight: 'stats'
    }
  ];

  // ============================================
  // DERIVED VALUES
  // ============================================
  const netWorth = useMemo(() => calculateNetWorth(gameState), [gameState]);
  // IMPORTANT: Use the deterministic cash flow estimate for UI so UI renders don't consume randomness.
  const cashFlow = useMemo(() => calculateMonthlyCashFlowEstimate(gameState), [gameState]);
  const freedomTarget = useMemo(() => getFinancialFreedomTarget(cashFlow.expenses), [cashFlow.expenses]);
  const winProgress = useMemo(() => {
    return freedomTarget <= 0 ? 0 : Math.min(100, (cashFlow.passive / freedomTarget) * 100);
  }, [cashFlow.passive, freedomTarget]);

  const filteredInvestments = useMemo(() => {
    if (investmentFilter === 'ALL') return MARKET_ITEMS;
    return MARKET_ITEMS.filter(item => item.type === investmentFilter);
  }, [investmentFilter]);

  const batchBuyCart = useMemo(() => {
    const inflationMult = Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12);

    const lines = Object.entries(batchBuyQuantities)
      .filter(([, qty]) => qty > 0)
      .map(([id, qty]) => {
        const item = MARKET_ITEMS.find(i => i.id === id);
        if (!item) return null;

        const unitPrice = Math.round(item.price * inflationMult);
        return {
          id,
          item,
          qty,
          unitPrice,
          lineTotal: unitPrice * qty
        };
      })
      .filter(Boolean) as Array<{
        id: string;
        item: MarketItem;
        qty: number;
        unitPrice: number;
        lineTotal: number;
      }>;

    const totalCost = lines.reduce((sum, l) => sum + l.lineTotal, 0);
    const totalUnits = lines.reduce((sum, l) => sum + l.qty, 0);

    return {
      lines,
      totalCost,
      totalUnits,
      canAfford: totalCost <= gameState.cash
    };
  }, [batchBuyQuantities, gameState.cash, gameState.economy.inflationRate, gameState.month]);


  const careerPath = gameState.career?.path || 'TECH';
  const aiImpact = gameState.aiDisruption?.affectedIndustries?.[careerPath];

  // ============================================
  // HANDLERS
  // ============================================
  const toggleSound = () => {
    const ns = !soundEnabled;
    setSoundEnabled(ns);
    setMuted(!ns);
    // Keep saved game state in sync
    setGameState(prev => ({ ...prev, soundEnabled: ns }));
    if (ns) playClick();
  };

  const showNotif = (title: string, message: string, type: string = 'info') => {
    setNotification({ title, message, type });
    if (type === 'success') playNotification();
    else if (type === 'error') playError();
    else if (type === 'warning') playWarning();
    setTimeout(() => setNotification(null), 4000);
  };

  // Consolidate rapid consecutive purchases into one toast (less pop-up spam)
  const purchaseToastAggRef = useRef<{
    timer: number | null;
    items: Record<string, number>;
    totalCost: number;
  }>({
    timer: null,
    items: {},
    totalCost: 0
  });

  const queuePurchaseNotif = (name: string, cost: number) => {
    const ref = purchaseToastAggRef.current;
    ref.items[name] = (ref.items[name] || 0) + 1;
    ref.totalCost += cost;

    if (ref.timer) window.clearTimeout(ref.timer);

    ref.timer = window.setTimeout(() => {
      const entries = Object.entries(ref.items);
      const total = ref.totalCost;

      // reset
      ref.items = {};
      ref.totalCost = 0;
      ref.timer = null;

      if (entries.length === 0) return;

      const isSingle = entries.length === 1 && entries[0][1] === 1;
      const summary = entries
        .slice(0, 3)
        .map(([n, c]) => (c === 1 ? n : `${c}x ${n}`))
        .join(', ');
      const suffix = entries.length > 3 ? ` +${entries.length - 3} more` : '';

      showNotif(
        isSingle ? 'Purchase Complete!' : 'Purchases Complete!',
        isSingle
          ? `Bought ${entries[0][0]} for ${formatMoneyFull(total)}.`
          : `Bought ${summary}${suffix} for ${formatMoneyFull(total)} total.`,
        'success'
      );

      confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });
    }, 650);
  };


  const openConfirmDialog = useCallback((cfg: ConfirmDialogConfig) => {
    setConfirmDialog(cfg);
  }, []);

  const closeConfirmDialog = useCallback(() => {
    setConfirmDialog(null);
  }, []);

  const InfoTip = ({ id, text }: { id: string; text: string }) => {
    const isOpen = openTooltipId === id;

    const open = () => setOpenTooltipId(id);
    const close = () => setOpenTooltipId((prev) => (prev === id ? null : prev));
    const toggle = (e: React.MouseEvent) => {
      e.stopPropagation();
      setOpenTooltipId((prev) => (prev === id ? null : id));
    };

    return (
      <div
        className="relative inline-flex"
        onMouseEnter={() => open()}
        onMouseLeave={() => close()}
      >
        <button
          type="button"
          onClick={toggle}
          onBlur={() => close()}
          className="ml-1 inline-flex items-center justify-center w-6 h-6 rounded-full hover:bg-slate-700/60 text-slate-400 hover:text-slate-200"
          aria-label="Show info"
        >
          <Info size={14} />
        </button>
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.12 }}
              className="absolute z-50 top-full mt-2 right-0 w-[min(18rem,calc(100vw-2rem))] bg-slate-900 border border-slate-700 rounded-xl p-3 shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <p className="text-slate-200 text-sm leading-relaxed">{text}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };


  // ============================================
  // GOALS / QUESTS (Step 6)
  // Live quest completion + claim rewards
  // ============================================
  useEffect(() => {
    // Only sync quests once the run has started
    if (!gameStarted || !gameState.character || gameState.hasWon) return;

    const synced = updateQuests(gameState);

    // Detect newly-ready rewards (quest completed but not claimed yet)
    try {
      const prevReady = new Set(gameState.quests?.readyToClaim || []);
      const nextReady = new Set(synced.quests?.readyToClaim || []);
      const newlyReady = Array.from(nextReady).filter(id => !prevReady.has(id));

      if (newlyReady.length > 0) {
        confetti({ particleCount: 70, spread: 70, origin: { y: 0.65 } });
        newlyReady.slice(0, 3).forEach(id => {
          const q = getQuestById(id);
          if (q) {
            showNotif('✅ Quest Complete!', `Claim your reward: ${q.title}`, 'success');
          }
        });
      }

      const prevTrack = gameState.quests?.track;
      const nextTrack = synced.quests?.track;
      if (nextTrack && nextTrack !== prevTrack) {
        const label = nextTrack === 'INVESTOR' ? 'Investor' : nextTrack === 'ENTREPRENEUR' ? 'Entrepreneur' : 'Debt Crusher';
        showNotif('🧭 Track Unlocked', `${label} questline unlocked.`, 'info');
      }
    } catch {
      // No-op
    }

    const questSig = (qs: any) => {
      const a = Array.isArray(qs?.active) ? qs.active : [];
      const r = Array.isArray(qs?.readyToClaim) ? qs.readyToClaim : [];
      const c = Array.isArray(qs?.completed) ? qs.completed : [];
      const t = typeof qs?.track === 'string' ? qs.track : '';
      return `t:${t}|a:${a.join(',')}|r:${r.join(',')}|c:${c.join(',')}`;
    };

    const questsChanged = questSig(synced.quests) !== questSig(gameState.quests);
    const eventsChanged = (synced.events?.[0]?.id || '') !== (gameState.events?.[0]?.id || '');

    if (questsChanged || eventsChanged) {
      setGameState(synced);
      if (!isMultiplayer) {
        saveAdultGame(synced, 'autosave');
      }
    }
  }, [gameState, gameStarted, isMultiplayer]);

  const handleClaimQuest = (questId: string) => {
    if (isProcessing) return;
    const q = getQuestById(questId);

    setGameState(prev => {
      const next = claimQuestReward(prev, questId);
      if (!isMultiplayer) {
        saveAdultGame(next, 'autosave');
      }
      return next;
    });

    playAchievement();
    confetti({ particleCount: 140, spread: 85, origin: { y: 0.65 } });
    if (q) {
      showNotif('🏆 Reward Claimed!', q.title, 'success');
    }
  };

  const formatDateTime = (ts: number) => {
    try {
      return new Date(ts).toLocaleString();
    } catch {
      return '';
    }
  };

  const refreshSaveSummaries = useCallback(() => {
    setSaveSummaries(getSaveSummaries('adult'));
  }, []);

  const openSaveManager = () => {
    playClick();
    refreshSaveSummaries();
    setShowSaveManager(true);
  };

  const handleSaveToSlot = (slotId: SaveSlotId) => {
    try {
      saveAdultGame(gameState, slotId);
      refreshSaveSummaries();
      showNotif('Game Saved', `Saved to ${slotId === 'autosave' ? 'Autosave' : slotId}`, 'success');
    } catch {
      showNotif('Save Failed', 'Unable to save game in this browser.', 'error');
    }
  };

  const handleLoadFromSlot = (slotId: SaveSlotId) => {
    const loaded = loadAdultGame(slotId);
    if (!loaded) {
      showNotif('No Save Found', `Nothing saved in ${slotId}.`, 'warning');
      return;
    }

    setAutoPlaySpeed(null);
    setIsProcessing(false);
    setMonthlyReport(null);
    setGameState(loaded);
    setGameStarted(true);
    setShowCharacterSelect(false);

    const se = loaded.soundEnabled ?? true;
    setSoundEnabled(se);
    setMuted(!se);

    setShowSaveManager(false);
    showNotif('Game Loaded', `Loaded ${slotId === 'autosave' ? 'Autosave' : slotId}`, 'success');
  };

  const handleDeleteSlot = (slotId: SaveSlotId) => {
    deleteSaveSlot('adult', slotId);
    refreshSaveSummaries();
    showNotif('Save Deleted', `${slotId === 'autosave' ? 'Autosave' : slotId} deleted`, 'info');
  };

  const handleRenameSlot = (slotId: SaveSlotId) => {
    const current = saveSummaries.find(s => s.slotId === slotId)?.label || '';
    const newLabel = window.prompt('Name this save slot:', current);
    if (!newLabel) return;
    renameSaveSlot('adult', slotId, newLabel);
    refreshSaveSummaries();
    showNotif('Save Renamed', `Renamed ${slotId}`, 'success');
  };

  const handleQuickStart = () => {
    playClick();
    setShowCharacterSelect(true);
  };

  const handleSelectCharacter = (char: Character) => {
    playPurchase();
    const diff = DIFFICULTY_SETTINGS[selectedDifficulty];
    let startingCash = diff.startingCash + (char.startingBonus.type === 'cash' ? char.startingBonus.amount : 0);
    
    const initialLiabilities: Liability[] = [];
    
    // Student loans from character
    if (char.startingBonus.amount < 0) {
      const debtAmount = Math.abs(char.startingBonus.amount);
      initialLiabilities.push({
        id: 'student-loan-' + Date.now(),
        name: 'Student Loans',
        balance: debtAmount,
        originalBalance: debtAmount,
        interestRate: 0.065,
        monthlyPayment: calculateLoanPayment(debtAmount, 0.065, 120),
        type: 'STUDENT_LOAN'
      });
      startingCash = diff.startingCash; // Don't add negative bonus to cash
    }
    
    // Difficulty debt
    if ('startingDebt' in diff && diff.startingDebt) {
      const debtAmount = diff.startingDebt as number;
      initialLiabilities.push({
        id: 'personal-loan-' + Date.now(),
        name: 'Personal Loan',
        balance: debtAmount,
        originalBalance: debtAmount,
        interestRate: 0.10,
        monthlyPayment: calculateLoanPayment(debtAmount, 0.10, 48),
        type: 'PERSONAL_LOAN'
      });
    }

    const newState: GameState = {
      ...INITIAL_GAME_STATE,
      character: char,
      difficulty: selectedDifficulty,
      cash: Math.max(0, startingCash),
      career: {
        path: char.careerPath,
        title: CAREER_PATHS[char.careerPath].levels[0].title,
        salary: Math.round(CAREER_PATHS[char.careerPath].levels[0].baseSalary * diff.salaryMultiplier),
        level: 1,
        experience: 0,
        skills: {},
        aiVulnerability: CAREER_PATHS[char.careerPath].aiVulnerability,
        futureProofScore: CAREER_PATHS[char.careerPath].futureProofScore
      },
      playerJob: {
        title: CAREER_PATHS[char.careerPath].levels[0].title,
        salary: Math.round(CAREER_PATHS[char.careerPath].levels[0].baseSalary * diff.salaryMultiplier),
        level: 1,
        experience: 0
      },
      liabilities: initialLiabilities,
      activeSideHustles: [],
      quests: { ...INITIAL_QUEST_STATE, active: [...INITIAL_QUEST_STATE.active], readyToClaim: [], completed: [], track: undefined },
      soundEnabled
    };
    
    setGameState(newState);
    if (!isMultiplayer) {
      saveAdultGame(newState, 'autosave');
    }
    setShowCharacterSelect(false);
    setGameStarted(true);
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
  };

  // ============================================
  // NEXT TURN
  // ============================================
  const buildTurnPreview = useCallback((state: GameState): TurnPreviewData => {
    const nextMonth = (state.month || 1) + 1;
    const baseYear = state.year || 2025;
    const nextYear = (nextMonth % 12 === 1 && nextMonth > 1) ? (baseYear + 1) : baseYear;
    const monthOfYear = ((nextMonth - 1) % 12) + 1;

    const cf = calculateMonthlyCashFlowEstimate(state);
    const netChange = cf.income - cf.expenses;
    const projectedEndCash = (state.cash || 0) + netChange;
    const shortfall = projectedEndCash < 0 ? Math.abs(projectedEndCash) : 0;

    const incomeLines: TurnPreviewLine[] = [
      { label: 'Salary', value: cf.salary },
      { label: 'Side Hustles', value: cf.sideHustleIncome },
      { label: 'Passive Income', value: cf.passive },
      { label: 'Spouse Income', value: cf.spouseIncome },
    ].filter(l => l.value > 0).sort((a, b) => b.value - a.value);

    const expenseLines: TurnPreviewLine[] = [
      { label: 'Lifestyle', value: cf.lifestyleCost },
      { label: 'Debt Payments', value: cf.debtPayments },
      { label: 'Education', value: cf.educationPayment },
      { label: 'Children', value: cf.childrenExpenses },
      { label: 'Vehicles', value: cf.vehicleCosts },
    ].filter(l => l.value > 0).sort((a, b) => b.value - a.value);

    const lowBufferThreshold = Math.max(500, Math.round(cf.expenses * 0.10));
    const warningLevel: TurnPreviewData['warningLevel'] =
      shortfall > 0 ? 'SHORTFALL' : (projectedEndCash < lowBufferThreshold ? 'LOW_BUFFER' : 'SAFE');

    return {
      nextMonth,
      nextYear,
      monthOfYear,
      incomeLines,
      expenseLines,
      income: cf.income,
      expenses: cf.expenses,
      netChange,
      projectedEndCash,
      shortfall,
      warningLevel,
    };
  }, []);

  const advanceMonth = useCallback(() => {
    if (isProcessing || gameState.pendingScenario) return;
    setIsProcessing(true);
    playTick();

    setTimeout(() => {
      const { newState, monthlyReport: report } = processTurn(gameState);
      const netIncome = report.income - report.expenses;

      // Autoplay scheduling is blocked while decision/modals are open (see the Auto-play effect),
      // but we do NOT automatically disable autoplay. This lets autoplay continue seamlessly
      // after the player makes a choice (unless they explicitly stop it).

      if (Math.abs(netIncome) > 10) {
        setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: netIncome }]);
        netIncome > 0 ? playMoneyGain(netIncome) : playMoneyLoss();
      }

      if (newState.hasWon && !gameState.hasWon) {
        playVictory();
        confetti({ particleCount: 300, spread: 120, origin: { y: 0.5 } });
      }

      if (report.promoted) {
        playLevelUp();
        showNotif('🎉 Promotion!', `Promoted to ${newState.career?.title}!`, 'success');
      }

      // Goals & Quests: completion + claim notifications are handled by the live quest sync effect (Step 6).

      setGameState(newState);
      // Autosave (single player)
      if (!isMultiplayer) {
        saveAdultGame(newState, 'autosave');
      }
      setMonthlyReport(report);
      setIsProcessing(false);

      // Multiplayer: track turns and switch players after MULTIPLAYER_TURNS_PER_ROUND
      if (isMultiplayer && onTurnComplete) {
        const newTurnsTaken = multiplayerTurnsTaken + 1;
        setMultiplayerTurnsTaken(newTurnsTaken);

        if (newTurnsTaken >= MULTIPLAYER_TURNS_PER_ROUND || newState.hasWon) {
          // End this player's turn
          setMultiplayerTurnsTaken(0);
          onTurnComplete(newState);
        }
      }
    }, 150);
  }, [autoPlaySpeed, gameState, isProcessing, isMultiplayer, onTurnComplete, multiplayerTurnsTaken]);

  const hideTurnPreview = useCallback(() => {
    setShowTurnPreview(false);
    setTurnPreview(null);
  }, []);

  const closeTurnPreview = useCallback(() => {
    playClick();
    hideTurnPreview();
  }, [hideTurnPreview]);

  const confirmTurnPreview = useCallback(() => {
    closeTurnPreview();
    advanceMonth();
  }, [advanceMonth, closeTurnPreview]);

  // Next Month button handler (shows preview unless skipped)
  const handleNextTurn = useCallback(() => {
    if (isProcessing || gameState.pendingScenario) return;

    // If autoplay is enabled, or preview is disabled, advance immediately.
    if (autoPlaySpeed !== null || skipTurnPreview || isMultiplayer) {
      advanceMonth();
      return;
    }

    playClick();
    setTurnPreview(buildTurnPreview(gameState));
    setShowTurnPreview(true);
  }, [advanceMonth, autoPlaySpeed, buildTurnPreview, gameState, isMultiplayer, isProcessing, skipTurnPreview]);

  // Step 12: manual way to (re)open the preview after taking a quick fix.
  const openTurnPreviewNow = useCallback(() => {
    if (isMultiplayer) return;
    if (isProcessing || gameState.pendingScenario) return;
    playClick();
    setTurnPreview(buildTurnPreview(gameState));
    setShowTurnPreview(true);
    setShowReopenPreviewPill(false);
  }, [buildTurnPreview, gameState, isMultiplayer, isProcessing]);

  // Keyboard shortcuts for Next Month preview
  useEffect(() => {
    if (!showTurnPreview) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        closeTurnPreview();
      } else if (e.key === 'Enter') {
        confirmTurnPreview();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [showTurnPreview, closeTurnPreview, confirmTurnPreview]);

  // Auto-play
  // Autoplay should feel "hands-off": it temporarily pauses itself while any blocking UI is open
  // (events, confirmation dialogs, special market flows, etc.) and then continues automatically.
  // Players can always stop it explicitly via the header button, keyboard (P/F), or the event popup.
  const isAutoplayBlocked =
    !!gameState.pendingScenario ||
    !!marketSpecialAction ||
    !!confirmDialog ||
    !!showMortgageModal ||
    !!introVideoTabId ||
    showSaveManager ||
    !!imageLightbox ||
    showAccessibility ||
    showTurnPreview ||
    isProcessing ||
    gameState.hasWon ||
    gameState.isBankrupt;

  useEffect(() => {
    if (autoPlaySpeed === null || isAutoplayBlocked) return;
    const t = setTimeout(advanceMonth, autoPlaySpeed);
    return () => clearTimeout(t);
  }, [autoPlaySpeed, isAutoplayBlocked, gameState.month, advanceMonth]);

  // Keyboard shortcut: toggle autoplay (Fast Forward) with F / P.
  // (Avoids mouse travel on desktop.)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const target = e.target as HTMLElement | null;
      const tag = (target?.tagName || '').toLowerCase();
      const isTyping = tag === 'input' || tag === 'textarea' || (target as any)?.isContentEditable;
      if (isTyping) return;

      if (e.key === 'f' || e.key === 'F' || e.key === 'p' || e.key === 'P') {
        e.preventDefault();
        setAutoPlaySpeed((prev) => (prev ? null : 500));
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // ============================================
  // SCENARIO CHOICE
  // ============================================
  const handleScenarioChoice = (idx: number) => {
    if (!gameState.pendingScenario) return;
    playClick();

    const scenario = gameState.pendingScenario;
    const option = scenario.options[idx];
    const outcome: any = option.outcome;

    const labelLower = (option.label || '').toLowerCase();

    // Special economic flows (so choices clearly affect Assets/Liabilities)
    const isPanicSell = scenario.id === 'recession_starts' && labelLower.includes('panic sell');
    const isBuyDipLabel = labelLower.includes('buy the dip');
    const isMarketCrashOpportunity = scenario.id === 'market_crash_opportunity' && (labelLower.includes('invest') || labelLower.includes('all in'));
    const isHousingBuyMore = scenario.id === 'housing_bubble' && labelLower.includes('buy more');

    if (isPanicSell) {
      const patchedOutcome = {
        ...outcome,
        cashChange: 0,
        message: 'You decided to fire-sell assets to feel “safe” again. Choose what to sell at a 30% fire-sale discount.'
      };
      const newState = applyScenarioOutcome(gameState, patchedOutcome);
      setGameState(newState);
      if (!isMultiplayer) {
        saveAdultGame(newState, 'autosave');
      }

      // Open asset selection modal (default: everything selected)
      const sel: Record<string, boolean> = {};
      (gameState.assets || []).forEach(a => { sel[a.id] = true; });
      setPanicSellSelection(sel);

      setMarketSpecialAction({
        type: 'PANIC_SELL',
        discount: 0.3,
        title: '📉 Panic Sell',
        description:
          'Choose which assets to fire-sell now. You receive ~70% of current value. Mortgaged properties may create a deficiency balance.'
      });
      return;
    }

    if (isBuyDipLabel || isMarketCrashOpportunity || isHousingBuyMore) {
      const budget = (typeof outcome.cashChange === 'number' && outcome.cashChange < 0) ? Math.abs(outcome.cashChange) : 0;
      const discount = scenario.id === 'housing_bubble' ? 0.2 : 0.3;

      const patchedOutcome = {
        ...outcome,
        cashChange: 0,
        message: `Opportunity: pick a deal to buy at ${Math.round(discount * 100)}% below market price (up to ${formatMoneyFull(budget)}).`
      };
      const newState = applyScenarioOutcome(gameState, patchedOutcome);
      setGameState(newState);
      if (!isMultiplayer) {
        saveAdultGame(newState, 'autosave');
      }

      setDiscountBuyItemId(null);
      setDiscountBuyQuantity(1);
      setMarketSpecialAction({
        type: 'BUY_DISCOUNT',
        budget,
        discount,
        title: '🔥 Market Sale',
        description: `Choose what to buy at ${Math.round(discount * 100)}% below market price. You can invest up to ${formatMoneyFull(budget)} (and no more than your available cash).`
      });
      return;
    }

    const newState = applyScenarioOutcome(gameState, outcome);
    setGameState(newState);
    if (!isMultiplayer) {
      saveAdultGame(newState, 'autosave');
    }
    if (outcome.cashChange) {
      setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: outcome.cashChange! }]);
      outcome.cashChange > 0 ? playMoneyGain(outcome.cashChange) : playMoneyLoss();
    }
  };

  // ============================================
  // SPECIAL MARKET EVENT FLOWS
  // (Buy the Dip / Panic Sell) — makes outcomes explicit and carried through to Assets/Liabilities
  // ============================================
  const closeMarketSpecialAction = useCallback(() => {
    setMarketSpecialAction(null);
    setDiscountBuyItemId(null);
    setDiscountBuyQuantity(1);
    setPanicSellSelection({});
  }, []);

  const executeDiscountBuy = useCallback(() => {
    if (!marketSpecialAction || marketSpecialAction.type !== 'BUY_DISCOUNT') return;

    const item = MARKET_ITEMS.find(i => i.id === discountBuyItemId);
    if (!item) {
      showNotif('Choose a Deal', 'Select an asset to buy on sale.', 'warning');
      return;
    }

    const discount = marketSpecialAction.discount;
    const budgetCap = Math.max(0, marketSpecialAction.budget);

    const inflationMult = Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12);
    const basePrice = Math.round(item.price * inflationMult);
    const unitPrice = Math.max(1, Math.round(basePrice * (1 - discount)));

    const singleUnit = item.type === AssetType.REAL_ESTATE || item.type === AssetType.BUSINESS;
    const maxSpend = Math.min(budgetCap, gameState.cash);
    const maxUnits = singleUnit ? (unitPrice <= maxSpend ? 1 : 0) : Math.floor(maxSpend / unitPrice);

    if (maxUnits <= 0) {
      showNotif('Not Enough Cash', `You need at least ${formatMoneyFull(unitPrice)} available to grab this deal.`, 'error');
      return;
    }

    const qty = singleUnit ? 1 : Math.max(1, Math.min(discountBuyQuantity, maxUnits));
    const totalCost = unitPrice * qty;

    if (totalCost > gameState.cash) {
      showNotif('Not Enough Cash', `You need ${formatMoneyFull(totalCost)} but only have ${formatMoneyFull(gameState.cash)}.`, 'error');
      return;
    }

    playPurchase();

    setGameState(prev => {
      const inflationMultPrev = Math.pow(1 + prev.economy.inflationRate, prev.month / 12);
      const basePricePrev = Math.round(item.price * inflationMultPrev);
      const unitPricePrev = Math.max(1, Math.round(basePricePrev * (1 - discount)));
      const totalCostPrev = unitPricePrev * qty;

      if (prev.cash < totalCostPrev) return prev;

      const existing = prev.assets.find(a => a.name === item.name && a.type === item.type && !a.mortgageId);
      let updatedAssets: Asset[];

      if (existing) {
        const prevQty = typeof existing.quantity === 'number' ? existing.quantity : 1;
        const newQty = prevQty + qty;
        const newCostBasis = ((existing.costBasis * prevQty) + (unitPricePrev * qty)) / newQty;

        updatedAssets = prev.assets.map(a => a.id === existing.id ? {
          ...a,
          quantity: newQty,
          costBasis: newCostBasis,
          value: basePricePrev,
          cashFlow: (item.expectedYield * basePricePrev) / 12,
          purchasePrice: unitPricePrev
        } : a);
      } else {
        const newAsset: Asset = {
          id: 'asset-' + Date.now().toString(),
          name: item.name,
          type: item.type,
          // Market value vs what you paid
          value: basePricePrev,
          costBasis: unitPricePrev,
          quantity: qty,
          appreciationRate: item.appreciationRate || (item.expectedYield * 0.4),
          volatility: item.volatility,
          baseYield: item.expectedYield,
          cashFlow: (item.expectedYield * basePricePrev) / 12,
          purchasedMonth: prev.month,
          purchasePrice: unitPricePrev,
          industry: item.industry,
          description: item.description,
          priceHistory: [{ month: prev.month, value: basePricePrev }]
        };
        updatedAssets = [...prev.assets, newAsset];
      }

      return {
        ...prev,
        cash: prev.cash - totalCostPrev,
        assets: updatedAssets,
        events: [{
          id: Date.now().toString(),
          month: prev.month,
          title: `🔥 Bought on Sale: ${item.name}`,
          description: `Purchased ${qty}x at ${Math.round(discount * 100)}% off for ${formatMoneyFull(totalCostPrev)} total.`,
          type: 'DECISION'
        }, ...prev.events]
      };
    });

    setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: -totalCost }]);
    playMoneyLoss();
    showNotif('Deal Captured!', `Bought ${qty}x ${item.name} at ${Math.round(discount * 100)}% off (${formatMoneyFull(totalCost)}).`, 'success');
    confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });

    closeMarketSpecialAction();
  }, [marketSpecialAction, discountBuyItemId, discountBuyQuantity, gameState.cash, gameState.economy.inflationRate, gameState.month, closeMarketSpecialAction]);

  const executePanicSell = useCallback(() => {
    if (!marketSpecialAction || marketSpecialAction.type !== 'PANIC_SELL') return;

    const discount = marketSpecialAction.discount;
    const selectedIds = Object.entries(panicSellSelection)
      .filter(([, v]) => !!v)
      .map(([id]) => id);

    if (selectedIds.length === 0) {
      showNotif('Select Assets', 'Choose at least one asset to panic sell.', 'warning');
      return;
    }

    // Preview (for UI feedback)
    const preview = (() => {
      let net = 0;
      for (const id of selectedIds) {
        const a = gameState.assets.find(x => x.id === id);
        if (!a) continue;
        const qty = typeof a.quantity === 'number' ? a.quantity : 1;
        const gross = a.value * qty;
        const fireSale = Math.round(gross * (1 - discount));

        const mtg = a.mortgageId
          ? (gameState.mortgages.find(m => m.id === a.mortgageId) || gameState.mortgages.find(m => m.assetId === id))
          : gameState.mortgages.find(m => m.assetId === id);

        if (mtg) {
          net += Math.max(0, fireSale - mtg.balance);
        } else {
          net += fireSale;
        }
      }
      return net;
    })();

    playWarning();

    setGameState(prev => {
      let cashDelta = 0;
      let nextAssets = [...prev.assets];
      let nextLiabilities = [...prev.liabilities];
      let nextMortgages = [...prev.mortgages];

      const soldNames: string[] = [];
      const deficiencyNotes: string[] = [];

      for (const assetId of selectedIds) {
        const asset = nextAssets.find(a => a.id === assetId);
        if (!asset) continue;

        const qty = typeof asset.quantity === 'number' ? asset.quantity : 1;
        const gross = asset.value * qty;
        const fireSale = Math.round(gross * (1 - discount));

        const mortgage = asset.mortgageId
          ? (nextMortgages.find(m => m.id === asset.mortgageId) || nextMortgages.find(m => m.assetId === assetId))
          : nextMortgages.find(m => m.assetId === assetId);

        if (mortgage) {
          if (fireSale >= mortgage.balance) {
            cashDelta += fireSale - mortgage.balance;
          } else {
            const deficiency = mortgage.balance - fireSale;
            const newLiability: Liability = {
              id: 'def-' + Date.now().toString() + '-' + assetId,
              name: `Deficiency Balance (${asset.name})`,
              balance: deficiency,
              originalBalance: deficiency,
              interestRate: 0.12,
              monthlyPayment: Math.max(50, Math.round(deficiency / 36)),
              type: 'PERSONAL_LOAN'
            };
            nextLiabilities = [...nextLiabilities, newLiability];
            deficiencyNotes.push(`${asset.name}: ${formatMoneyFull(deficiency)}`);
          }

          // Remove mortgage + its matching liability (id)
          nextLiabilities = nextLiabilities.filter(l => l.id !== mortgage.id && l.assetId !== mortgage.assetId);
          nextMortgages = nextMortgages.filter(m => m.id !== mortgage.id);
        } else {
          cashDelta += fireSale;
        }

        nextAssets = nextAssets.filter(a => a.id !== assetId);
        soldNames.push(asset.name);
      }

      if (soldNames.length === 0) return prev;

      const desc = [
        `Fire-sold ${soldNames.join(', ')} at ${Math.round(discount * 100)}% below value.`,
        `Net cash received: ${formatMoneyFull(cashDelta)}.`,
        deficiencyNotes.length ? `Deficiency created: ${deficiencyNotes.join('; ')}.` : ''
      ].filter(Boolean).join(' ');

      return {
        ...prev,
        cash: prev.cash + cashDelta,
        assets: nextAssets,
        liabilities: nextLiabilities,
        mortgages: nextMortgages,
        events: [{
          id: Date.now().toString(),
          month: prev.month,
          title: '📉 Panic Sale Executed',
          description: desc,
          type: 'DECISION'
        }, ...prev.events]
      };
    });

    setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: preview }]);
    preview > 0 ? playMoneyGain(preview) : playMoneyLoss();
    showNotif('Fire Sale Complete', `You panic sold ${selectedIds.length} asset(s).`, 'warning');

    closeMarketSpecialAction();
  }, [marketSpecialAction, panicSellSelection, gameState.assets, gameState.mortgages, closeMarketSpecialAction]);



  // ============================================
  // MONTHLY ACTIONS (Adult mode)
  // ============================================
  const handleUseMonthlyAction = (actionId: MonthlyActionId) => {
    if (isProcessing) return;
    if (gameState.pendingScenario) {
      showNotif('Resolve Event First', 'Please respond to the current event before taking Monthly Actions.', 'warning');
      return;
    }
    if (gameState.isBankrupt) {
      showNotif('Game Over', 'You are bankrupt and can no longer take actions.', 'error');
      return;
    }

    playClick();
    const beforeCash = gameState.cash;
    const { newState, message } = applyMonthlyAction(gameState, actionId);

    // No-op or blocked action
    if (newState === gameState) {
      showNotif('Cannot Do That', message, 'warning');
      return;
    }

    setGameState(newState);
    // Autosave (single player)
    if (!isMultiplayer) {
      saveAdultGame(newState, 'autosave');
    }

    const cashDelta = newState.cash - beforeCash;
    if (Math.abs(cashDelta) >= 1) {
      setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: cashDelta }]);
      cashDelta > 0 ? playMoneyGain(cashDelta) : playMoneyLoss();
    }

    showNotif('Monthly Action Used', message, 'success');
  };

  // ============================================
  // BUY ASSET (with or without mortgage)
  // ============================================
  const handleBuyAsset = useCallback((item: MarketItem, mortgageOptionId?: string) => {
    const inflationMult = Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12);
    const price = Math.round(item.price * inflationMult);
    
    if (mortgageOptionId && item.canMortgage) {
      const assetId = 'asset-' + Date.now().toString();
      const result = createMortgage(assetId, item.name, price, mortgageOptionId, gameState.economy.interestRate);
      if (!result) { playError(); return; }
      
      if (gameState.cash < result.downPayment) {
        playError();
        showNotif('Insufficient Funds', `Need ${formatMoneyFull(result.downPayment)} for down payment`, 'error');
        return;
      }
      
      playPurchase();
      setGameState(prev => {
        const asset: Asset = {
          id: assetId,
          name: item.name,
          type: item.type,
          value: price,
          costBasis: price,
          quantity: 1,
          cashFlow: (item.expectedYield * price) / 12,
          volatility: item.volatility,
          appreciationRate: item.expectedYield * 0.4,
          priceHistory: [{ month: prev.month, value: price }],
          baseYield: item.expectedYield,
          industry: item.industry,
          mortgageId: result.mortgage.id
        };
        return {
          ...prev,
          cash: prev.cash - result.downPayment,
          assets: [...prev.assets, asset],
          liabilities: [...prev.liabilities, result.liability],
          mortgages: [...prev.mortgages, result.mortgage],
          events: [{
            id: Date.now().toString(),
            month: prev.month,
            title: `🏠 Purchased ${item.name}`,
            description: `${formatMoneyFull(result.downPayment)} down, ${formatMoneyFull(result.mortgage.monthlyPayment)}/mo mortgage`,
            type: 'DECISION'
          }, ...prev.events]
        };
      });
      setShowMortgageModal(null);
      confetti({ particleCount: 40, spread: 50 });
      showNotif('Property Purchased!', `Mortgage: ${formatMoneyFull(result.mortgage.monthlyPayment)}/mo`, 'success');
    } else {
      // Cash purchase
      if (gameState.cash < price) {
        playError();
        showNotif('Insufficient Funds', `Need ${formatMoneyFull(price)}`, 'error');
        return;
      }
      
      playPurchase();
      setGameState(prev => {
        const existing = prev.assets.find(a => a.name === item.name && !a.mortgageId);
        let newAssets = [...prev.assets];
        
        if (existing) {
          const idx = newAssets.findIndex(a => a.id === existing.id);
          const newQuantity = existing.quantity + 1;
          const newCostBasis = ((existing.costBasis * existing.quantity) + price) / newQuantity;
          // Recalculate average cashFlow based on new cost basis
          const newCashFlow = (item.expectedYield * newCostBasis) / 12;
          newAssets[idx] = {
            ...existing,
            quantity: newQuantity,
            value: price,
            costBasis: newCostBasis,
            cashFlow: newCashFlow
          };
        } else {
          newAssets.push({
            id: 'asset-' + Date.now(),
            name: item.name,
            type: item.type,
            value: price,
            costBasis: price,
            quantity: 1,
            cashFlow: (item.expectedYield * price) / 12,
            volatility: item.volatility,
            appreciationRate: item.expectedYield * 0.4,
            priceHistory: [{ month: prev.month, value: price }],
            baseYield: item.expectedYield,
            industry: item.industry
          });
        }
        
        return {
          ...prev,
          cash: prev.cash - price,
          assets: newAssets,
          events: [{
            id: Date.now().toString(),
            month: prev.month,
            title: `📦 Purchased ${item.name}`,
            description: `Bought for ${formatMoneyFull(price)} cash`,
            type: 'DECISION'
          }, ...prev.events]
        };
      });
      queuePurchaseNotif(item.name, price);
    }
  }, [gameState]);

  // ============================================
  // BATCH BUY (Securities)
  // ============================================
  const isBatchBuyEligible = (item: MarketItem) => {
    return [
      AssetType.STOCK,
      AssetType.INDEX_FUND,
      AssetType.BOND,
      AssetType.CRYPTO,
      AssetType.COMMODITY
    ].includes(item.type);
  };

  const toggleBatchBuyMode = () => {
    playClick();
    setBatchBuyMode(prev => {
      const next = !prev;
      if (!next) {
        setBatchBuyQuantities({});
      }
      return next;
    });
  };

  const setBatchQty = (itemId: string, qty: number) => {
    setBatchBuyQuantities(prev => {
      const next = { ...prev };
      if (qty <= 0) {
        delete next[itemId];
      } else {
        next[itemId] = qty;
      }
      return next;
    });
  };

  const clearBatchBuyCart = () => {
    playClick();
    setBatchBuyQuantities({});
  };

  const executeBatchBuy = () => {
    if (batchBuyCart.lines.length === 0) {
      showNotif('Cart Empty', 'Select quantities on securities first.', 'warning');
      return;
    }

    if (!batchBuyCart.canAfford) {
      showNotif(
        'Not Enough Cash',
        `Total is ${formatMoneyFull(batchBuyCart.totalCost)} but you only have ${formatMoneyFull(gameState.cash)}.`,
        'error'
      );
      return;
    }

    playPurchase();

    setGameState(prev => {
      const inflationMult = Math.pow(1 + prev.economy.inflationRate, prev.month / 12);

      let cash = prev.cash;
      let assets = [...prev.assets];
      let totalSpent = 0;

      const purchased: string[] = [];

      for (const line of batchBuyCart.lines) {
        const item = line.item;
        if (!isBatchBuyEligible(item)) continue;

        const unitPrice = Math.round(item.price * inflationMult);
        const qty = Math.max(1, line.qty);
        const lineTotal = unitPrice * qty;

        if (cash < lineTotal) break;

        cash -= lineTotal;
        totalSpent += lineTotal;
        purchased.push(`${qty}x ${item.name}`);

        const existing = assets.find(a => a.name === item.name && a.type === item.type && !a.mortgageId);
        if (existing) {
          const prevQty = typeof existing.quantity === 'number' ? existing.quantity : 1;
          const newQty = prevQty + qty;
          const newCostBasis = ((existing.costBasis * prevQty) + (unitPrice * qty)) / newQty;

          assets = assets.map(a => a.id === existing.id ? {
            ...a,
            quantity: newQty,
            costBasis: newCostBasis,
            value: unitPrice,
            cashFlow: (item.expectedYield * unitPrice) / 12,
            purchasePrice: unitPrice
          } : a);
        } else {
          const newAsset: Asset = {
            id: 'asset-' + Date.now().toString() + '-' + item.id,
            name: item.name,
            type: item.type,
            value: unitPrice,
            costBasis: unitPrice,
            quantity: qty,
            appreciationRate: item.appreciationRate || (item.expectedYield * 0.4),
            volatility: item.volatility,
            baseYield: item.expectedYield,
            cashFlow: (item.expectedYield * unitPrice) / 12,
            purchasedMonth: prev.month,
            purchasePrice: unitPrice,
            industry: item.industry,
            description: item.description,
            priceHistory: [{ month: prev.month, value: unitPrice }]
          };
          assets.push(newAsset);
        }
      }

      if (totalSpent <= 0) return prev;

      return {
        ...prev,
        cash,
        assets,
        events: [{
          id: Date.now().toString(),
          month: prev.month,
          title: '📦 Batch Purchase',
          description: `Bought ${purchased.join(', ')} for ${formatMoneyFull(totalSpent)} total.`,
          type: 'DECISION'
        }, ...prev.events]
      };
    });

    setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: -batchBuyCart.totalCost }]);
    playMoneyLoss();
    showNotif(
      'Batch Purchase Complete!',
      `Bought ${batchBuyCart.lines.length} ${batchBuyCart.lines.length === 1 ? 'security' : 'securities'} for ${formatMoneyFull(batchBuyCart.totalCost)}.`,
      'success'
    );

    confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });

    // Clear cart (keep mode on for rapid re-buying)
    setBatchBuyQuantities({});
  };

  const openBatchBuyConfirm = () => {
    if (batchBuyCart.lines.length === 0) {
      showNotif('Cart Empty', 'Select quantities on securities first.', 'warning');
      return;
    }

    const details = batchBuyCart.lines.map(l => ({
      label: `${l.qty}x ${l.item.name}`,
      value: `${formatMoneyFull(l.lineTotal)} (${formatMoneyFull(l.unitPrice)} each)`
    }));

    details.push({
      label: 'TOTAL',
      value: formatMoneyFull(batchBuyCart.totalCost)
    });

    openConfirmDialog({
      title: 'Confirm Batch Purchase',
      description: 'You are about to buy the following securities:',
      details,
      confirmLabel: `Buy (${formatMoneyFull(batchBuyCart.totalCost)})`,
      cancelLabel: 'Cancel',
      onConfirm: executeBatchBuy
    });
  };



  // ============================================
  // SELL ASSET
  // ============================================
  const handleSellAsset = useCallback((assetId: string) => {
    playSell();
    setGameState(prev => {
      const asset = prev.assets.find(a => a.id === assetId);
      if (!asset) return prev;

      const qty = typeof asset.quantity === 'number' ? asset.quantity : 1;
      const saleValue = asset.value * qty;

      // Find mortgage by explicit mortgageId first (backwards compatible), then by assetId
      const mortgage = asset.mortgageId
        ? (prev.mortgages.find(m => m.id === asset.mortgageId) || prev.mortgages.find(m => m.assetId === assetId))
        : prev.mortgages.find(m => m.assetId === assetId);

      // If mortgaged, pay off mortgage first
      let netProceeds = saleValue;
      if (mortgage) {
        netProceeds = saleValue - mortgage.balance;
        if (netProceeds < 0) {
          // Can't sell - underwater
          showNotif('Cannot Sell', 'Property is underwater (worth less than mortgage).', 'error');
          return prev;
        }
      }

      const nextLiabilities = mortgage
        ? prev.liabilities.filter(l => l.id !== mortgage.id && l.assetId !== mortgage.assetId)
        : prev.liabilities;

      const nextMortgages = mortgage
        ? prev.mortgages.filter(m => m.id !== mortgage.id)
        : prev.mortgages;

      return {
        ...prev,
        cash: prev.cash + netProceeds,
        assets: prev.assets.filter(a => a.id !== assetId),
        liabilities: nextLiabilities,
        mortgages: nextMortgages,
        events: [{
          id: Date.now().toString(),
          month: prev.month,
          title: `💰 Sold ${asset.name}`,
          description: `Sold for ${formatMoneyFull(saleValue)}${mortgage ? ` (${formatMoneyFull(netProceeds)} after mortgage)` : ''}`,
          type: 'DECISION'
        }, ...prev.events]
      };
    });
  }, []);

  // ============================================
  // TAKE LOAN
  // ============================================
  const handleTakeLoan = useCallback((loanOption: typeof LOAN_OPTIONS[0]) => {
    const payment = calculateLoanPayment(loanOption.amount, loanOption.rate, loanOption.term);

    openConfirmDialog({
      title: `Confirm Loan: ${loanOption.name}`,
      description: 'Loans are permanent until repaid. Confirm before taking on new debt.',
      details: [
        { label: 'Cash received now', value: formatMoneyFull(loanOption.amount) },
        { label: 'APR', value: `${(loanOption.rate * 100).toFixed(1)}%` },
        { label: 'Term', value: `${loanOption.term} months` },
        { label: 'Est. monthly payment', value: formatMoneyFull(payment) },
      ],
      confirmLabel: 'Take Loan',
      cancelLabel: 'Cancel',
      danger: true,
      onConfirm: () => {
        playPurchase();
        setGameState(prev => {
          const newLiability: Liability = {
            id: 'loan-' + Date.now(),
            name: loanOption.name,
            balance: loanOption.amount,
            originalBalance: loanOption.amount,
            interestRate: loanOption.rate,
            monthlyPayment: payment,
            type: 'PERSONAL_LOAN'
          };

          return {
            ...prev,
            cash: prev.cash + loanOption.amount,
            liabilities: [...prev.liabilities, newLiability],
            events: [{
              id: Date.now().toString(),
              month: prev.month,
              title: `💳 Took ${loanOption.name}`,
              description: `Received ${formatMoneyFull(loanOption.amount)} at ${formatPercent(loanOption.rate)} APR, ${formatMoneyFull(payment)}/mo`,
              type: 'DECISION'
            }, ...prev.events]
          };
        });

        setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: loanOption.amount }]);
        playMoneyGain(loanOption.amount);
        showNotif('Loan Approved!', `${formatMoneyFull(loanOption.amount)} deposited`, 'success');
      },
      onCancel: () => {
        playClick();
      }
    });
  }, [openConfirmDialog]);

  // ============================================
  // PAY DEBT
  // ============================================
  const handlePayDebt = useCallback((liabilityId: string, amount?: number) => {
    const liability = gameState.liabilities.find(l => l.id === liabilityId);
    if (!liability) return;
    
    const payAmount = amount || Math.min(liability.balance, gameState.cash);
    if (payAmount <= 0 || gameState.cash < payAmount) {
      playError();
      showNotif('Insufficient Funds', 'Not enough cash to pay', 'error');
      return;
    }
    
    playMoneyLoss();
    setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: -payAmount }]);
    
    setGameState(prev => {
      const newLiabilities = prev.liabilities.map(l => {
        if (l.id === liabilityId) {
          const newBalance = l.balance - payAmount;
          return { ...l, balance: Math.max(0, newBalance) };
        }
        return l;
      }).filter(l => l.balance > 0);
      
      const paidOff = !newLiabilities.find(l => l.id === liabilityId);
      if (paidOff) {
        playAchievement();
        showNotif('🎉 Debt Paid Off!', liability.name, 'success');
      }
      
      return {
        ...prev,
        cash: prev.cash - payAmount,
        liabilities: newLiabilities,
        events: [{
          id: Date.now().toString(),
          month: prev.month,
          title: paidOff ? `✅ Paid Off ${liability.name}` : `💸 Paid ${formatMoneyFull(payAmount)} on ${liability.name}`,
          description: paidOff ? 'Debt eliminated!' : `Remaining: ${formatMoneyFull(liability.balance - payAmount)}`,
          type: 'DECISION'
        }, ...prev.events]
      };
    });
  }, [gameState]);

  // ============================================
  // EDUCATION
  // ============================================
  const handleEnrollEducation = useCallback((edu: EducationOption) => {
    // Check if currently enrolled (handle both null and undefined)
    const isCurrentlyEnrolled = gameState.education.currentlyEnrolled && 
                                gameState.education.currentlyEnrolled.educationId;
    
    if (isCurrentlyEnrolled) {
      playError();
      showNotif('Already Enrolled', 'Complete current program first', 'error');
      return;
    }
    
    // Check if already completed this degree
    if (gameState.education.degrees.includes(edu.id)) {
      playError();
      showNotif('Already Completed', 'You already have this degree', 'error');
      return;
    }
    
    // Check prerequisites
    if (edu.requirements) {
      const hasPrereq = edu.requirements.some(req => 
        gameState.education.degrees.some(d => {
          const degree = EDUCATION_OPTIONS.find(e => e.id === d);
          return degree && degree.level === req;
        })
      );
      if (!hasPrereq) {
        playError();
        showNotif('Prerequisites Missing', `Requires ${edu.requirements.join(' or ')} degree`, 'error');
        return;
      }
    }
    
    // Check if can afford deposit (10% upfront for expensive degrees, full for cheap ones)
    const isExpensive = edu.cost > 20000;
    const deposit = isExpensive ? Math.round(edu.cost * 0.1) : edu.cost;
    
    if (gameState.cash < deposit) {
      playError();
      showNotif('Insufficient Funds', `Need ${formatMoneyFull(deposit)} ${isExpensive ? 'deposit' : 'to enroll'}`, 'error');
      return;
    }
    
    const isRelevant = edu.relevantCareers.includes(careerPath);
    const loanAmount = isExpensive ? edu.cost - deposit : 0;
    const estLoanPayment = isExpensive ? Math.round(loanAmount / edu.duration) : 0;
    const needsConfirm = isExpensive || !isRelevant || deposit >= 5000;

    const doEnroll = () => {
      playPurchase();
      setGameState(prev => {
        const newLiabilities = [...prev.liabilities];
        if (isExpensive) {
          newLiabilities.push({
            id: 'student-loan-' + Date.now(),
            name: `${edu.name} Student Loan`,
            balance: loanAmount,
            originalBalance: loanAmount,
            interestRate: 0.065, // 6.5% student loan rate
            monthlyPayment: estLoanPayment,
            type: 'STUDENT_LOAN'
          });
        }

        return {
          ...prev,
          cash: prev.cash - deposit,
          liabilities: newLiabilities,
          education: {
            ...prev.education,
            currentlyEnrolled: {
              educationId: edu.id,
              monthsRemaining: edu.duration,
              monthlyPayment: 0 // Payment is now handled by liability
            }
          },
          events: [{
            id: Date.now().toString(),
            month: prev.month,
            title: `📚 Started ${edu.name}`,
            description: isRelevant
              ? `This will boost your ${CAREER_PATHS[careerPath].name} career by ${Math.round((edu.salaryBoost - 1) * 100)}%!${isExpensive ? ` Student loan: ${formatMoneyFull(loanAmount)}` : ''}`
              : `⚠️ Warning: This degree won't help your ${CAREER_PATHS[careerPath].name} career.`,
            type: 'DECISION'
          }, ...prev.events]
        };
      });

      showNotif(
        isRelevant ? '🎓 Great Choice!' : '⚠️ Career Mismatch',
        isRelevant
          ? `${edu.name} will boost your salary!`
          : `${edu.name} won't benefit your ${CAREER_PATHS[careerPath].name} career`,
        isRelevant ? 'success' : 'warning'
      );
    };

    if (needsConfirm) {
      openConfirmDialog({
        title: `Confirm Enrollment: ${edu.name}`,
        description: 'Education is a long-term commitment. Confirm before enrolling in expensive or mismatched programs.',
        details: [
          { label: 'Upfront payment', value: formatMoneyFull(deposit) },
          ...(isExpensive
            ? [
                { label: 'Student loan', value: formatMoneyFull(loanAmount) },
                { label: 'Est. loan payment', value: `${formatMoneyFull(estLoanPayment)}/mo` },
                { label: 'Duration', value: `${edu.duration} months` },
              ]
            : [{ label: 'Duration', value: `${edu.duration} months` }]),
          { label: 'Career relevance', value: isRelevant ? '✅ Relevant' : '⚠️ Not relevant' },
          { label: 'Salary boost', value: `+${Math.round((edu.salaryBoost - 1) * 100)}%` },
        ],
        confirmLabel: 'Enroll',
        cancelLabel: 'Cancel',
        danger: !isRelevant || isExpensive,
        onConfirm: doEnroll,
        onCancel: () => playClick(),
      });
      return;
    }

    doEnroll();
  }, [gameState, careerPath, openConfirmDialog]);

  // ============================================
  // SIDE HUSTLES
  // ============================================
  const handleStartSideHustle = useCallback((hustle: SideHustle) => {
    // Check if already active
    if (gameState.activeSideHustles.find(h => h.id === hustle.id)) {
      playError();
      showNotif('Already Active', 'You are already doing this side hustle', 'error');
      return;
    }
    
    // Check startup cost
    if (gameState.cash < hustle.startupCost) {
      playError();
      showNotif('Insufficient Funds', `Need ${formatMoneyFull(hustle.startupCost)} startup cost`, 'error');
      return;
    }
    
    // Check education requirements
    if (hustle.requiredEducation && hustle.requiredEducation.length > 0) {
      const hasRequired = hustle.requiredEducation.some(reqCat =>
        gameState.education.degrees.some(d => {
          const degree = EDUCATION_OPTIONS.find(e => e.id === d);
          return degree && degree.category === reqCat;
        })
      );
      if (!hasRequired) {
        playError();
        showNotif('Education Required', `Need ${hustle.requiredEducation.join(' or ')} education`, 'error');
        return;
      }
    }
    
    // Check energy
    if (gameState.stats.energy < hustle.energyCost) {
      playError();
      showNotif('Too Tired', 'Not enough energy for this side hustle', 'error');
      return;
    }
    
    playPurchase();
    
    setGameState(prev => ({
      ...prev,
      cash: prev.cash - hustle.startupCost,
      activeSideHustles: [...prev.activeSideHustles, { ...hustle, isActive: true }],
      events: [{
        id: Date.now().toString(),
        month: prev.month,
        title: `🚀 Started ${hustle.name}`,
        description: `Expected income: ${formatMoneyFull(hustle.incomeRange.min)}-${formatMoneyFull(hustle.incomeRange.max)}/mo`,
        type: 'DECISION'
      }, ...prev.events]
    }));
    
    if (hustle.startupCost > 0) {
      setFloatingNumbers(p => [...p, { id: Date.now().toString(), value: -hustle.startupCost }]);
    }
    showNotif('Side Hustle Started!', `${hustle.name} is now active`, 'success');
  }, [gameState]);

  const handleStopSideHustle = useCallback((hustleId: string) => {
    playClick();
    const hustle = gameState.activeSideHustles.find(h => h.id === hustleId);
    
    setGameState(prev => ({
      ...prev,
      activeSideHustles: prev.activeSideHustles.filter(h => h.id !== hustleId),
      events: [{
        id: Date.now().toString(),
        month: prev.month,
        title: `🛑 Stopped ${hustle?.name || 'Side Hustle'}`,
        description: 'Side hustle discontinued',
        type: 'DECISION'
      }, ...prev.events]
    }));
    
    showNotif('Side Hustle Stopped', hustle?.name || 'Hustle', 'info');
  }, [gameState]);

  // ============================================
  // LIFESTYLE
  // ============================================
  const handleChangeLifestyle = useCallback((lifestyle: Lifestyle) => {
    if (lifestyle === gameState.lifestyle) {
      playClick();
      return;
    }

    const current = LIFESTYLE_OPTS[gameState.lifestyle];
    const next = LIFESTYLE_OPTS[lifestyle];
    const delta = next.cost - current.cost;

    openConfirmDialog({
      title: 'Confirm Lifestyle Change',
      description: 'Lifestyle changes immediately affect your monthly expenses and wellbeing. Confirm to avoid costly mis-clicks.',
      details: [
        { label: 'From', value: `${gameState.lifestyle} (${formatMoneyFull(current.cost)}/mo)` },
        { label: 'To', value: `${lifestyle} (${formatMoneyFull(next.cost)}/mo)` },
        { label: 'Monthly cost change', value: `${delta >= 0 ? '+' : ''}${formatMoneyFull(delta)}/mo` },
        { label: 'Happiness impact', value: `${next.happiness >= 0 ? '+' : ''}${next.happiness}` },
      ],
      confirmLabel: 'Change Lifestyle',
      cancelLabel: 'Cancel',
      danger: delta > 0,
      onConfirm: () => {
        playClick();
        setGameState(prev => ({ ...prev, lifestyle }));
        showNotif('Lifestyle Changed', `Now living ${lifestyle.toLowerCase()}`, 'info');
      },
      onCancel: () => {
        playClick();
      }
    });
  }, [gameState.lifestyle, openConfirmDialog]);

  // ============================================
  // SCREENS
  // ============================================
  
  // Welcome Screen
  if (!gameStarted && !showCharacterSelect) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="max-w-md w-full text-center">
          {onBackToMenu && (
            <button onClick={onBackToMenu} className="absolute top-4 left-4 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-full text-white font-medium transition-all">
              ← Back to Menu
            </button>
          )}
          <motion.div animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.05, 1] }} transition={{ duration: 3, repeat: Infinity }} className="text-7xl mb-4">💰</motion.div>
          <h1 className="text-5xl font-bold text-white mb-2">Tycoon</h1>
          <p className="text-emerald-400 font-medium text-xl">Financial Freedom Simulator</p>
          <p className="text-slate-400 mt-2 mb-6">Build wealth • Invest wisely • Beat the robots</p>
          
          <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={handleQuickStart}
            className="w-full py-4 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-bold rounded-xl shadow-lg text-xl mb-4">
            🚀 Start Your Journey
          </motion.button>
          
          <button onClick={toggleSound} className="p-3 bg-slate-800 rounded-lg text-slate-400 hover:text-white">
            {soundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </button>
          
          <p className="text-slate-500 text-sm mt-6">v3.4.3 • Autoplay Continues After Events • Stop Autoplay in Event Popups • Event Cooldowns • Save/Load • Event Images</p>
        </motion.div>
      </div>
    );
  }

  // Character Select Screen
  if (showCharacterSelect) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-white mb-2">Choose Your Path</h1>
            <p className="text-slate-400">⚠️ Some careers are more AI-proof than others!</p>
          </div>
          
          {/* Difficulty Selection */}
          <div className="flex justify-center gap-2 mb-6 flex-wrap">
            {(Object.keys(DIFFICULTY_SETTINGS) as Array<keyof typeof DIFFICULTY_SETTINGS>).map(diff => (
              <motion.button key={diff} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                onClick={() => { playClick(); setSelectedDifficulty(diff); }}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${selectedDifficulty === diff ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'}`}>
                {DIFFICULTY_SETTINGS[diff].label}
              </motion.button>
            ))}
          </div>
          
          <p className="text-center text-slate-500 text-sm mb-6">{DIFFICULTY_SETTINGS[selectedDifficulty].description}</p>
          
          {/* Character Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {CHARACTERS.map(char => {
              const career = CAREER_PATHS[char.careerPath];
              const futureProof = career.futureProofScore;
              
              return (
                <motion.div key={char.id} whileHover={{ scale: 1.02, y: -5 }} whileTap={{ scale: 0.98 }}
                  onClick={() => handleSelectCharacter(char)}
                  className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 cursor-pointer hover:border-emerald-500/50 transition-all">
                  <div className={`w-14 h-14 rounded-full bg-gradient-to-br ${char.avatarColor} flex items-center justify-center text-2xl mb-3 mx-auto`}>
                    {char.avatarEmoji}
                  </div>
                  <h3 className="text-lg font-bold text-white text-center">{char.name}</h3>
                  <p className="text-emerald-400 text-sm text-center">{career.icon} {career.name}</p>
                  <p className="text-slate-400 text-xs text-center mb-2 line-clamp-2">{char.backstory}</p>
                  
                  {/* AI-Proof Rating */}
                  <div className={`text-center p-2 rounded-lg mb-2 ${
                    futureProof >= 80 ? 'bg-emerald-900/30 border border-emerald-700/50' : 
                    futureProof >= 50 ? 'bg-amber-900/30 border border-amber-700/50' : 
                    'bg-red-900/30 border border-red-700/50'}`}>
                    <div className="flex items-center justify-center gap-1">
                      <Bot size={12} />
                      <span className="text-xs font-medium">AI-Proof: {futureProof}%</span>
                    </div>
                  </div>
                  
                  <div className="text-center text-xs text-slate-500">
                    Starting: {formatMoney(DIFFICULTY_SETTINGS[selectedDifficulty].startingCash + (char.startingBonus.type === 'cash' && char.startingBonus.amount > 0 ? char.startingBonus.amount : 0))}
                    {char.startingBonus.amount < 0 && <span className="text-red-400"> + {formatMoney(Math.abs(char.startingBonus.amount))} debt</span>}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // ============================================
  // MAIN GAME SCREEN
  // ============================================
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white pb-24 md:pb-4">
      {/* Floating Numbers */}
      <AnimatePresence>
        {floatingNumbers.map(fn => (
          <FloatingNumber key={fn.id} value={fn.value} onComplete={() => setFloatingNumbers(p => p.filter(f => f.id !== fn.id))} />
        ))}
      </AnimatePresence>

      {/* Notification Toast */}
      <AnimatePresence>
        {notification && (
          <motion.div initial={{ opacity: 0, y: -50 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -50 }}
            className="fixed left-1/2 -translate-x-1/2 z-50 bg-slate-800 border border-slate-700 rounded-xl p-4 shadow-2xl w-[min(24rem,calc(100vw-2rem))]" style={{ top: 'calc(env(safe-area-inset-top) + 1rem)' }}>
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg ${
                notification.type === 'success' ? 'bg-emerald-500/20' : 
                notification.type === 'error' ? 'bg-red-500/20' : 
                notification.type === 'warning' ? 'bg-amber-500/20' : 'bg-blue-500/20'}`}>
                {notification.type === 'success' ? <CheckCircle className="text-emerald-400" size={20} /> :
                 notification.type === 'error' ? <X className="text-red-400" size={20} /> :
                 notification.type === 'warning' ? <AlertTriangle className="text-amber-400" size={20} /> :
                 <Sparkles className="text-blue-400" size={20} />}
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-white">{notification.title}</h4>
                <p className="text-slate-400 text-sm">{notification.message}</p>
              </div>
              <button onClick={() => setNotification(null)} className="text-slate-500 hover:text-white"><X size={18} /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tab Intro Video (shows only first time a user opens a tab, unless postponed) */}
      <AnimatePresence>
        {introVideoTabId && activeIntroVideoConfig && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[56] flex items-center justify-center overflow-y-auto"
            style={{
              paddingTop: 'calc(env(safe-area-inset-top) + 1rem)',
              paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)',
              paddingLeft: 'calc(env(safe-area-inset-left) + 1rem)',
              paddingRight: 'calc(env(safe-area-inset-right) + 1rem)'
            }}
            onClick={() => closeIntroVideoModal()}
            role="dialog"
            aria-modal="true"
            aria-label={`${activeIntroVideoConfig.title} intro video`}
          >
            <motion.div
              initial={{ scale: 0.98, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.98, y: 10 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              className="w-full max-w-4xl bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl overflow-y-auto"
              style={{ maxHeight: 'calc(100dvh - 2rem)' }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="sticky top-0 z-10 flex items-start justify-between gap-4 p-5 border-b border-slate-700/60 bg-slate-800/95 backdrop-blur">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    {activeIntroVideoConfig.icon}
                    {activeIntroVideoConfig.title}
                  </h2>
                  <p className="text-slate-400 text-sm mt-1">
                    {activeIntroVideoConfig.description}
                  </p>
                </div>
                <button
                  onClick={() => closeIntroVideoModal()}
                  className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-700/50"
                  aria-label="Close intro video"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-5">
                <div className="rounded-xl overflow-hidden border border-slate-700 bg-black">
                  <div style={{ aspectRatio: '16 / 9' }} className="w-full relative">
                    {/* Poster thumbnail (never steals input) */}
                    {activeIntroVideoConfig.poster && !introVideoHasStarted && (
                      <img
                        src={activeIntroVideoConfig.poster}
                        alt="Intro video thumbnail"
                        className="absolute inset-0 w-full h-full object-cover pointer-events-none select-none"
                        draggable={false}
                      />
                    )}

                    <video
                      ref={introVideoRef}
                      poster={activeIntroVideoConfig.poster}
                      className="w-full h-full object-contain bg-black"
                      playsInline
                      muted={introVideoMuted}
                      preload="metadata"
                      controls
                      onPlay={() => {
                        // If the user presses Play (native controls or our button), unmute automatically.
                        const vid = introVideoRef.current;
                        if (vid) {
                          try {
                            vid.muted = false;
                          } catch {
                            // ignore
                          }
                        }
                        setIntroVideoMuted(false);

                        // On mobile, automatically expand to fullscreen when playback starts.
                        tryEnterIntroVideoFullscreen(vid);

                        setIntroVideoIsPlaying(true);
                        setIntroVideoHasStarted(true);
                        setIntroVideoPlaybackError(null);
                      }}
                      onPause={() => setIntroVideoIsPlaying(false)}
                      onEnded={() => {
                        setIntroVideoIsPlaying(false);
                        if (introVideoTabId) {
                          setMinimizedTabVideos((prev) => ({ ...prev, [introVideoTabId]: true }));
                        }
                        closeIntroVideoModal({ remember: true });
                      }}
                      onError={() => {
                        const vid = introVideoRef.current;
                        const code = vid?.error?.code;
                        const codeLabel = code === 1
                          ? 'MEDIA_ERR_ABORTED'
                          : code === 2
                            ? 'MEDIA_ERR_NETWORK'
                            : code === 3
                              ? 'MEDIA_ERR_DECODE'
                              : code === 4
                                ? 'MEDIA_ERR_SRC_NOT_SUPPORTED'
                                : code
                                  ? `MEDIA_ERR_${code}`
                                  : '';
                        setIntroVideoPlaybackError(codeLabel ? `Video error: ${codeLabel}` : 'Video failed to load.');
                        setIntroVideoIsPlaying(false);
                      }}
                    >
                      <source src={activeIntroVideoConfig.src} type="video/mp4" />
                    </video>
                  </div>
                </div>

                {/* Always-visible playback controls */}
                <div className="mt-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={toggleIntroVideoPlayback}
                      className="px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white text-sm font-semibold flex items-center gap-2"
                    >
                      {introVideoIsPlaying ? <Pause size={16} /> : <Play size={16} />}
                      {introVideoIsPlaying ? 'Pause' : 'Play'}
                    </button>
                    <button
                      onClick={() => {
                        setIntroVideoMuted((m) => {
                          const next = !m;
                          const vid = introVideoRef.current;
                          if (vid) vid.muted = next;
                          return next;
                        });
                      }}
                      className="px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white text-sm font-semibold"
                    >
                      {introVideoMuted ? 'Unmute' : 'Mute'}
                    </button>
                  </div>

                  <div className="text-xs text-slate-500">
                    Tap Play — sound will turn on.
                  </div>
                </div>

                {introVideoPlaybackError && (
                  <div className="mt-3 rounded-xl border border-red-700/30 bg-red-950/30 p-3">
                    <p className="text-red-200 font-semibold text-sm">Video couldn&apos;t start.</p>
                    <p className="text-red-200/80 text-xs mt-1 break-words">
                      {introVideoPlaybackError}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <button
                        onClick={() => void requestIntroVideoPlayback()}
                        className="px-3 py-2 rounded-lg bg-red-500/20 hover:bg-red-500/25 border border-red-500/30 text-red-100 text-xs font-semibold"
                      >
                        Try again
                      </button>
                      <button
                        onClick={() => {
                          try {
                            window.open(activeIntroVideoConfig.src, '_blank', 'noopener,noreferrer');
                          } catch {
                            // ignore
                          }
                        }}
                        className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold"
                      >
                        Open video
                      </button>
                    </div>
                  </div>
                )}

                {/* Action buttons */}
                <div className="mt-5 flex flex-col gap-2">
                  <motion.button
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => {
                      closeIntroVideoModal({ remember: true });
                      if (activeIntroVideoConfig.continueToTab) {
                        setActiveTab(activeIntroVideoConfig.continueToTab);
                      }
                    }}
                    className="w-full px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold"
                  >
                    {activeIntroVideoConfig.continueLabel || 'Continue'}
                  </motion.button>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      onClick={() => closeIntroVideoModal({ remember: false })}
                      className="px-4 py-3 rounded-xl bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white font-semibold"
                    >
                      Show later
                    </button>
                    <button
                      onClick={() => closeIntroVideoModal({ remember: true })}
                      className="px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 font-semibold"
                    >
                      Don&apos;t show again
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirmation Dialog (prevents costly mis-clicks) */}
      <AnimatePresence>
        {confirmDialog && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[70] flex items-center justify-center"
            style={{
              paddingTop: 'calc(env(safe-area-inset-top) + 1rem)',
              paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)',
              paddingLeft: 'calc(env(safe-area-inset-left) + 1rem)',
              paddingRight: 'calc(env(safe-area-inset-right) + 1rem)'
            }}
            onClick={closeConfirmDialog}
            role="dialog"
            aria-modal="true"
            aria-label="Confirmation"
          >
            <motion.div
              initial={{ scale: 0.98, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.98, y: 10 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              className="w-full max-w-lg bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden"
              style={{ maxHeight: 'calc(100dvh - 2rem)' }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between gap-4 p-5 border-b border-slate-700/60">
                <div>
                  <h2 className="text-lg font-bold text-white">{confirmDialog.title}</h2>
                  <p className="text-slate-400 text-sm mt-1">{confirmDialog.description}</p>
                </div>
                <button
                  onClick={closeConfirmDialog}
                  className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-700/50"
                  aria-label="Close confirmation"
                >
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                {confirmDialog.details && confirmDialog.details.length > 0 && (
                  <div className="rounded-xl border border-slate-700 bg-slate-900/40 p-4">
                    <div className="space-y-2">
                      {confirmDialog.details.map((d) => (
                        <div key={d.label} className="flex items-center justify-between gap-3 text-sm">
                          <span className="text-slate-300">{d.label}</span>
                          <span className="text-slate-200 font-semibold text-right">{d.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={() => {
                      const onCancel = confirmDialog.onCancel;
                      closeConfirmDialog();
                      onCancel?.();
                    }}
                    className="w-full sm:w-auto px-4 py-3 rounded-xl bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white font-semibold"
                  >
                    {confirmDialog.cancelLabel || 'Cancel'}
                  </button>
                  <button
                    onClick={() => {
                      const onConfirm = confirmDialog.onConfirm;
                      closeConfirmDialog();
                      onConfirm();
                    }}
                    className={`w-full sm:flex-1 px-4 py-3 rounded-xl text-white font-semibold ${
                      confirmDialog.danger
                        ? 'bg-red-600 hover:bg-red-500'
                        : 'bg-emerald-600 hover:bg-emerald-500'
                    }`}
                  >
                    {confirmDialog.confirmLabel}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Accessibility Settings */}
      <AnimatePresence>
        {showAccessibility && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[65] flex items-center justify-center"
            style={{
              paddingTop: 'calc(env(safe-area-inset-top) + 1rem)',
              paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)',
              paddingLeft: 'calc(env(safe-area-inset-left) + 1rem)',
              paddingRight: 'calc(env(safe-area-inset-right) + 1rem)'
            }}
            onClick={() => setShowAccessibility(false)}
            role="dialog"
            aria-modal="true"
            aria-label="Accessibility settings"
          >
            <motion.div
              initial={{ scale: 0.98, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.98, y: 10 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              className="w-full max-w-lg bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden"
              style={{ maxHeight: 'calc(100dvh - 2rem)' }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between gap-4 p-5 border-b border-slate-700/60">
                <div>
                  <h2 className="text-lg font-bold text-white">Accessibility</h2>
                  <p className="text-slate-400 text-sm mt-1">Adjust text size and contrast for better readability.</p>
                </div>
                <button
                  onClick={() => setShowAccessibility(false)}
                  className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-700/50"
                  aria-label="Close accessibility settings"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-5 space-y-4">
                <label className="flex items-start gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={accessibilityPrefs.largeText}
                    onChange={(e) => setAccessibilityPrefs((p) => ({ ...p, largeText: e.target.checked }))}
                    className="mt-1"
                  />
                  <div>
                    <div className="text-white font-semibold">Larger text</div>
                    <div className="text-slate-400 text-sm">Scales the UI up for easier reading.</div>
                  </div>
                </label>

                <label className="flex items-start gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={accessibilityPrefs.highContrast}
                    onChange={(e) => setAccessibilityPrefs((p) => ({ ...p, highContrast: e.target.checked }))}
                    className="mt-1"
                  />
                  <div>
                    <div className="text-white font-semibold">High contrast</div>
                    <div className="text-slate-400 text-sm">Brightens text and UI accents for improved contrast.</div>
                  </div>
                </label>

                <div className="pt-2 flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={() => setAccessibilityPrefs({ largeText: false, highContrast: false })}
                    className="w-full sm:w-auto px-4 py-3 rounded-xl bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white font-semibold"
                  >
                    Reset
                  </button>
                  <button
                    onClick={() => setShowAccessibility(false)}
                    className="w-full sm:flex-1 px-4 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold"
                  >
                    Done
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Next Month Preview (Step 10) */}
      <AnimatePresence>
        {showTurnPreview && turnPreview && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={closeTurnPreview}
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.98, y: 10 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              className="bg-slate-800 border border-slate-700 rounded-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
              role="dialog"
              aria-modal="true"
              aria-label="Next Month preview"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white">📅 Next Month Preview</h2>
                  <p className="text-slate-400 text-sm">
                    Year {turnPreview.nextYear} • Month {turnPreview.monthOfYear} (estimated)
                  </p>
                </div>
                <button
                  onClick={closeTurnPreview}
                  className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-700/50"
                  aria-label="Close preview"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5">
                <div className="bg-slate-900/40 border border-slate-700 rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-emerald-300">Income</h3>
                    <span className="text-xs text-slate-400">Top sources</span>
                  </div>
                  <div className="mt-3 space-y-2">
                    {turnPreview.incomeLines.slice(0, 5).map((l) => (
                      <div key={l.label} className="flex items-center justify-between text-sm">
                        <span className="text-slate-300">{l.label}</span>
                        <span className="text-emerald-200 font-medium">{formatMoneyFull(l.value)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-700 flex items-center justify-between">
                    <span className="text-xs text-slate-400">Estimated total</span>
                    <span className="text-sm font-bold text-emerald-300">{formatMoneyFull(turnPreview.income)}</span>
                  </div>
                </div>

                <div className="bg-slate-900/40 border border-slate-700 rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-amber-300">Expenses</h3>
                    <span className="text-xs text-slate-400">Top drivers</span>
                  </div>
                  <div className="mt-3 space-y-2">
                    {turnPreview.expenseLines.slice(0, 5).map((l) => (
                      <div key={l.label} className="flex items-center justify-between text-sm">
                        <span className="text-slate-300">{l.label}</span>
                        <span className="text-amber-200 font-medium">{formatMoneyFull(l.value)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-700 flex items-center justify-between">
                    <span className="text-xs text-slate-400">Estimated total</span>
                    <span className="text-sm font-bold text-amber-300">{formatMoneyFull(turnPreview.expenses)}</span>
                  </div>
                </div>
              </div>

              <div className={`mt-4 p-4 rounded-xl border ${
                turnPreview.warningLevel === 'SHORTFALL' ? 'bg-red-900/20 border-red-700/40' :
                turnPreview.warningLevel === 'LOW_BUFFER' ? 'bg-amber-900/20 border-amber-700/40' :
                'bg-emerald-900/10 border-emerald-700/30'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-slate-300">Projected cash change</div>
                  <div className={`text-sm font-bold flex items-center gap-1 ${turnPreview.netChange >= 0 ? 'text-emerald-300' : 'text-red-300'}`}>
                    {turnPreview.netChange >= 0 ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                    {turnPreview.netChange >= 0 ? '+' : '-'}{formatMoneyFull(Math.abs(turnPreview.netChange))}
                  </div>
                </div>

                <div className="flex items-center justify-between mt-2">
                  <div className="text-sm text-slate-300">Projected end cash</div>
                  <div className="text-sm font-bold text-white">
                    {formatMoneyFull(Math.max(0, turnPreview.projectedEndCash))}
                  </div>
                </div>

                {turnPreview.warningLevel === 'SHORTFALL' && (
                  <div className="mt-3 text-sm text-red-200 flex items-start gap-2">
                    <AlertTriangle size={18} className="mt-0.5" />
                    <div>
                      <div className="font-semibold">Projected shortfall: {formatMoneyFull(turnPreview.shortfall)}</div>
                      <div className="text-xs text-red-200/90 mt-1">
                        You may miss payments and take a credit hit. Consider lowering lifestyle, selling an asset, or using a Monthly Action (Overtime / Hustle Sprint).
                      </div>
                    </div>
                  </div>
                )}

                {turnPreview.warningLevel === 'LOW_BUFFER' && (
                  <div className="mt-3 text-sm text-amber-200 flex items-start gap-2">
                    <AlertTriangle size={18} className="mt-0.5" />
                    <div>
                      <div className="font-semibold">Low buffer</div>
                      <div className="text-xs text-amber-200/90 mt-1">
                        One bad event could push you into delinquency. Consider building a 1–3 month cash reserve.
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Coach Actions (Step 11): jump to fixes before advancing */}
              {(turnPreview.warningLevel === 'SHORTFALL' || turnPreview.warningLevel === 'LOW_BUFFER') && (
                <div className="mt-4 bg-slate-900/30 border border-slate-700/50 rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                      <Sparkles size={16} className="text-amber-400" /> Quick Fixes
                    </h3>
                    <span className="text-xs text-slate-400">Before advancing</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Jump straight to the right place (or use a Monthly Action) to reduce cashflow risk.
                  </p>

                  {(() => {
                    const max = gameState.monthlyActionsMax ?? 2;
                    const remaining = (typeof gameState.monthlyActionsRemaining === 'number') ? gameState.monthlyActionsRemaining : max;
                    const locked = isProcessing || !!gameState.pendingScenario || !!gameState.hasWon || !!gameState.isBankrupt;
                    const energy = gameState.stats?.energy ?? 0;
                    const tooDrained = energy < 20;
                    const canUseAction = !locked && remaining > 0 && !tooDrained;
                    const hasHustle = (gameState.activeSideHustles || []).length > 0;
                    const canLowerLifestyle = gameState.lifestyle !== 'FRUGAL';
                    const hasAssets = (gameState.assets || []).length > 0;
                    const showLoan = turnPreview.warningLevel === 'SHORTFALL';

                    const btnBase = 'w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3';
                    const btnEnabled = 'bg-slate-800/40 border-slate-700 hover:border-emerald-500/40 hover:bg-slate-800/60';
                    const btnDisabled = 'bg-slate-900/20 border-slate-700/50 text-slate-500 cursor-not-allowed';

                    const goTo = (tabId: string, tipTitle: string, tipMessage: string, tipType: string = 'info') => {
                      playClick();
                      hideTurnPreview();
                      setActiveTab(tabId);
                      showNotif(tipTitle, tipMessage, tipType);

                      // Step 12: on-tab coach ribbon + section highlight
                      const target: CoachTarget | undefined =
                        tabId === 'lifestyle' ? 'lifestyle-grid' :
                        tabId === 'assets' ? 'assets-sell' :
                        tabId === 'sidehustle' ? 'sidehustles-list' :
                        tabId === 'bank' ? 'bank-loans' :
                        tabId === 'overview' ? 'monthly-actions' :
                        undefined;

                      triggerCoachHint({
                        tabId,
                        title: tipTitle,
                        message: tipMessage,
                        target,
                        allowReopenPreview: true,
                      });
                    };

                    const useAction = (actionId: MonthlyActionId) => {
                      // Close preview first so effects/notifications feel immediate.
                      hideTurnPreview();
                      setActiveTab('overview');
                      triggerCoachHint({
                        tabId: 'overview',
                        title: 'Coach Tip',
                        message: actionId === 'OVERTIME'
                          ? 'Overtime applied. Re-open the preview to see the improved projection.'
                          : 'Action applied. Re-open the preview to see the updated projection.',
                        target: 'monthly-actions',
                        allowReopenPreview: true,
                      });
                      // Allow the modal to unmount before applying the action.
                      setTimeout(() => handleUseMonthlyAction(actionId), 0);
                    };

                    const overtimeDisabledReason = locked
                      ? 'Unavailable right now'
                      : remaining <= 0
                        ? 'No actions remaining'
                        : tooDrained
                          ? 'Need 20+ energy'
                          : '';

                    const sprintDisabledReason = locked
                      ? 'Unavailable right now'
                      : remaining <= 0
                        ? 'No actions remaining'
                        : tooDrained
                          ? 'Need 20+ energy'
                          : !hasHustle
                            ? 'Start a hustle first'
                            : '';

                    return (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3">
                        <motion.button
                          whileHover={{ scale: canLowerLifestyle ? 1.02 : 1 }}
                          whileTap={{ scale: canLowerLifestyle ? 0.99 : 1 }}
                          disabled={!canLowerLifestyle}
                          onClick={() => goTo('lifestyle', 'Coach Tip', 'Drop one lifestyle tier to cut monthly expenses.', 'info')}
                          className={`${btnBase} ${canLowerLifestyle ? btnEnabled : btnDisabled}`}
                        >
                          <Heart size={18} className="text-pink-300 mt-0.5" />
                          <div>
                            <p className="font-semibold text-white">Lower Lifestyle</p>
                            <p className="text-xs text-slate-400">
                              {canLowerLifestyle ? 'Reduce monthly costs (you choose the tier).' : 'Already at the lowest tier.'}
                            </p>
                          </div>
                        </motion.button>

                        <motion.button
                          whileHover={{ scale: hasAssets ? 1.02 : 1 }}
                          whileTap={{ scale: hasAssets ? 0.99 : 1 }}
                          disabled={!hasAssets}
                          onClick={() => goTo('assets', 'Coach Tip', 'Sell an asset to raise cash (watch out for underwater mortgages).', 'info')}
                          className={`${btnBase} ${hasAssets ? btnEnabled : btnDisabled}`}
                        >
                          <Wallet size={18} className="text-amber-300 mt-0.5" />
                          <div>
                            <p className="font-semibold text-white">Sell an Asset</p>
                            <p className="text-xs text-slate-400">
                              {hasAssets ? 'Convert an asset into cash to cover your buffer.' : 'No assets available to sell yet.'}
                            </p>
                          </div>
                        </motion.button>

                        <motion.button
                          whileHover={{ scale: canUseAction ? 1.02 : 1 }}
                          whileTap={{ scale: canUseAction ? 0.99 : 1 }}
                          disabled={!canUseAction}
                          onClick={() => useAction('OVERTIME')}
                          className={`${btnBase} ${canUseAction ? btnEnabled : btnDisabled}`}
                        >
                          <Clock size={18} className="text-emerald-300 mt-0.5" />
                          <div>
                            <p className="font-semibold text-white">Use Overtime</p>
                            <p className="text-xs text-slate-400">
                              {canUseAction ? 'Monthly Action: +10% salary bonus (next month).' : overtimeDisabledReason}
                            </p>
                          </div>
                        </motion.button>

                        {hasHustle ? (
                          <motion.button
                            whileHover={{ scale: (canUseAction && hasHustle) ? 1.02 : 1 }}
                            whileTap={{ scale: (canUseAction && hasHustle) ? 0.99 : 1 }}
                            disabled={!(canUseAction && hasHustle)}
                            onClick={() => useAction('HUSTLE_SPRINT')}
                            className={`${btnBase} ${(canUseAction && hasHustle) ? btnEnabled : btnDisabled}`}
                          >
                            <Zap size={18} className="text-amber-200 mt-0.5" />
                            <div>
                              <p className="font-semibold text-white">Hustle Sprint</p>
                              <p className="text-xs text-slate-400">
                                {(canUseAction && hasHustle) ? 'Monthly Action: +25% side hustle income (next month).' : sprintDisabledReason}
                              </p>
                            </div>
                          </motion.button>
                        ) : (
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.99 }}
                            onClick={() => goTo('sidehustle', 'Coach Tip', 'Start a side hustle to increase monthly income.', 'info')}
                            className={`${btnBase} ${btnEnabled}`}
                          >
                            <Coffee size={18} className="text-sky-200 mt-0.5" />
                            <div>
                              <p className="font-semibold text-white">Start a Side Hustle</p>
                              <p className="text-xs text-slate-400">Add extra income streams (energy/stress tradeoff).</p>
                            </div>
                          </motion.button>
                        )}

                        {showLoan && (
                          <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.99 }}
                            onClick={() => goTo('bank', 'Coach Warning', 'A loan can patch a shortfall fast, but increases monthly payments.', 'warning')}
                            className={`${btnBase} ${btnEnabled}`}
                          >
                            <Banknote size={18} className="text-blue-200 mt-0.5" />
                            <div>
                              <p className="font-semibold text-white">Get a Loan</p>
                              <p className="text-xs text-slate-400">Fast cash now, higher expenses later.</p>
                            </div>
                          </motion.button>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}

              <div className="mt-3 text-xs text-slate-500">
                Estimates exclude random events, taxes, and side-hustle variance. Use this as a planning snapshot.
              </div>

              <div className="mt-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <label className="flex items-center gap-2 text-xs text-slate-400 select-none">
                  <input
                    type="checkbox"
                    className="rounded border-slate-600 bg-slate-900"
                    checked={skipTurnPreview}
                    onChange={(e) => setSkipTurnPreview(e.target.checked)}
                  />
                  Don't show this again
                </label>

                <div className="flex gap-2 justify-end">
                  <button
                    onClick={closeTurnPreview}
                    className="px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 border border-slate-600 text-white"
                  >
                    Back
                  </button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={confirmTurnPreview}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold"
                  >
                    Advance Month
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Scenario Modal */}
      <AnimatePresence>
        {gameState.pendingScenario && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-slate-800 border border-slate-700 rounded-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto">
              {/* Event Image (if available) */}
              {gameState.pendingScenario.image && (
                <div
                  ref={scenarioImageContainerRef}
                  className="mb-4 -mt-2 -mx-2 overflow-hidden rounded-xl relative group cursor-zoom-in select-none bg-slate-900/50 border border-slate-700/50"
                  onClick={() => openImageLightbox(gameState.pendingScenario.image!, gameState.pendingScenario.title)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      openImageLightbox(gameState.pendingScenario.image!, gameState.pendingScenario.title);
                    }
                  }}
                  aria-label="Enlarge event image"
                >
                  <div className="w-full flex items-center justify-center p-2">
                    <motion.img
                      src={gameState.pendingScenario.image}
                      alt={gameState.pendingScenario.title}
                      className="w-full max-h-[40vh] object-contain rounded-lg"
                      initial={reduceMotion ? { opacity: 1 } : { opacity: 0, scale: 1.02 }}
                      animate={reduceMotion ? { opacity: 1 } : { opacity: 1, scale: 1 }}
                      transition={{ duration: 0.35, ease: 'easeOut' }}
                      draggable={false}
                    />
                  </div>

                  {/* Hint (always visible on mobile, hover on desktop) */}
                  <div className="absolute bottom-2 right-2 text-xs text-white/90 bg-black/40 backdrop-blur px-2 py-1 rounded-lg pointer-events-none opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                    Tap to enlarge
                  </div>
                </div>
              )}
              {!gameState.pendingScenario.image && (
                <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center text-3xl ${
                  gameState.pendingScenario.category === 'AI_DISRUPTION' ? 'bg-purple-500/20' :
                  gameState.pendingScenario.category === 'MEDICAL' ? 'bg-red-500/20' :
                  gameState.pendingScenario.category === 'FAMILY_EMERGENCY' ? 'bg-red-500/20' :
                  gameState.pendingScenario.category === 'TAX' ? 'bg-amber-500/20' :
                  gameState.pendingScenario.category === 'LEGAL' ? 'bg-orange-500/20' :
                  gameState.pendingScenario.category === 'ECONOMIC' ? 'bg-blue-500/20' :
                  gameState.pendingScenario.category === 'VEHICLE' ? 'bg-slate-500/20' :
                  gameState.pendingScenario.category === 'RELATIONSHIP' ? 'bg-pink-500/20' :
                  gameState.pendingScenario.category === 'WINDFALL' ? 'bg-yellow-500/20' :
                  gameState.pendingScenario.category === 'HOUSING' ? 'bg-cyan-500/20' : 'bg-emerald-500/20'}`}>
                  {gameState.pendingScenario.category === 'AI_DISRUPTION' ? '🤖' : 
                   gameState.pendingScenario.category === 'MEDICAL' ? '🏥' :
                   gameState.pendingScenario.category === 'FAMILY_EMERGENCY' ? '👨‍👩‍👧' :
                   gameState.pendingScenario.category === 'TAX' ? '📋' :
                   gameState.pendingScenario.category === 'LEGAL' ? '⚖️' :
                   gameState.pendingScenario.category === 'ECONOMIC' ? '📉' :
                   gameState.pendingScenario.category === 'VEHICLE' ? '🚗' :
                   gameState.pendingScenario.category === 'RELATIONSHIP' ? '💕' :
                   gameState.pendingScenario.category === 'WINDFALL' ? '🎉' :
                   gameState.pendingScenario.category === 'HOUSING' ? '🏠' : '💡'}
                </div>
              )}

              {/* Autoplay controls (kept inside the modal so desktop users don't have to hunt for the header button) */}
              {!isMultiplayer && (
                <div className="flex items-center justify-between mb-3">
                  <div className="text-xs text-slate-400 flex items-center gap-2">
                    <span
                      className={`px-2 py-1 rounded-full border ${
                        autoPlaySpeed
                          ? 'bg-amber-600/20 border-amber-500/40 text-amber-200'
                          : 'bg-slate-900/40 border-slate-700/60 text-slate-300'
                      }`}
                    >
                      {autoPlaySpeed ? 'Autoplay: ON' : 'Autoplay: OFF'}
                    </span>
                    <span className="hidden sm:inline">Press P/F to toggle</span>
                  </div>

                  <button
                    onClick={() => setAutoPlaySpeed(autoPlaySpeed ? null : 500)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 border transition-all ${
                      autoPlaySpeed
                        ? 'bg-amber-600/20 border-amber-500/40 text-amber-200 hover:bg-amber-600/30'
                        : 'bg-slate-700/50 border-slate-600 text-white hover:bg-slate-700'
                    }`}
                    title={autoPlaySpeed ? 'Stop autoplay (P/F)' : 'Start autoplay (P/F)'}
                  >
                    {autoPlaySpeed ? <Pause size={14} /> : <FastForward size={14} />}
                    {autoPlaySpeed ? 'Stop Autoplay' : 'Start Autoplay'}
                  </button>
                </div>
              )}

              <h2 className="text-2xl font-bold text-white text-center mb-2">{gameState.pendingScenario.title}</h2>
              <p className="text-slate-400 text-center mb-6">{gameState.pendingScenario.description}</p>
              <div
                ref={coachAssetsSellRef}
                className={`space-y-3 ${coachHighlight('assets-sell')}`}
              >
                {gameState.pendingScenario.options.map((opt, idx) => (
                  <motion.button key={idx} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                    onClick={() => handleScenarioChoice(idx)}
                    className="w-full p-4 bg-slate-700/50 hover:bg-slate-700 border border-slate-600 rounded-xl text-left transition-all">
                    <span className="text-white font-medium">{opt.label}</span>
                    {opt.outcome.cashChange !== 0 && opt.outcome.cashChange !== undefined && (
                      <span className={`ml-2 text-sm ${opt.outcome.cashChange >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                        ({opt.outcome.cashChange >= 0 ? '+' : ''}{formatMoney(opt.outcome.cashChange)})
                      </span>
                    )}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>


      {/* Market Special Action Modal (Buy the Dip / Panic Sell) */}
      <AnimatePresence>
        {marketSpecialAction && (
          <motion.div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[55] flex items-center justify-center p-4"
            style={{
              paddingTop: 'calc(env(safe-area-inset-top) + 1rem)',
              paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)'
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeMarketSpecialAction}
          >
            <motion.div
              className="bg-slate-900 border border-slate-700 rounded-2xl p-5 w-full max-w-2xl max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.96, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.96, y: 10 }}
              transition={{ duration: 0.16 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h3 className="text-xl font-bold text-white">{marketSpecialAction.title}</h3>
                  <p className="text-slate-300 text-sm mt-1">{marketSpecialAction.description}</p>
                </div>
                <button
                  onClick={closeMarketSpecialAction}
                  className="p-2 rounded-lg hover:bg-slate-800/60 text-slate-300 hover:text-white"
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {marketSpecialAction.type === 'BUY_DISCOUNT' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                    <div className="text-slate-300">
                      Budget: <span className="text-white font-semibold">{formatMoneyFull(marketSpecialAction.budget)}</span>
                      <span className="text-slate-400"> • Cash: {formatMoneyFull(gameState.cash)}</span>
                    </div>
                    <div className="text-slate-400">
                      Discount: <span className="text-white font-semibold">{Math.round(marketSpecialAction.discount * 100)}%</span>
                    </div>
                  </div>

                  {(() => {
                    const inflationMult = Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12);
                    const cap = Math.min(gameState.cash, marketSpecialAction.budget);

                    const deals = MARKET_ITEMS
                      .filter(i => i.type !== AssetType.SAVINGS)
                      .map(i => {
                        const base = Math.round(i.price * inflationMult);
                        const discounted = Math.max(1, Math.round(base * (1 - marketSpecialAction.discount)));
                        const singleUnit = i.type === AssetType.REAL_ESTATE || i.type === AssetType.BUSINESS;
                        const maxUnits = singleUnit ? (discounted <= cap ? 1 : 0) : Math.floor(cap / discounted);
                        return {
                          item: i,
                          base,
                          discounted,
                          singleUnit,
                          maxUnits,
                          affordable: maxUnits > 0
                        };
                      })
                      .sort((a, b) => Number(b.affordable) - Number(a.affordable) || a.discounted - b.discounted)
                      .slice(0, 18);

                    if (deals.length === 0) {
                      return (
                        <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700 text-slate-300">
                          No deals available right now.
                        </div>
                      );
                    }

                    const selected = deals.find(d => d.item.id === discountBuyItemId) || null;

                    return (
                      <>
                        <div className="grid gap-2">
                          {deals.map(d => {
                            const isSelected = discountBuyItemId === d.item.id;
                            return (
                              <button
                                key={d.item.id}
                                onClick={() => {
                                  setDiscountBuyItemId(d.item.id);
                                  if (d.singleUnit) {
                                    setDiscountBuyQuantity(1);
                                  } else {
                                    setDiscountBuyQuantity((q) => Math.min(Math.max(1, q), Math.max(1, d.maxUnits)));
                                  }
                                }}
                                className={`text-left p-3 rounded-xl border transition ${
                                  isSelected ? 'border-emerald-500 bg-emerald-500/10' : 'border-slate-700 bg-slate-800/40 hover:bg-slate-800/60'
                                }`}
                              >
                                <div className="flex items-start justify-between gap-3">
                                  <div>
                                    <div className="text-white font-semibold">{d.item.name}</div>
                                    <div className="text-xs text-slate-400 mt-0.5">{d.item.description}</div>
                                    <div className="text-xs text-slate-400 mt-1">
                                      <span className="line-through">{formatMoneyFull(d.base)}</span>
                                      <span className="ml-2 text-white font-semibold">{formatMoneyFull(d.discounted)}</span>
                                      <span className="ml-2 text-slate-400">({Math.round(marketSpecialAction.discount * 100)}% off)</span>
                                    </div>
                                  </div>
                                  <div className="text-right text-xs">
                                    <div className={`font-semibold ${d.affordable ? 'text-emerald-300' : 'text-rose-300'}`}>
                                      {d.affordable ? `Max ${d.singleUnit ? 1 : d.maxUnits}` : 'Too expensive'}
                                    </div>
                                    <div className="text-slate-400 mt-1">
                                      ~{formatMoneyFull((d.item.expectedYield * d.discounted) / 12)}/mo
                                    </div>
                                  </div>
                                </div>
                              </button>
                            );
                          })}
                        </div>

                        <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700">
                          {!selected ? (
                            <div className="text-slate-300 text-sm">Select a deal above to continue.</div>
                          ) : (
                            <div className="space-y-3">
                              <div className="flex items-center justify-between gap-3">
                                <div className="text-slate-200 font-semibold">{selected.item.name}</div>
                                {selected.singleUnit ? (
                                  <div className="text-slate-300 text-sm">Qty: <span className="text-white font-semibold">1</span></div>
                                ) : (
                                  <div className="flex items-center gap-2">
                                    <button
                                      className="w-9 h-9 rounded-lg bg-slate-700/60 hover:bg-slate-700 text-white font-bold"
                                      onClick={() => setDiscountBuyQuantity(q => Math.max(1, q - 1))}
                                      disabled={discountBuyQuantity <= 1}
                                    >
                                      −
                                    </button>
                                    <div className="min-w-[3rem] text-center text-white font-semibold">{discountBuyQuantity}</div>
                                    <button
                                      className="w-9 h-9 rounded-lg bg-slate-700/60 hover:bg-slate-700 text-white font-bold"
                                      onClick={() => setDiscountBuyQuantity(q => Math.min(selected.maxUnits, q + 1))}
                                      disabled={discountBuyQuantity >= selected.maxUnits}
                                    >
                                      +
                                    </button>
                                  </div>
                                )}
                              </div>

                              <div className="flex items-center justify-between text-sm">
                                <div className="text-slate-300">
                                  Total:
                                </div>
                                <div className="text-white font-semibold">
                                  {formatMoneyFull(selected.discounted * (selected.singleUnit ? 1 : discountBuyQuantity))}
                                </div>
                              </div>

                              <div className="flex flex-col sm:flex-row gap-2">
                                <button
                                  onClick={closeMarketSpecialAction}
                                  className="flex-1 px-4 py-3 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-white font-semibold"
                                >
                                  Cancel
                                </button>
                                <button
                                  onClick={executeDiscountBuy}
                                  className="flex-1 px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold"
                                >
                                  Buy on Sale
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </>
                    );
                  })()}
                </div>
              )}

              {marketSpecialAction.type === 'PANIC_SELL' && (
                <div className="space-y-4">
                  {(() => {
                    const assets = gameState.assets || [];
                    if (assets.length === 0) {
                      return (
                        <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700 text-slate-300">
                          You have no assets to sell.
                        </div>
                      );
                    }

                    const selectedIds = Object.entries(panicSellSelection).filter(([, v]) => !!v).map(([id]) => id);
                    const preview = (() => {
                      let net = 0;
                      for (const id of selectedIds) {
                        const a = assets.find(x => x.id === id);
                        if (!a) continue;
                        const qty = typeof a.quantity === 'number' ? a.quantity : 1;
                        const gross = a.value * qty;
                        const fireSale = Math.round(gross * (1 - marketSpecialAction.discount));

                        const mtg = a.mortgageId
                          ? (gameState.mortgages.find(m => m.id === a.mortgageId) || gameState.mortgages.find(m => m.assetId === id))
                          : gameState.mortgages.find(m => m.assetId === id);

                        if (mtg) {
                          net += Math.max(0, fireSale - mtg.balance);
                        } else {
                          net += fireSale;
                        }
                      }
                      return net;
                    })();

                    return (
                      <>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <button
                            onClick={() => {
                              const sel: Record<string, boolean> = {};
                              assets.forEach(a => { sel[a.id] = true; });
                              setPanicSellSelection(sel);
                            }}
                            className="px-4 py-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-white font-semibold"
                          >
                            Select all
                          </button>
                          <button
                            onClick={() => setPanicSellSelection({})}
                            className="px-4 py-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-white font-semibold"
                          >
                            Clear
                          </button>
                          <div className="sm:ml-auto px-4 py-2 rounded-xl bg-slate-800/40 border border-slate-700 text-slate-200">
                            Est. cash received: <span className="text-white font-semibold">{formatMoneyFull(preview)}</span>
                          </div>
                        </div>

                        <div className="grid gap-2">
                          {assets.map(a => {
                            const checked = !!panicSellSelection[a.id];
                            const qty = typeof a.quantity === 'number' ? a.quantity : 1;
                            const gross = a.value * qty;
                            const fireSale = Math.round(gross * (1 - marketSpecialAction.discount));

                            const mtg = a.mortgageId
                              ? (gameState.mortgages.find(m => m.id === a.mortgageId) || gameState.mortgages.find(m => m.assetId === a.id))
                              : gameState.mortgages.find(m => m.assetId === a.id);

                            const net = mtg ? Math.max(0, fireSale - mtg.balance) : fireSale;

                            return (
                              <label
                                key={a.id}
                                className="flex items-start gap-3 p-3 rounded-xl bg-slate-800/40 border border-slate-700 hover:bg-slate-800/60 cursor-pointer"
                              >
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={(e) => setPanicSellSelection(prev => ({ ...prev, [a.id]: e.target.checked }))}
                                  className="mt-1 w-5 h-5"
                                />
                                <div className="flex-1">
                                  <div className="text-white font-semibold">{a.name}</div>
                                  <div className="text-xs text-slate-400 mt-1">
                                    Value: {formatMoneyFull(gross)} → Fire-sale: {formatMoneyFull(fireSale)}
                                    {mtg ? ` • Mortgage: ${formatMoneyFull(mtg.balance)} • Net: ${formatMoneyFull(net)}` : ` • Net: ${formatMoneyFull(net)}`}
                                  </div>
                                </div>
                              </label>
                            );
                          })}
                        </div>

                        <div className="flex flex-col sm:flex-row gap-2">
                          <button
                            onClick={closeMarketSpecialAction}
                            className="flex-1 px-4 py-3 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-white font-semibold"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={executePanicSell}
                            disabled={selectedIds.length === 0}
                            className="flex-1 px-4 py-3 rounded-xl bg-rose-500 hover:bg-rose-600 disabled:bg-rose-500/40 text-white font-semibold"
                          >
                            Execute Fire Sale
                          </button>
                        </div>
                      </>
                    );
                  })()}
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Event Image Lightbox */}
      <AnimatePresence>
        {imageLightbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[60] flex items-center justify-center p-4"
            onClick={closeImageLightbox}
            role="dialog"
            aria-modal="true"
            aria-label="Event image preview"
          >
            <motion.div
              initial={reduceMotion ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.97, y: 8 }}
              animate={reduceMotion ? { opacity: 1, scale: 1 } : { opacity: 1, scale: 1, y: 0 }}
              exit={reduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.98, y: 8 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
              className="relative w-full max-w-5xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={closeImageLightbox}
                className="absolute -top-3 -right-3 md:top-3 md:right-3 z-10 w-10 h-10 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700 flex items-center justify-center"
                aria-label="Close image preview"
              >
                <X size={18} className="text-white" />
              </button>

              <motion.img
                src={imageLightbox.src}
                alt={imageLightbox.alt}
                className="w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl border border-slate-700"
                initial={reduceMotion ? { opacity: 1 } : { opacity: 0 }}
                animate={reduceMotion ? { opacity: 1 } : { opacity: 1 }}
                transition={{ duration: 0.35 }}
                draggable={false}
              />

              <div className="mt-3 text-center text-xs text-slate-300">
                <span className="hidden sm:inline">Click</span>
                <span className="sm:hidden">Tap</span>
                <span> outside to close</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mortgage Modal */}
      <AnimatePresence>
        {showMortgageModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-slate-800 border border-slate-700 rounded-2xl p-6 max-w-md w-full">
              <h2 className="text-xl font-bold text-white mb-2">🏠 Finance {showMortgageModal.name}</h2>
              <p className="text-slate-400 mb-4">
                Price: {formatMoneyFull(Math.round(showMortgageModal.price * Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12)))}
              </p>
              
              <div className="space-y-3 mb-4">
                {showMortgageModal.mortgageOptions?.map(optId => {
                  const opt = MORTGAGE_OPTIONS.find(o => o.id === optId);
                  if (!opt) return null;
                  const price = Math.round(showMortgageModal.price * Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12));
                  const down = Math.round(price * opt.downPaymentPercent / 100);
                  const loanAmount = price - down;
                  const rate = gameState.economy.interestRate + opt.interestRateSpread;
                  const payment = calculateLoanPayment(loanAmount, rate, opt.termYears * 12);
                  const canAfford = gameState.cash >= down;
                  
                  return (
                    <div key={optId} 
                      onClick={() => canAfford && setSelectedMortgage(optId)}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        selectedMortgage === optId ? 'border-emerald-500 bg-emerald-900/20' : 
                        canAfford ? 'border-slate-600 hover:border-slate-500' : 
                        'border-slate-700 opacity-50 cursor-not-allowed'}`}>
                      <div className="flex justify-between mb-1">
                        <span className="text-white font-medium">{opt.name}</span>
                        <span className="text-emerald-400">{formatMoney(down)} down</span>
                      </div>
                      <p className="text-slate-400 text-xs">{opt.description}</p>
                      <div className="flex justify-between text-xs mt-2">
                        <span className="text-slate-500">Rate: {formatPercent(rate)}</span>
                        <span className="text-slate-500">Payment: {formatMoney(payment)}/mo</span>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="flex gap-3">
                <button onClick={() => { setShowMortgageModal(null); setSelectedMortgage(''); }} 
                  className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-all">Cancel</button>
                <button onClick={() => handleBuyAsset(showMortgageModal, selectedMortgage)} 
                  disabled={!selectedMortgage}
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 disabled:text-slate-500 rounded-lg font-medium transition-all">
                  Get Mortgage
                </button>
              </div>
              
              <button onClick={() => handleBuyAsset(showMortgageModal)} 
                disabled={gameState.cash < Math.round(showMortgageModal.price * Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12))}
                className="w-full mt-3 py-2 bg-amber-600/20 hover:bg-amber-600/30 border border-amber-600/50 text-amber-400 rounded-lg text-sm disabled:opacity-50 disabled:cursor-not-allowed transition-all">
                Pay Full Cash ({formatMoney(Math.round(showMortgageModal.price * Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12)))})
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Win Celebration Modal */}
      <AnimatePresence>
        {gameState.hasWon && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} 
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} 
              className="bg-gradient-to-br from-amber-900/50 to-amber-800/50 border border-amber-500/50 rounded-2xl p-8 max-w-md w-full text-center">
              <motion.div animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 1, repeat: Infinity }} 
                className="text-7xl mb-4">👑</motion.div>
              <h2 className="text-4xl font-bold text-amber-400 mb-2">Financial Freedom!</h2>
              <p className="text-white mb-2">Your passive income covers {Math.round(FINANCIAL_FREEDOM_TARGET_MULTIPLIER * 100)}% of your expenses!</p>
              <p className="text-amber-300/80 text-sm mb-6 italic">
                {Math.floor(gameState.month / 12) < 5 
                  ? "🚀 Speed run champion! Did you even sleep?" 
                  : Math.floor(gameState.month / 12) < 10 
                    ? "🎯 Impressive! You beat the system faster than most!"
                    : Math.floor(gameState.month / 12) < 20
                      ? "💪 Solid performance! Your future self is sending thank-you notes."
                      : "🐢 Slow and steady wins the race! (The race was with a snail, but still!)"
                }
              </p>
              <div className="bg-black/30 rounded-xl p-4 mb-6 grid grid-cols-2 gap-4 text-sm">
                <div><p className="text-slate-400">Time</p><p className="text-white font-bold">{Math.floor(gameState.month / 12)}y {gameState.month % 12}m</p></div>
                <div><p className="text-slate-400">Net Worth</p><p className="text-emerald-400 font-bold">{formatMoney(netWorth)}</p></div>
                <div><p className="text-slate-400">Passive Income</p><p className="text-amber-400 font-bold">{formatMoney(cashFlow.passive)}/mo</p></div>
                <div><p className="text-slate-400">Expenses</p><p className="text-white font-bold">{formatMoney(cashFlow.expenses)}/mo</p></div>
              </div>
              <p className="text-slate-400 text-xs mb-4">🏆 Game Over - You escaped the rat race!</p>
              <button onClick={() => { 
                playClick();
                setAutoPlaySpeed(null);
                setGameStarted(false); 
                setShowCharacterSelect(true); 
                setMonthlyReport(null);
                setActiveTab('overview');
                setTutorialStep(0);
                setTutorialDismissed(false);
                setShowTutorial(true);
                setGameState({
                  ...INITIAL_GAME_STATE,
                  quests: { ...INITIAL_QUEST_STATE, active: [...INITIAL_QUEST_STATE.active], readyToClaim: [], completed: [], track: undefined }
                }); 
              }} 
                className="w-full py-3 bg-amber-600 hover:bg-amber-500 rounded-xl font-bold transition-all">
                🎮 Play Again
              </button>
            </motion.div>
          </motion.div>
        )}
        
        {/* Bankruptcy Modal */}
        {gameState.isBankrupt && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} 
            className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} 
              className="bg-gradient-to-br from-red-900/50 to-slate-900/50 border border-red-500/50 rounded-2xl p-8 max-w-md w-full text-center">
              <motion.div 
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-7xl mb-4"
              >💸</motion.div>
              <h2 className="text-4xl font-bold text-red-400 mb-2">BROKE!</h2>
              <p className="text-white mb-2">Your wallet has filed for emotional support.</p>
              <p className="text-slate-400 text-sm mb-4 italic">
                {Math.floor(gameState.month / 12) < 2 
                  ? "Speedrun bankruptcy! That's... actually impressive in a way? 😬"
                  : Math.floor(gameState.month / 12) < 5
                    ? "The bank called. They said 'LOL.' Then hung up. 📞"
                    : "Your credit score is now a cautionary tale told to finance students. 📚"}
              </p>
              <div className="bg-black/30 rounded-xl p-4 mb-6 text-sm">
                <p className="text-slate-400 mb-2">📊 The Damage Report</p>
                <div className="grid grid-cols-2 gap-2">
                  <div><p className="text-slate-400">Time Survived</p><p className="text-white font-bold">{Math.floor(gameState.month / 12)}y {gameState.month % 12}m</p></div>
                  <div><p className="text-slate-400">Credit Rating</p><p className="text-red-400 font-bold">{gameState.creditRating || 'N/A'} 📉</p></div>
                  <div><p className="text-slate-400">Missed Payments</p><p className="text-red-400 font-bold">{gameState.missedPayments || 0} 😅</p></div>
                  <div><p className="text-slate-400">Final Debt</p><p className="text-red-400 font-bold">{formatMoney(gameState.liabilities.reduce((s, l) => s + l.balance, 0))}</p></div>
                </div>
              </div>
              <p className="text-yellow-400 text-sm mb-4">
                💡 Pro tip: Emergency funds are like umbrellas. You never need one until you REALLY need one.
              </p>
              <button onClick={() => { 
                playClick();
                setAutoPlaySpeed(null);
                setGameStarted(false); 
                setShowCharacterSelect(true); 
                setMonthlyReport(null);
                setActiveTab('overview');
                setTutorialStep(0);
                setTutorialDismissed(false);
                setShowTutorial(true);
                setGameState({
                  ...INITIAL_GAME_STATE,
                  quests: { ...INITIAL_QUEST_STATE, active: [...INITIAL_QUEST_STATE.active], readyToClaim: [], completed: [], track: undefined }
                }); 
              }} 
                className="w-full py-3 bg-red-600 hover:bg-red-500 rounded-xl font-bold transition-all">
                🎮 Redemption Arc Time
              </button>
            </motion.div>
          </motion.div>
        )}
        
        {/* Tutorial Modal - shown for new players */}
        {gameStarted && showTutorial && !tutorialDismissed && !gameState.pendingScenario && !gameState.isBankrupt && tutorialStep < tutorialTips.length && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} 
            className="fixed inset-0 bg-black/60 z-40 flex items-end md:items-center justify-center p-4">
            <motion.div initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} 
              className="bg-gradient-to-br from-blue-900/90 to-slate-900/90 border border-blue-500/50 rounded-2xl p-6 max-w-md w-full backdrop-blur-sm">
              <div className="flex items-start gap-4">
                <div className="text-4xl">{tutorialTips[tutorialStep].title.split(' ')[0]}</div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-white mb-2">{tutorialTips[tutorialStep].title.split(' ').slice(1).join(' ')}</h3>
                  <p className="text-slate-300 text-sm mb-4">{tutorialTips[tutorialStep].message}</p>
                </div>
              </div>
              <div className="flex items-center justify-between mt-4">
                <div className="flex gap-1">
                  {tutorialTips.map((_, idx) => (
                    <div key={idx} className={`w-2 h-2 rounded-full transition-all ${idx === tutorialStep ? 'bg-blue-400' : 'bg-slate-600'}`} />
                  ))}
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => { setTutorialDismissed(true); setShowTutorial(false); }}
                    className="px-4 py-2 text-slate-400 hover:text-white text-sm transition-all"
                  >
                    Skip Tutorial
                  </button>
                  <button 
                    onClick={() => {
                      if (tutorialStep < tutorialTips.length - 1) {
                        setTutorialStep(tutorialStep + 1);
                      } else {
                        setTutorialDismissed(true);
                        setShowTutorial(false);
                      }
                    }}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-sm font-medium transition-all"
                  >
                    {tutorialStep < tutorialTips.length - 1 ? 'Next →' : 'Got it! 🎮'}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
        
        {/* Emergency Asset Sale Warning */}
        {gameState.cash <= 0 && !gameState.isBankrupt && gameState.assets.length > 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} 
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} 
              className="bg-gradient-to-br from-amber-900/50 to-red-900/50 border border-amber-500/50 rounded-2xl p-6 max-w-lg w-full">
              <div className="text-center mb-4">
                <div className="text-5xl mb-2">⚠️</div>
                <h2 className="text-2xl font-bold text-amber-400">Cash Emergency!</h2>
                <p className="text-white">You're out of cash but have assets. Sell at 50% value to survive.</p>
                <p className="text-slate-400 text-sm mt-2">Credit Rating: <span className={`font-bold ${(gameState.creditRating || 650) > 600 ? 'text-green-400' : 'text-red-400'}`}>{gameState.creditRating || 650}</span></p>
              </div>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {gameState.assets.map(asset => {
                  const emergencyValue = Math.round(asset.costBasis * 0.5 * asset.quantity);
                  const mortgage = asset.mortgageId
                    ? (gameState.mortgages.find(m => m.id === asset.mortgageId) || gameState.mortgages.find(m => m.assetId === asset.id))
                    : gameState.mortgages.find(m => m.assetId === asset.id);
                  const netValue = mortgage ? Math.max(0, emergencyValue - mortgage.balance) : emergencyValue;
                  
                  return (
                    <div key={asset.id} className="flex items-center justify-between bg-black/30 rounded-lg p-3">
                      <div>
                        <p className="text-white font-medium">{asset.name}</p>
                        <p className="text-slate-400 text-sm">Emergency Sale: {formatMoney(emergencyValue)}</p>
                        {mortgage && <p className="text-red-400 text-xs">Net after mortgage: {formatMoney(netValue)}</p>}
                      </div>
                      <button
                        onClick={() => {
                          if (netValue <= 0) {
                            showNotif('Cannot Sell', 'Asset is underwater', 'error');
                            return;
                          }
                          playWarning();
                          setGameState(prev => ({
                            ...prev,
                            cash: prev.cash + netValue,
                            assets: prev.assets.filter(a => a.id !== asset.id),
                            liabilities: prev.liabilities.filter(l => l.assetId !== asset.id),
                            mortgages: prev.mortgages.filter(m => m.assetId !== asset.id),
                            events: [{
                              id: Date.now().toString(),
                              month: prev.month,
                              title: `🔥 Emergency Sale: ${asset.name}`,
                              description: `Sold at 50% value for ${formatMoneyFull(netValue)} to avoid bankruptcy`,
                              type: 'WARNING'
                            }, ...prev.events]
                          }));
                        }}
                        disabled={netValue <= 0}
                        className={`px-4 py-2 rounded-lg font-medium ${netValue > 0 ? 'bg-amber-600 hover:bg-amber-500 text-white' : 'bg-slate-700 text-slate-500 cursor-not-allowed'}`}
                      >
                        Sell for {formatMoney(netValue)}
                      </button>
                    </div>
                  );
                })}
              </div>
              <p className="text-red-400 text-xs text-center mt-4">
                ⚠️ {3 - (gameState.missedPayments || 0)} missed payments until bankruptcy
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>


      {/* Save Manager */}
      <AnimatePresence>
        {showSaveManager && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] bg-black/70 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700">
                <div>
                  <h2 className="text-white font-bold text-lg">💾 Save & Load</h2>
                  <p className="text-slate-400 text-xs">Autosaves at the end of every month • Use slots for manual saves</p>
                </div>
                <button
                  onClick={() => setShowSaveManager(false)}
                  className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-3">
                {SAVE_SLOTS.map(slotId => {
                  const summary = saveSummaries.find(s => s.slotId === slotId);
                  const isEmpty = !summary;
                  const title = slotId === 'autosave' ? 'Autosave' : `Slot ${slotId.replace('slot', '')}`;

                  return (
                    <div key={slotId} className="bg-slate-800/60 border border-slate-700 rounded-xl p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className="text-white font-bold">{title}</p>
                            {summary?.label && slotId !== 'autosave' && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/20">
                                {summary.label}
                              </span>
                            )}
                          </div>

                          {isEmpty ? (
                            <p className="text-slate-400 text-sm mt-1">Empty</p>
                          ) : (
                            <div className="text-slate-300 text-sm mt-1 space-y-1">
                              <p className="text-slate-400 text-xs">Last saved: {formatDateTime(summary.updatedAt)}</p>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                                <div className="bg-slate-900/40 rounded-lg p-2">
                                  <p className="text-slate-500">Time</p>
                                  <p className="text-white font-medium">Y{Math.ceil((summary.month || 1) / 12)} • M{(((summary.month || 1) - 1) % 12) + 1}</p>
                                </div>
                                <div className="bg-slate-900/40 rounded-lg p-2">
                                  <p className="text-slate-500">Cash</p>
                                  <p className="text-emerald-300 font-medium">{formatMoney(summary.cash || 0)}</p>
                                </div>
                                <div className="bg-slate-900/40 rounded-lg p-2">
                                  <p className="text-slate-500">Net Worth</p>
                                  <p className="text-white font-medium">{formatMoney(summary.netWorth || 0)}</p>
                                </div>
                                <div className="bg-slate-900/40 rounded-lg p-2">
                                  <p className="text-slate-500">Passive/mo</p>
                                  <p className="text-amber-300 font-medium">{formatMoney(summary.passiveIncome || 0)}</p>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex flex-col gap-2 shrink-0">
                          <button
                            onClick={() => handleSaveToSlot(slotId)}
                            className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium flex items-center gap-2"
                          >
                            <SaveIcon size={16} /> Save
                          </button>

                          <button
                            disabled={isEmpty}
                            onClick={() => handleLoadFromSlot(slotId)}
                            className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 disabled:bg-slate-800 disabled:text-slate-500 text-white text-sm font-medium flex items-center gap-2"
                          >
                            <FolderOpenIcon size={16} /> Load
                          </button>

                          <div className="flex gap-2">
                            <button
                              disabled={slotId === 'autosave' || isEmpty}
                              onClick={() => handleRenameSlot(slotId)}
                              className="flex-1 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 disabled:text-slate-600 text-slate-200 text-xs"
                              title="Rename slot"
                            >
                              Rename
                            </button>
                            <button
                              disabled={isEmpty}
                              onClick={() => handleDeleteSlot(slotId)}
                              className="px-3 py-2 rounded-lg bg-red-600/80 hover:bg-red-600 disabled:bg-slate-900 disabled:text-slate-600 text-white text-xs flex items-center gap-1"
                              title="Delete save"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => {
                      // Hard refresh in case another tab modified saves
                      refreshSaveSummaries();
                      showNotif('Refreshed', 'Save slots refreshed', 'info');
                    }}
                    className="text-slate-400 hover:text-white text-sm"
                  >
                    Refresh
                  </button>

                  <button
                    onClick={() => setShowSaveManager(false)}
                    className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-white text-sm"
                  >
                    Close
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Header */}
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-lg border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${gameState.character?.avatarColor || 'from-slate-500 to-slate-600'} flex items-center justify-center text-xl`}>
                {gameState.character?.avatarEmoji || '👤'}
              </div>
              <div>
                <p className="text-white font-medium text-sm">{playerConfig?.name || gameState.character?.name || 'Player'}</p>
                <p className="text-slate-400 text-xs">Year {Math.ceil(gameState.month / 12)} • Month {((gameState.month - 1) % 12) + 1}</p>
              </div>
              
              {/* Multiplayer Turn Indicator */}
              {isMultiplayer && (
                <div className="bg-amber-500/20 border border-amber-500/50 rounded-lg px-3 py-1">
                  <p className="text-amber-400 text-xs font-medium">Turn {multiplayerTurnsTaken + 1}/{MULTIPLAYER_TURNS_PER_ROUND}</p>
                </div>
              )}
              
              {/* AI Disruption Indicator */}
              {gameState.aiDisruption && gameState.aiDisruption.disruptionLevel > 20 && (
                <div className={`hidden md:flex items-center gap-1 px-2 py-1 rounded-lg text-xs ${
                  aiImpact?.automationRisk === 'CRITICAL' ? 'bg-red-900/30 text-red-400' : 
                  aiImpact?.automationRisk === 'HIGH' ? 'bg-orange-900/30 text-orange-400' : 
                  'bg-amber-900/30 text-amber-400'}`}>
                  <Bot size={12} />
                  <span>AI Risk: {aiImpact?.automationRisk || 'LOW'}</span>
                </div>
              )}
            </div>
            
            {/* Desktop Stats */}
            <div className="hidden md:flex items-center gap-6">
              <div className="text-right">
                <p className="text-slate-400 text-xs">Cash</p>
                <p className="text-emerald-400 font-bold">{formatMoney(gameState.cash)}</p>
              </div>
              <div className="text-right">
                <p className="text-slate-400 text-xs">Net Worth</p>
                <p className="text-white font-bold">{formatMoney(netWorth)}</p>
              </div>
              <div className="text-right">
                <p className="text-slate-400 text-xs">Passive/mo</p>
                <p className="text-amber-400 font-bold">{formatMoney(cashFlow.passive)}</p>
              </div>
            </div>
            
            {/* Controls */}
            <div className="flex items-center gap-2">
              {onBackToMenu && !isMultiplayer && (
                <button
                  onClick={() => {
                    playClick();
                    // Ensure progress is captured before returning to menu
                    saveAdultGame(gameState, 'autosave');
                    onBackToMenu();
                  }}
                  className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-all"
                  title="Back to Menu"
                >
                  <Home size={18} />
                </button>
              )}
              {!isMultiplayer && (
                <button
                  onClick={openSaveManager}
                  className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-all"
                  title="Save / Load"
                >
                  <SaveIcon size={18} />
                </button>
              )}

              <button onClick={toggleSound} className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-all">
                {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
              </button>

              <button
                onClick={() => setShowAccessibility(true)}
                className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-all"
                title="Accessibility"
              >
                <Settings size={18} />
              </button>
              <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} 
                onClick={handleNextTurn}
                disabled={isProcessing || !!gameState.pendingScenario}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 rounded-lg font-medium flex items-center gap-2 transition-all">
                {isProcessing ? <Clock size={18} className="animate-spin" /> : <Play size={18} />}
                <span className="hidden sm:inline">Next Month</span>
              </motion.button>
              <button
                onClick={() => setAutoPlaySpeed(autoPlaySpeed ? null : 500)}
                title={autoPlaySpeed ? 'Stop autoplay (P/F)' : 'Start autoplay (P/F)'}
                aria-label={autoPlaySpeed ? 'Stop autoplay' : 'Start autoplay'}
                className={`p-2 rounded-lg transition-all ${autoPlaySpeed ? 'bg-amber-600 text-white' : 'bg-slate-700 text-slate-400 hover:text-white'}`}
              >
                {autoPlaySpeed ? <Pause size={18} /> : <FastForward size={18} />}
              </button>
            </div>
          </div>
          
          {/* Win Progress Bar */}
          <div className="mt-2">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">Financial Freedom Progress <span className="text-slate-500">(Goal: {Math.round(FINANCIAL_FREEDOM_TARGET_MULTIPLIER * 100)}%)</span></span>
              <span className="text-emerald-400">{Math.floor(winProgress)}%</span>
            </div>
            <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400" 
                animate={{ width: `${winProgress}%` }} 
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-4">
        {/* Tab Navigation */}
        <div className="sticky top-0 z-40 -mx-4 px-4 pt-[calc(env(safe-area-inset-top)+0.5rem)] pb-2 bg-slate-900/95 backdrop-blur border-b border-slate-800/70 md:static md:mx-0 md:px-0 md:pt-0 md:pb-0 md:bg-transparent md:border-b-0">
          <div className="flex gap-2 mb-3 md:mb-4 overflow-x-auto pb-2 scrollbar-hide">

          {[
            { id: 'overview', label: 'Overview', icon: LineChart },
            { id: 'invest', label: 'Invest', icon: TrendingUp },
            { id: 'assets', label: 'Portfolio', icon: Wallet },
            { id: 'bank', label: 'Bank', icon: Banknote },
            { id: 'career', label: 'Career', icon: Briefcase },
            { id: 'education', label: 'Education', icon: GraduationCap },
            { id: 'eq', label: 'Upgrade EQ', icon: HeartPulse },
            { id: 'sidehustle', label: 'Side Hustles', icon: Coffee },
            { id: 'lifestyle', label: 'Lifestyle', icon: Heart },
          ].map(tab => (
            <motion.button key={tab.id} whileTap={{ scale: 0.98 }} 
              onClick={() => { playClick(); setActiveTab(tab.id); }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all ${
                activeTab === tab.id 
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'}`}>
              <tab.icon size={18} />{tab.label}
            </motion.button>
          ))}
        
          </div>
        </div>

        {/* Coach Ribbon (Step 12) */}
        <AnimatePresence>
          {coachHint && coachHint.tabId === activeTab && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              className="mb-4 bg-slate-800/60 border border-emerald-700/30 rounded-2xl p-4"
              role="status"
              aria-live="polite"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center">
                  <Sparkles size={18} className="text-emerald-300" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-white">{coachHint.title}</p>
                      <p className="text-sm text-slate-300 mt-0.5">{coachHint.message}</p>
                    </div>
                    <button
                      onClick={() => setCoachHint(null)}
                      className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700/40"
                      aria-label="Dismiss coach tip"
                    >
                      <X size={16} />
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-3">
                    {coachHint.allowReopenPreview && (
                      <button
                        onClick={openTurnPreviewNow}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                      >
                        Re-open Preview
                      </button>
                    )}
                    <span className="text-xs text-slate-500 self-center">Tip disappears in a few seconds.</span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ============================================ */}
        {/* TAB GUIDE VIDEOS */}
        {/* ============================================ */}
        {TAB_INTRO_VIDEO_CONFIG[activeTab] && (
          <div className="mb-4">
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-900/50 border border-slate-700 flex items-center justify-center">
                  <BookOpen size={18} className="text-emerald-300" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">Tab Video</p>
                  <p className="text-xs text-slate-400">{TAB_INTRO_VIDEO_CONFIG[activeTab].title}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => openIntroVideoModal(activeTab, { autoplay: true })}
                  className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold flex items-center gap-2"
                >
                  <Play size={16} /> Watch video
                </button>

                {minimizedTabVideos[activeTab] && (
                  <button
                    onClick={() => setMinimizedTabVideos((prev) => ({ ...prev, [activeTab]: false }))}
                    className="px-3 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-sm font-semibold"
                  >
                    Hide
                  </button>
                )}
              </div>
            </div>

            <AnimatePresence>
              {minimizedTabVideos[activeTab] && (
                <motion.div
                  initial={{ opacity: 0, y: -6, height: 0 }}
                  animate={{ opacity: 1, y: 0, height: 'auto' }}
                  exit={{ opacity: 0, y: -6, height: 0 }}
                  transition={{ duration: 0.18 }}
                  className="mt-3 bg-slate-800/40 border border-slate-700/70 rounded-2xl p-3 overflow-hidden"
                >
                  <div className="flex items-center gap-3">
                    {TAB_INTRO_VIDEO_CONFIG[activeTab].poster ? (
                      <img
                        src={TAB_INTRO_VIDEO_CONFIG[activeTab].poster}
                        alt={`${TAB_INTRO_VIDEO_CONFIG[activeTab].title} video thumbnail`}
                        className="w-28 h-16 rounded-xl object-cover border border-slate-700"
                      />
                    ) : (
                      <div className="w-28 h-16 rounded-xl bg-slate-900/60 border border-slate-700 flex items-center justify-center">
                        <Play size={18} className="text-slate-300" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-white truncate">{TAB_INTRO_VIDEO_CONFIG[activeTab].title}</p>
                      <p className="text-xs text-slate-400 truncate">{TAB_INTRO_VIDEO_CONFIG[activeTab].description}</p>
                      <p className="text-xs text-slate-500 mt-1">Finished — replay anytime.</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openIntroVideoModal(activeTab, { autoplay: true })}
                        className="px-3 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-sm font-semibold flex items-center gap-2"
                      >
                        <Play size={16} /> Replay
                      </button>
                      <button
                        onClick={() => setMinimizedTabVideos((prev) => ({ ...prev, [activeTab]: false }))}
                        className="p-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200"
                        aria-label="Hide video"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* ============================================ */}
        {/* OVERVIEW TAB */}
        {/* ============================================ */}
        {activeTab === 'overview' && (
          <>
          {/* Monthly Actions */}
          <div
            ref={coachMonthlyActionsRef}
            className={`bg-slate-800/50 border border-slate-700 rounded-2xl p-5 mb-4 ${coachHighlight('monthly-actions')}`}
          >
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles className="text-amber-400" size={20} />Monthly Actions
                </h3>
                <p className="text-slate-400 text-sm mt-1">
                  Spend actions to trade time & energy for income boosts, skill growth, or recovery.
                </p>
              </div>

              {(() => {
                const max = gameState.monthlyActionsMax ?? 2;
                const remaining = (typeof gameState.monthlyActionsRemaining === 'number') ? gameState.monthlyActionsRemaining : max;
                const energy = gameState.stats?.energy ?? 0;
                const stress = gameState.stats?.stress ?? 0;
                const health = gameState.stats?.health ?? 0;
                const hasBonus = energy >= 70 && stress <= 60;
                const hasPenalty = energy < 35 || stress >= 85 || health < 30;
                const reason = hasBonus
                  ? 'Bonus: +1 action (high energy, manageable stress)'
                  : hasPenalty
                    ? 'Penalty: -1 action (low energy / high stress / low health)'
                    : 'Tip: keep energy high and stress low for more actions';
                const tooltip =
                  `Monthly Actions start at 2. +1 if Energy ≥ 70 AND Stress ≤ 60. -1 if Energy < 35 OR Stress ≥ 85 OR Health < 30. Range: 1–3. This month: Energy ${Math.round(energy)}, Stress ${Math.round(stress)}, Health ${Math.round(health)} → Max ${max}.`;

                return (
                  <div className="text-right">
                    <p className="text-slate-400 text-xs flex items-center justify-end">
                      Actions Remaining
                      <InfoTip id="actions-remaining-tip" text={tooltip} />
                    </p>
                    <p className="text-white font-bold text-xl">{remaining} / {max}</p>
                    <p className="text-slate-400 text-xs mt-1 max-w-[220px] sm:max-w-none">{reason}</p>
                  </div>
                );
              })()}
            </div>

            {/* Pending one-turn buffs */}
            <div className="flex flex-wrap gap-2 mt-3">
              {(gameState.tempSalaryBonus || 0) > 0 && (
                <span className="px-2 py-1 rounded-lg bg-emerald-600/20 text-emerald-300 text-xs border border-emerald-500/30">
                  Overtime bonus pending: +{formatMoneyFull(gameState.tempSalaryBonus || 0)} salary
                </span>
              )}
              {(gameState.tempSideHustleMultiplier || 1) > 1.01 && (
                <span className="px-2 py-1 rounded-lg bg-amber-600/20 text-amber-300 text-xs border border-amber-500/30">
                  Hustle sprint active: +{Math.round(((gameState.tempSideHustleMultiplier || 1) - 1) * 100)}% side hustle income
                </span>
              )}
              <span className="px-2 py-1 rounded-lg bg-slate-700/40 text-slate-300 text-xs border border-slate-600/40">
                Financial IQ boosts passive income up to ~5%
              </span>
            </div>

            {(() => {
              const max = gameState.monthlyActionsMax ?? 2;
              const remaining = (typeof gameState.monthlyActionsRemaining === 'number') ? gameState.monthlyActionsRemaining : max;
              const locked = isProcessing || !!gameState.pendingScenario || !!gameState.hasWon || !!gameState.isBankrupt;
              const energy = gameState.stats?.energy ?? 0;
              const tooDrained = energy < 20;
              const hasHustle = (gameState.activeSideHustles || []).length > 0;
              return (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 mt-4">
                  <motion.button
                    whileHover={{ scale: locked || remaining <= 0 || tooDrained ? 1 : 1.02 }}
                    whileTap={{ scale: locked || remaining <= 0 || tooDrained ? 1 : 0.99 }}
                    onClick={() => handleUseMonthlyAction('OVERTIME')}
                    disabled={locked || remaining <= 0 || tooDrained}
                    className={`rounded-xl p-4 border text-left transition-all ${
                      locked || remaining <= 0 || tooDrained
                        ? 'bg-slate-900/30 border-slate-700/50 text-slate-500 cursor-not-allowed'
                        : 'bg-slate-900/40 border-slate-700 hover:border-emerald-500/50 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Clock size={18} className="text-emerald-400" />
                      <div>
                        <p className="font-semibold">Work Overtime</p>
                        <p className="text-xs text-slate-400">+10% salary bonus (next month)</p>
                      </div>
                    </div>
                    <p className="text-xs mt-2">-15 energy • +12 stress</p>
                    {tooDrained && <p className="text-xs mt-1 text-red-400">Too drained (need 20+ energy)</p>}
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: locked || remaining <= 0 || gameState.cash < 100 ? 1 : 1.02 }}
                    whileTap={{ scale: locked || remaining <= 0 || gameState.cash < 100 ? 1 : 0.99 }}
                    onClick={() => handleUseMonthlyAction('NETWORK')}
                    disabled={locked || remaining <= 0 || gameState.cash < 100}
                    className={`rounded-xl p-4 border text-left transition-all ${
                      locked || remaining <= 0 || gameState.cash < 100
                        ? 'bg-slate-900/30 border-slate-700/50 text-slate-500 cursor-not-allowed'
                        : 'bg-slate-900/40 border-slate-700 hover:border-blue-500/50 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Users size={18} className="text-blue-400" />
                      <div>
                        <p className="font-semibold">Networking</p>
                        <p className="text-xs text-slate-400">+$0–$500 chance • +networking</p>
                      </div>
                    </div>
                    <p className="text-xs mt-2">Cost: $100 • +12 networking</p>
                    {gameState.cash < 100 && <p className="text-xs mt-1 text-red-400">Need $100 cash</p>}
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: locked || remaining <= 0 || tooDrained || gameState.cash < 300 ? 1 : 1.02 }}
                    whileTap={{ scale: locked || remaining <= 0 || tooDrained || gameState.cash < 300 ? 1 : 0.99 }}
                    onClick={() => handleUseMonthlyAction('TRAINING')}
                    disabled={locked || remaining <= 0 || tooDrained || gameState.cash < 300}
                    className={`rounded-xl p-4 border text-left transition-all ${
                      locked || remaining <= 0 || tooDrained || gameState.cash < 300
                        ? 'bg-slate-900/30 border-slate-700/50 text-slate-500 cursor-not-allowed'
                        : 'bg-slate-900/40 border-slate-700 hover:border-amber-500/50 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <BookOpen size={18} className="text-amber-400" />
                      <div>
                        <p className="font-semibold">Skill Training</p>
                        <p className="text-xs text-slate-400">+12 Financial IQ (stronger investing)</p>
                      </div>
                    </div>
                    <p className="text-xs mt-2">Cost: $300 • -8 energy • +4 stress</p>
                    {gameState.cash < 300 && <p className="text-xs mt-1 text-red-400">Need $300 cash</p>}
                    {tooDrained && <p className="text-xs mt-1 text-red-400">Too drained</p>}
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: locked || remaining <= 0 || tooDrained || !hasHustle ? 1 : 1.02 }}
                    whileTap={{ scale: locked || remaining <= 0 || tooDrained || !hasHustle ? 1 : 0.99 }}
                    onClick={() => handleUseMonthlyAction('HUSTLE_SPRINT')}
                    disabled={locked || remaining <= 0 || tooDrained || !hasHustle}
                    className={`rounded-xl p-4 border text-left transition-all ${
                      locked || remaining <= 0 || tooDrained || !hasHustle
                        ? 'bg-slate-900/30 border-slate-700/50 text-slate-500 cursor-not-allowed'
                        : 'bg-slate-900/40 border-slate-700 hover:border-purple-500/50 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Zap size={18} className="text-purple-400" />
                      <div>
                        <p className="font-semibold">Hustle Sprint</p>
                        <p className="text-xs text-slate-400">+25% side hustle income (next month)</p>
                      </div>
                    </div>
                    <p className="text-xs mt-2">Requires active hustle • -12 energy • +10 stress</p>
                    {!hasHustle && <p className="text-xs mt-1 text-red-400">Start a hustle first</p>}
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: locked || remaining <= 0 ? 1 : 1.02 }}
                    whileTap={{ scale: locked || remaining <= 0 ? 1 : 0.99 }}
                    onClick={() => handleUseMonthlyAction('RECOVER')}
                    disabled={locked || remaining <= 0}
                    className={`rounded-xl p-4 border text-left transition-all ${
                      locked || remaining <= 0
                        ? 'bg-slate-900/30 border-slate-700/50 text-slate-500 cursor-not-allowed'
                        : 'bg-slate-900/40 border-slate-700 hover:border-pink-500/50 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <HeartPulse size={18} className="text-pink-400" />
                      <div>
                        <p className="font-semibold">Recover</p>
                        <p className="text-xs text-slate-400">Restore energy & reduce stress</p>
                      </div>
                    </div>
                    <p className="text-xs mt-2">+18 energy • -15 stress • +4 health</p>
                  </motion.button>
                </div>
              );
            })()}
          </div>

          {/* Goals & Quests */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5 mb-4">
            {(() => {
              const questState = gameState.quests || INITIAL_QUEST_STATE;
              const activeIds = (questState.active || []).slice(0, 3);
              const readyIds = questState.readyToClaim || [];
              const readyCount = readyIds.length;
              const completedIds = questState.completed || [];
              const completedCount = completedIds.length;

              const trackLabel = questState.track === 'INVESTOR'
                ? 'Investor'
                : questState.track === 'ENTREPRENEUR'
                  ? 'Entrepreneur'
                  : questState.track === 'DEBT_CRUSHER'
                    ? 'Debt Crusher'
                    : null;

              const formatQuestValue = (info: any) => {
                if (!info) return '';
                if (info.unit === 'money') return `${formatMoneyFull(info.current)} / ${formatMoneyFull(info.target)}`;
                if (info.unit === 'months') return `${info.current.toFixed(1)} / ${info.target.toFixed(1)} months`;
                if (info.unit === 'score') return `${Math.round(info.current)} / ${Math.round(info.target)}`;
                return `${Math.round(info.current)} / ${Math.round(info.target)}`;
              };

              const formatReward = (reward: any) => {
                if (!reward) return '';
                const parts: string[] = [];
                if (typeof reward.cash === 'number' && reward.cash !== 0) {
                  parts.push(`${reward.cash >= 0 ? '+' : ''}${formatMoneyFull(Math.abs(reward.cash))} cash`);
                }
                if (typeof reward.creditRating === 'number' && reward.creditRating !== 0) {
                  parts.push(`${reward.creditRating >= 0 ? '+' : ''}${Math.round(reward.creditRating)} credit`);
                }
                if (reward.stats) {
                  Object.entries(reward.stats).forEach(([k, v]) => {
                    if (typeof v !== 'number' || v === 0) return;
                    const pretty = k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase());
                    parts.push(`${v >= 0 ? '+' : ''}${Math.round(v)} ${pretty}`);
                  });
                }
                return parts.join(' • ');
              };

              return (
                <>
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <Trophy className="text-amber-400" size={20} />Goals & Quests
                      </h3>
                      <p className="text-slate-400 text-sm mt-1">
                        Short-term objectives with small rewards — learn the money habits that win games.
                      </p>
                    </div>
                    <div className="flex items-start gap-4">
                      {trackLabel && (
                        <div className="text-right">
                          <p className="text-slate-400 text-xs">Track</p>
                          <p className="text-white font-bold">{trackLabel}</p>
                        </div>
                      )}
                      <div className="text-right">
                        <p className="text-slate-400 text-xs">Ready</p>
                        <p className="text-white font-bold text-xl">{readyCount}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-slate-400 text-xs">Claimed</p>
                        <p className="text-white font-bold text-xl">{completedCount}</p>
                      </div>
                    </div>
                  </div>

                  {readyIds.length > 0 && (
                    <div className="mt-4">
                      <div className="flex items-center justify-between">
                        <p className="text-slate-300 text-sm font-semibold">Ready to claim</p>
                        <p className="text-slate-400 text-xs">Tap Claim to apply rewards</p>
                      </div>
                      <div className="space-y-2 mt-2">
                        {readyIds.map((id: string) => {
                          const q = getQuestById(id);
                          if (!q) return null;

                          return (
                            <div key={id} className="bg-emerald-900/20 border border-emerald-700/30 rounded-xl p-4 flex items-start justify-between gap-3">
                              <div>
                                <p className="font-semibold text-white flex items-center gap-2">
                                  <CheckCircle size={16} className="text-emerald-400" />
                                  {q.title}
                                </p>
                                <p className="text-slate-300 text-sm mt-1">{q.description}</p>
                                <p className="text-emerald-200 text-xs mt-2">🎁 Reward: {formatReward(q.reward)}</p>
                              </div>
                              <button
                                onClick={() => handleClaimQuest(id)}
                                disabled={isProcessing}
                                className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all border ${
                                  isProcessing
                                    ? 'bg-slate-900/30 border-slate-700/50 text-slate-500 cursor-not-allowed'
                                    : 'bg-emerald-600/20 border-emerald-500/40 text-emerald-200 hover:bg-emerald-600/30 hover:border-emerald-400/60'
                                }`}
                              >
                                Claim
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}


                  <div className="space-y-3 mt-4">
                    {activeIds.length === 0 && (
                      <div className="text-slate-400 text-sm">No active goals right now.</div>
                    )}

                    {activeIds.map(qid => {
                      const info = getQuestProgress(gameState, qid);
                      if (!info) return null;
                      const pct = Math.round(info.progress * 100);

                      const difficultyColor = info.quest.difficulty === 'EASY'
                        ? 'bg-emerald-600/20 text-emerald-300 border-emerald-500/30'
                        : info.quest.difficulty === 'MEDIUM'
                          ? 'bg-amber-600/20 text-amber-300 border-amber-500/30'
                          : 'bg-red-600/20 text-red-300 border-red-500/30';

                      return (
                        <div key={qid} className="bg-slate-900/40 border border-slate-700 rounded-xl p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-semibold text-white">{info.quest.title}</p>
                                <span className={`px-2 py-0.5 rounded-lg text-[11px] border ${difficultyColor}`}>
                                  {info.quest.difficulty}
                                </span>
                              </div>
                              <p className="text-slate-400 text-sm mt-1">{info.quest.description}</p>
                              {info.quest.hint && (
                                <p className="text-slate-300 text-xs mt-2">💡 {info.quest.hint}</p>
                              )}
                              <p className="text-amber-300 text-xs mt-2">🎁 Reward: {formatReward(info.quest.reward)}</p>
                            </div>
                            <div className="text-right min-w-[110px]">
                              <p className="text-slate-400 text-xs">Progress</p>
                              <p className="text-white font-bold">{pct}%</p>
                              <p className="text-slate-400 text-xs mt-1">{formatQuestValue(info)}</p>
                            </div>
                          </div>

                          <div className="h-2 bg-slate-800 rounded-full overflow-hidden mt-3">
                            <motion.div
                              className="h-full bg-gradient-to-r from-amber-600 to-emerald-400"
                              animate={{ width: `${pct}%` }}
                              transition={{ duration: 0.4 }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {completedIds.length > 0 && (
                    <details className="mt-4">
                      <summary className="cursor-pointer text-slate-300 text-sm hover:text-white transition-all">
                        View completed goals ({completedIds.length})
                      </summary>
                      <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2">
                        {completedIds.slice(-6).reverse().map(id => {
                          const q = getQuestById(id);
                          if (!q) return null;
                          return (
                            <div key={id} className="px-3 py-2 rounded-xl bg-slate-900/40 border border-slate-700 text-sm">
                              <span className="text-emerald-400">✔</span>{' '}
                              <span className="text-white font-medium">{q.title}</span>
                              <p className="text-slate-400 text-xs mt-1">{q.description}</p>
                            </div>
                          );
                        })}
                      </div>
                    </details>
                  )}
                </>
              );
            })()}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Net Worth Card */}
            <div className="bg-gradient-to-br from-emerald-900/30 to-emerald-800/20 border border-emerald-700/30 rounded-2xl p-5">
              <h3 className="text-sm text-emerald-400 mb-1">Net Worth</h3>
              <p className="text-3xl font-bold text-white mb-2">{formatMoney(netWorth)}</p>
              {monthlyReport && (
                <span className={`flex items-center gap-1 ${monthlyReport.netWorthChange >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {monthlyReport.netWorthChange >= 0 ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                  {formatMoney(Math.abs(monthlyReport.netWorthChange))}/mo
                </span>
              )}
            </div>

            {/* Cash Flow Card */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5">
              <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <DollarSign className="text-emerald-400" size={20} />Monthly Cash Flow
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Salary</span>
                  <span className="text-emerald-400">+{formatMoney(cashFlow.salary)}</span>
                </div>
                {(gameState.jobLossMonthsRemaining ?? 0) > 0 && (
                  <div className="text-xs text-amber-300 bg-amber-900/20 border border-amber-700/30 rounded-lg p-2">
                    Job loss shock: salary is paused for <span className="font-semibold">{gameState.jobLossMonthsRemaining}</span> more month{gameState.jobLossMonthsRemaining === 1 ? '' : 's'}. Emergency fund matters.
                  </div>
                )}
                {cashFlow.spouseIncome > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Spouse Income</span>
                    <span className="text-emerald-400">+{formatMoney(cashFlow.spouseIncome)}</span>
                  </div>
                )}
                {cashFlow.sideHustleIncome > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Side Hustles</span>
                    <span className="text-emerald-400">+{formatMoney(cashFlow.sideHustleIncome)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-400">Investments</span>
                  <span className="text-emerald-400">+{formatMoney(cashFlow.passive)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Lifestyle</span>
                  <span className="text-red-400">-{formatMoney(cashFlow.lifestyleCost)}</span>
                </div>
                {cashFlow.childrenExpenses > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Children</span>
                    <span className="text-red-400">-{formatMoney(cashFlow.childrenExpenses)}</span>
                  </div>
                )}
                {cashFlow.vehicleCosts > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Vehicle</span>
                    <span className="text-red-400">-{formatMoney(cashFlow.vehicleCosts)}</span>
                  </div>
                )}
                {cashFlow.debtPayments > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Debt Payments</span>
                    <span className="text-red-400">-{formatMoney(cashFlow.debtPayments)}</span>
                  </div>
                )}
                {cashFlow.educationPayment > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Education</span>
                    <span className="text-red-400">-{formatMoney(cashFlow.educationPayment)}</span>
                  </div>
                )}
                <div className="border-t border-slate-700 pt-2 flex justify-between font-bold">
                  <span>Net Cash Flow</span>
                  <span className={cashFlow.income - cashFlow.expenses >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                    {cashFlow.income - cashFlow.expenses >= 0 ? '+' : ''}{formatMoney(cashFlow.income - cashFlow.expenses)}
                  </span>
                </div>
              </div>
            </div>

            {/* AI Disruption Card */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5">
              <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <Bot className="text-purple-400" size={20} />AI Disruption
              </h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-slate-400">Disruption Level</span>
                    <span className="text-white">{(gameState.aiDisruption?.disruptionLevel || 0).toFixed(0)}%</span>
                  </div>
                  <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500 transition-all" style={{ width: `${gameState.aiDisruption?.disruptionLevel || 0}%` }} />
                  </div>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Your Career Risk</span>
                  <span className={getAIRiskColor(aiImpact?.automationRisk || 'LOW')}>{aiImpact?.automationRisk || 'LOW'}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Future-Proof Score</span>
                  <span className="text-white">{CAREER_PATHS[careerPath]?.futureProofScore || 50}%</span>
                </div>
              </div>
            </div>

            {/* Family Card */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5">
              <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <Heart className="text-pink-400" size={20} />Family
              </h3>
              {!gameState.family?.spouse && !gameState.family?.isEngaged && !gameState.family?.inRelationship ? (
                <p className="text-slate-400 text-sm">Single - romance may come your way! 💕</p>
              ) : (
                <div className="space-y-3">
                  {gameState.family?.inRelationship && !gameState.family?.isEngaged && !gameState.family?.spouse && (
                    <div className="bg-pink-500/20 rounded-lg p-2 text-center">
                      <span className="text-pink-400 font-medium">💕 In a Relationship</span>
                    </div>
                  )}
                  {gameState.family?.isEngaged && !gameState.family?.spouse && (
                    <div className="bg-pink-500/20 rounded-lg p-2 text-center">
                      <span className="text-pink-400 font-medium">💍 Engaged!</span>
                    </div>
                  )}
                  {gameState.family?.spouse && (
                    <div>
                      <p className="text-white font-medium">👫 Married to {gameState.family.spouse.name}</p>
                      <p className="text-slate-400 text-xs">
                        {CAREER_PATHS[gameState.family.spouse.careerPath]?.icon} {CAREER_PATHS[gameState.family.spouse.careerPath]?.name} • {formatMoney(gameState.family.spouse.income)}/mo
                      </p>
                    </div>
                  )}
                  {gameState.family?.children && gameState.family.children.length > 0 && (
                    <div className="border-t border-slate-700 pt-2">
                      <p className="text-slate-400 text-xs mb-2">Children ({gameState.family.children.length}):</p>
                      <div className="flex flex-wrap gap-2">
                        {gameState.family.children.map(child => {
                          const ageMonths = gameState.month - child.birthMonth;
                          const isPreBorn = ageMonths < 0;
                          return (
                            <span key={child.id} className="px-2 py-1 bg-slate-700 rounded-full text-xs text-white">
                              {isPreBorn ? '🤰 Due soon' : `👶 ${child.name}, ${child.age}y`}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
              <div className="mt-3 pt-3 border-t border-slate-700">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Fulfillment</span>
                  <span className="text-pink-400">{gameState.stats.fulfillment || 40}%</span>
                </div>
              </div>
            </div>

            {/* Economy Card */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5">
              <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <TrendingUp className={gameState.economy?.recession ? "text-red-400" : "text-blue-400"} size={20} />Economy
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Market</span>
                  <span className={gameState.economy?.marketTrend === 'BULL' || gameState.economy?.marketTrend === 'BOOM' ? 'text-emerald-400' : 
                    gameState.economy?.marketTrend === 'BEAR' || gameState.economy?.marketTrend === 'CRASH' ? 'text-red-400' : 'text-slate-300'}>
                    {gameState.economy?.marketTrend || 'STABLE'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Interest Rate</span>
                  <span className="text-white">{formatPercent(gameState.economy?.interestRate || 0.065)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Inflation</span>
                  <span className="text-amber-400">{formatPercent(gameState.economy?.inflationRate || 0.03)}</span>
                </div>
                {gameState.economy?.recession && (
                  <div className="bg-red-500/20 rounded-lg p-2 text-center mt-2">
                    <span className="text-red-400 font-medium">⚠️ RECESSION</span>
                    <p className="text-xs text-slate-400">{gameState.economy.recessionMonths} months remaining</p>
                  </div>
                )}
              </div>
            </div>

            {/* Recent Events */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-5 md:col-span-2 lg:col-span-3">
              <h3 className="text-lg font-bold text-white mb-3">📰 Recent Events</h3>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {gameState.events.length === 0 ? (
                  <p className="text-slate-500 text-sm">No events yet. Start playing!</p>
                ) : (
                  gameState.events.slice(0, 10).map(event => (
                    <div key={event.id} className="flex items-start gap-3 p-2 rounded-lg bg-slate-700/30">
                      <span className="text-slate-500 text-xs font-mono whitespace-nowrap">M{event.month}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-sm truncate">{event.title}</p>
                        <p className="text-slate-400 text-xs truncate">{event.description}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
          
          {/* Net Worth Chart - Full Width */}
          {gameState.netWorthHistory && gameState.netWorthHistory.length > 1 && (
            <div className="mt-6 bg-slate-800/50 border border-slate-700 rounded-2xl p-5">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <LineChart className="text-emerald-400" size={20} />Net Worth History
              </h3>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={gameState.netWorthHistory}>
                    <defs>
                      <linearGradient id="netWorthGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="month" 
                      stroke="#64748b" 
                      fontSize={12}
                      tickFormatter={(m) => `Y${Math.ceil(m/12)}`}
                    />
                    <YAxis 
                      stroke="#64748b" 
                      fontSize={12}
                      tickFormatter={(v) => v >= 1000000 ? `$${(v/1000000).toFixed(1)}M` : v >= 1000 ? `$${(v/1000).toFixed(0)}K` : `$${v}`}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                      labelStyle={{ color: '#94a3b8' }}
                      formatter={(value: number) => [formatMoneyFull(value), 'Net Worth']}
                      labelFormatter={(m) => `Month ${m} (Year ${Math.ceil(m/12)})`}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#10b981" 
                      strokeWidth={2}
                      fill="url(#netWorthGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
          </>
        )}

        {/* ============================================ */}
        {/* INVEST TAB */}
        {/* ============================================ */}
        {activeTab === 'invest' && (
          <div>
            {/* Filters */}
            <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
              {[
                { id: 'ALL', label: 'All' },
                { id: AssetType.SAVINGS, label: 'Savings' },
                { id: AssetType.BOND, label: 'Bonds' },
                { id: AssetType.INDEX_FUND, label: 'Index Funds' },
                { id: AssetType.STOCK, label: 'Stocks' },
                { id: AssetType.REAL_ESTATE, label: 'Real Estate' },
                { id: AssetType.BUSINESS, label: 'Business' },
                { id: AssetType.CRYPTO, label: 'Crypto' },
              ].map(f => (
                <button key={f.id} onClick={() => setInvestmentFilter(f.id)}
                  className={`px-3 py-1.5 rounded-lg text-sm whitespace-nowrap transition-all ${
                    investmentFilter === f.id 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                  {f.label}
                </button>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <p className="text-slate-400 text-sm">
                Available: {formatMoney(gameState.cash)} • {filteredInvestments.length} investments
              </p>

              <div className="flex items-center gap-2">
                <button
                  onClick={toggleBatchBuyMode}
                  className={`px-4 py-2 rounded-xl font-semibold transition ${
                    batchBuyMode ? 'bg-emerald-500 text-white hover:bg-emerald-600' : 'bg-slate-700/60 text-white hover:bg-slate-700'
                  }`}
                >
                  {batchBuyMode ? 'Batch Buy: ON' : 'Batch Buy'}
                </button>

                {batchBuyMode && (
                  <button
                    onClick={clearBatchBuyCart}
                    className="px-4 py-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-white font-semibold transition"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            {batchBuyMode && (
              <div className="mb-4 p-3 rounded-xl bg-slate-800/40 border border-slate-700 text-slate-300 text-sm">
                Set quantities on stocks, index funds, bonds, crypto, and commodities — then confirm once.
              </div>
            )}
            
            {/* Investment Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredInvestments.map((item, idx) => {
                const inflationMult = Math.pow(1 + gameState.economy.inflationRate, gameState.month / 12);
                const price = Math.round(item.price * inflationMult);
                const canAffordCash = gameState.cash >= price;
                const canMortgage = item.canMortgage && gameState.cash >= price * 0.035;
                
                return (
                  <motion.div key={item.id} 
                    initial={{ opacity: 0, y: 20 }} 
                    animate={{ opacity: 1, y: 0 }} 
                    transition={{ delay: idx * 0.02 }}
                    className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 hover:border-slate-600 transition-all">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{getAssetIcon(item.type)}</span>
                        <div>
                          <h4 className="text-white font-bold text-sm">{item.name}</h4>
                          <p className="text-slate-500 text-xs">{item.type.replace('_', ' ')}</p>
                        </div>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-xs border ${getRiskColor(item.risk)}`}>
                        {item.risk.replace('_', ' ')}
                      </span>
                    </div>
                    
                    <p className="text-slate-400 text-xs mb-2 line-clamp-2">{item.description}</p>
                    
                    {item.educationalNote && (
                      <p className="text-blue-400/70 text-xs mb-2 italic">💡 {item.educationalNote}</p>
                    )}
                    
                    <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                      <div className="bg-slate-900/50 rounded-lg p-2">
                        <p className="text-slate-500">Price</p>
                        <p className="text-white font-bold">{formatMoney(price)}</p>
                      </div>
                      <div className="bg-slate-900/50 rounded-lg p-2">
                        <p className="text-slate-500">Yield</p>
                        <p className="text-emerald-400 font-bold">{formatPercent(item.expectedYield)}/yr</p>
                      </div>
                    </div>
                    
                    {item.canMortgage ? (
                      <div className="flex gap-2">
                        <button 
                          onClick={() => { playClick(); setShowMortgageModal(item); setSelectedMortgage(''); }} 
                          disabled={!canMortgage}
                          className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
                            canMortgage 
                              ? 'bg-blue-600 hover:bg-blue-500 text-white' 
                              : 'bg-slate-700 text-slate-500 cursor-not-allowed'}`}>
                          🏦 Finance
                        </button>
                        <button 
                          onClick={() => handleBuyAsset(item)} 
                          disabled={!canAffordCash}
                          className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
                            canAffordCash 
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white' 
                              : 'bg-slate-700 text-slate-500 cursor-not-allowed'}`}>
                          💵 Cash
                        </button>
                      </div>
                    ) : batchBuyMode && isBatchBuyEligible(item) ? (
                      (() => {
                        const qty = batchBuyQuantities[item.id] || 0;
                        const lineCost = qty * price;
                        const otherCost = batchBuyCart.totalCost - lineCost;
                        const canAddOne = otherCost + (qty + 1) * price <= gameState.cash;

                        return (
                          <div className="w-full flex items-center justify-between gap-3 py-2 px-3 rounded-lg border border-slate-700 bg-slate-900/40">
                            <div className="text-left">
                              <div className="text-slate-400 text-xs">Cart</div>
                              <div className="text-white font-bold text-sm">
                                {qty}x
                                <span className="text-slate-400 font-medium ml-2">{qty > 0 ? formatMoneyFull(lineCost) : '—'}</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setBatchQty(item.id, qty - 1)}
                                disabled={qty <= 0}
                                className={`w-9 h-9 rounded-lg font-bold transition-all ${
                                  qty > 0 ? 'bg-slate-700 hover:bg-slate-600 text-white' : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                                }`}
                              >
                                −
                              </button>
                              <div className="min-w-[2.5rem] text-center text-white font-bold">{qty}</div>
                              <button
                                onClick={() => setBatchQty(item.id, qty + 1)}
                                disabled={!canAddOne}
                                className={`w-9 h-9 rounded-lg font-bold transition-all ${
                                  canAddOne ? 'bg-emerald-600 hover:bg-emerald-500 text-white' : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                                }`}
                              >
                                +
                              </button>
                            </div>
                          </div>
                        );
                      })()
                    ) : (
                      <button 
                        onClick={() => handleBuyAsset(item)} 
                        disabled={!canAffordCash}
                        className={`w-full py-2 rounded-lg font-medium transition-all ${
                          canAffordCash 
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white' 
                            : 'bg-slate-700 text-slate-500 cursor-not-allowed'}`}>
                        {canAffordCash ? `Buy ${formatMoney(price)}` : 'Insufficient Funds'}
                      </button>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* ============================================ */}
        {/* PORTFOLIO TAB */}
        {/* ============================================ */}
        {activeTab === 'assets' && (
          <div className="space-y-4">
            {/* Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
                <p className="text-slate-400 text-xs">Total Assets</p>
                <p className="text-xl font-bold text-white">{formatMoney(gameState.assets.reduce((s, a) => s + a.value * a.quantity, 0))}</p>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
                <p className="text-slate-400 text-xs">Passive Income</p>
                <p className="text-xl font-bold text-emerald-400">{formatMoney(cashFlow.passive)}/mo</p>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
                <p className="text-slate-400 text-xs">Total Debt</p>
                <p className="text-xl font-bold text-red-400">{formatMoney(gameState.liabilities.reduce((s, l) => s + l.balance, 0))}</p>
              </div>
              <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
                <p className="text-slate-400 text-xs">Positions</p>
                <p className="text-xl font-bold text-white">{gameState.assets.length}</p>
              </div>
            </div>
            
            {/* Assets List */}
            {gameState.assets.length === 0 ? (
              <div className="text-center py-16 bg-slate-800/30 rounded-2xl">
                <Wallet size={48} className="mx-auto text-slate-600 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Assets Yet</h3>
                <p className="text-slate-400 mb-4">Start building your portfolio!</p>
                <button onClick={() => setActiveTab('invest')} className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 rounded-lg font-medium transition-all">
                  Browse Investments
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <h3 className="text-lg font-bold text-white">Your Assets</h3>
                {gameState.assets.map(asset => {
                  const totalValue = asset.value * asset.quantity;
                  const totalCost = asset.costBasis * asset.quantity;
                  const profitLoss = totalValue - totalCost;
                  const profitPercent = totalCost > 0 ? ((totalValue / totalCost) - 1) * 100 : 0;
                  const mortgage = asset.mortgageId
                    ? (gameState.mortgages.find(m => m.id === asset.mortgageId) || gameState.mortgages.find(m => m.assetId === asset.id))
                    : gameState.mortgages.find(m => m.assetId === asset.id);
                  const equity = mortgage ? totalValue - mortgage.balance : totalValue;
                  
                  return (
                    <div key={asset.id} className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 hover:border-slate-600 transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-700 rounded-lg flex items-center justify-center text-2xl">
                            {getAssetIcon(asset.type)}
                          </div>
                          <div>
                            <h4 className="text-white font-bold">{asset.name}</h4>
                            <p className="text-slate-400 text-sm">{asset.quantity}x @ {formatMoney(asset.value)}</p>
                            {mortgage && (
                              <p className="text-blue-400 text-xs">Mortgage: {formatMoney(mortgage.balance)} • Equity: {formatMoney(equity)}</p>
                            )}
                          </div>
                        </div>
                        <div className="text-right flex items-center gap-4">
                          <div>
                            <p className="text-white font-bold text-lg">{formatMoney(totalValue)}</p>
                            <p className={`text-sm ${profitLoss >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                              {profitLoss >= 0 ? '+' : ''}{formatMoney(profitLoss)} ({profitPercent.toFixed(1)}%)
                            </p>
                            <p className="text-emerald-400/70 text-xs">+{formatMoney(asset.cashFlow * asset.quantity)}/mo</p>
                          </div>
                          <button
                            onClick={() => handleSellAsset(asset.id)}
                            className={`px-4 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded-lg text-sm border border-red-600/30 transition-all ${
                              coachHint && coachHint.tabId === 'assets' && coachHint.target === 'assets-sell' && activeTab === 'assets'
                                ? 'ring-2 ring-amber-400/70 animate-pulse'
                                : ''
                            }`}
                          >
                            Sell
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            
            {/* Liabilities List */}
            {gameState.liabilities.length > 0 && (
              <div className="mt-8">
                <h3 className="text-lg font-bold text-white mb-4">💳 Liabilities</h3>
                <div className="space-y-3">
                  {gameState.liabilities.map(liability => {
                    const progress = ((liability.originalBalance - liability.balance) / liability.originalBalance) * 100;
                    
                    return (
                      <div key={liability.id} className="bg-slate-800/50 border border-red-900/30 rounded-xl p-4">
                        <div className="flex justify-between mb-2">
                          <div>
                            <h4 className="text-white font-bold">{liability.name}</h4>
                            <p className="text-slate-400 text-sm">
                              {formatPercent(liability.interestRate)} APR • {formatMoney(liability.monthlyPayment)}/mo
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-red-400 font-bold">{formatMoney(liability.balance)}</p>
                            <p className="text-slate-500 text-xs">of {formatMoney(liability.originalBalance)}</p>
                          </div>
                        </div>
                        <div className="h-2 bg-slate-700 rounded-full overflow-hidden mb-3">
                          <div className="h-full bg-emerald-500 transition-all" style={{ width: `${progress}%` }} />
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => handlePayDebt(liability.id, liability.monthlyPayment)} 
                            disabled={gameState.cash < liability.monthlyPayment}
                            className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 rounded-lg text-sm transition-all">
                            Pay {formatMoney(liability.monthlyPayment)}
                          </button>
                          <button onClick={() => handlePayDebt(liability.id, liability.balance)} 
                            disabled={gameState.cash < liability.balance}
                            className="flex-1 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded-lg text-sm border border-red-600/30 disabled:opacity-50 transition-all">
                            Pay Off ({formatMoney(liability.balance)})
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================ */}
        {/* BANK TAB - LOANS */}
        {/* ============================================ */}
        {activeTab === 'bank' && (
          <div className="max-w-3xl mx-auto">
            <div className="bg-gradient-to-br from-blue-900/30 to-blue-800/20 border border-blue-700/30 rounded-2xl p-6 mb-6">
              <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
                <Banknote className="text-blue-400" />
                First National Bank
              </h2>
              <p className="text-slate-400">Get the funds you need. All loans have fixed rates and terms.</p>
              <div className="mt-4 flex gap-4 text-sm">
                <div className="bg-black/20 rounded-lg p-3">
                  <p className="text-slate-400">Base Rate</p>
                  <p className="text-xl font-bold text-white">{formatPercent(gameState.economy.interestRate)}</p>
                </div>
                <div className="bg-black/20 rounded-lg p-3">
                  <p className="text-slate-400">Your Credit</p>
                  <p className="text-xl font-bold text-emerald-400">Good</p>
                </div>
              </div>
            </div>
            
            <h3 className="text-lg font-bold text-white mb-4">Available Loans</h3>
            <div
              ref={coachBankLoansRef}
              className={`grid gap-4 ${coachHighlight('bank-loans')}`}
            >
              {LOAN_OPTIONS.map(loan => {
                const payment = calculateLoanPayment(loan.amount, loan.rate, loan.term);
                const totalCost = payment * loan.term;
                const totalInterest = totalCost - loan.amount;
                
                return (
                  <div key={loan.id} className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 hover:border-slate-600 transition-all">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="text-white font-bold text-lg">{loan.name}</h4>
                        <p className="text-slate-400 text-sm">{loan.description}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-emerald-400">{formatMoney(loan.amount)}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-2 text-sm mb-4">
                      <div className="bg-slate-900/50 rounded-lg p-2 text-center">
                        <p className="text-slate-500 text-xs">Rate</p>
                        <p className="text-white font-medium">{formatPercent(loan.rate)}</p>
                      </div>
                      <div className="bg-slate-900/50 rounded-lg p-2 text-center">
                        <p className="text-slate-500 text-xs">Term</p>
                        <p className="text-white font-medium">{loan.term} mo</p>
                      </div>
                      <div className="bg-slate-900/50 rounded-lg p-2 text-center">
                        <p className="text-slate-500 text-xs">Payment</p>
                        <p className="text-white font-medium">{formatMoney(payment)}/mo</p>
                      </div>
                      <div className="bg-slate-900/50 rounded-lg p-2 text-center">
                        <p className="text-slate-500 text-xs">Total Interest</p>
                        <p className="text-red-400 font-medium">{formatMoney(totalInterest)}</p>
                      </div>
                    </div>
                    
                    <button onClick={() => handleTakeLoan(loan)}
                      className="w-full py-3 bg-blue-600 hover:bg-blue-500 rounded-lg font-medium transition-all flex items-center justify-center gap-2">
                      <Plus size={18} />
                      Get This Loan
                    </button>
                  </div>
                );
              })}
            </div>
            
            {/* Current Debts in Bank Tab */}
            {gameState.liabilities.length > 0 && (
              <div className="mt-8">
                <h3 className="text-lg font-bold text-white mb-4">Your Current Debts</h3>
                <div className="space-y-3">
                  {gameState.liabilities.map(liability => (
                    <div key={liability.id} className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="text-white font-medium">{liability.name}</h4>
                          <p className="text-slate-400 text-sm">{formatPercent(liability.interestRate)} • {formatMoney(liability.monthlyPayment)}/mo</p>
                        </div>
                        <div className="text-right">
                          <p className="text-red-400 font-bold">{formatMoney(liability.balance)}</p>
                          <button onClick={() => handlePayDebt(liability.id, liability.balance)}
                            disabled={gameState.cash < liability.balance}
                            className="text-xs text-blue-400 hover:text-blue-300 disabled:text-slate-500 disabled:cursor-not-allowed">
                            Pay in full
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ============================================ */}
        {/* CAREER TAB */}
        {/* ============================================ */}
        {activeTab === 'career' && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-20 h-20 rounded-xl bg-gradient-to-br ${gameState.character?.avatarColor || 'from-slate-500 to-slate-600'} flex items-center justify-center text-4xl`}>
                  {CAREER_PATHS[careerPath]?.icon || '💼'}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">{gameState.career?.title || 'Unemployed'}</h2>
                  <p className="text-emerald-400">{CAREER_PATHS[careerPath]?.name || 'Unknown'}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-slate-900/50 rounded-xl p-4 text-center">
                  <p className="text-slate-400 text-sm">Monthly Salary</p>
                  <p className="text-3xl font-bold text-emerald-400">{formatMoney(cashFlow.salary)}</p>
                  {getEducationSalaryMultiplier(gameState) > 1 && (
                    <p className="text-blue-400 text-xs">+{((getEducationSalaryMultiplier(gameState) - 1) * 100).toFixed(0)}% from education</p>
                  )}
                </div>
                <div className="bg-slate-900/50 rounded-xl p-4 text-center">
                  <p className="text-slate-400 text-sm">Experience</p>
                  <p className="text-3xl font-bold text-white">
                    {gameState.career?.experience || 0}<span className="text-lg text-slate-400"> mo</span>
                  </p>
                </div>
              </div>

              {(gameState.jobLossMonthsRemaining ?? 0) > 0 && (
                <div className="p-4 rounded-xl mb-4 bg-amber-900/20 border border-amber-700/50">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle size={16} className="text-amber-400" />
                    <span className="font-medium text-amber-300">Job loss shock</span>
                  </div>
                  <p className="text-sm text-slate-200">
                    Your salary is paused for <span className="font-semibold text-white">{gameState.jobLossMonthsRemaining}</span>{' '}
                    more month{gameState.jobLossMonthsRemaining === 1 ? '' : 's'}. Use your emergency fund, reduce expenses, and avoid taking on new debt.
                  </p>
                </div>
              )}
              
              {/* AI Risk Warning */}
              <div className={`p-4 rounded-xl mb-4 ${
                (CAREER_PATHS[careerPath]?.futureProofScore || 50) >= 80 ? 'bg-emerald-900/20 border border-emerald-700/50' : 
                (CAREER_PATHS[careerPath]?.futureProofScore || 50) >= 50 ? 'bg-amber-900/20 border border-amber-700/50' : 
                'bg-red-900/20 border border-red-700/50'}`}>
                <div className="flex items-center gap-2 mb-2">
                  <Bot size={16} />
                  <span className="font-medium">AI Future-Proof Score: {CAREER_PATHS[careerPath]?.futureProofScore || 50}%</span>
                </div>
                <p className="text-sm text-slate-300">{CAREER_PATHS[careerPath]?.specialMechanic || 'Work hard and advance!'}</p>
                {aiImpact && aiImpact.salaryImpact !== 1 && (
                  <p className="text-xs text-slate-400 mt-2">
                    AI impact on salary: {aiImpact.salaryImpact > 1 ? '+' : ''}{((aiImpact.salaryImpact - 1) * 100).toFixed(0)}%
                  </p>
                )}
              </div>
              
              {/* Next Promotion */}
              <div className="bg-slate-900/30 rounded-xl p-4">
                <h4 className="text-white font-medium mb-2">📈 Career Path</h4>
                {CAREER_PATHS[careerPath]?.levels.map((level, idx) => {
                  const isCurrentLevel = (gameState.career?.level || 1) === idx + 1;
                  const isCompleted = (gameState.career?.level || 1) > idx + 1;
                  
                  return (
                    <div key={idx} className={`flex items-center gap-3 p-2 rounded-lg mb-1 ${isCurrentLevel ? 'bg-emerald-900/30' : ''}`}>
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                        isCompleted ? 'bg-emerald-500 text-white' : 
                        isCurrentLevel ? 'bg-emerald-600 text-white' : 
                        'bg-slate-700 text-slate-400'}`}>
                        {isCompleted ? '✓' : idx + 1}
                      </div>
                      <div className="flex-1">
                        <p className={`text-sm ${isCurrentLevel ? 'text-white font-medium' : 'text-slate-400'}`}>{level.title}</p>
                        <p className="text-xs text-slate-500">{formatMoney(level.baseSalary)}/mo • {level.experienceRequired} mo exp</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ============================================ */}
        {/* EDUCATION TAB */}
        {/* ============================================ */}
        {activeTab === 'education' && (
          <div className="max-w-4xl mx-auto">
            {/* Warning Banner */}
            <div className="bg-amber-900/20 border border-amber-700/50 rounded-xl p-4 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="text-amber-400" size={18} />
                <span className="font-bold text-amber-400">Education Relevance Warning</span>
              </div>
              <p className="text-slate-300 text-sm">
                Only education relevant to your career path (<strong>{CAREER_PATHS[careerPath]?.name}</strong>) will boost your salary. 
                Irrelevant degrees are a waste of time and money!
              </p>
            </div>
            
            {/* Currently Enrolled */}
            {gameState.education.currentlyEnrolled?.educationId && (
              <div className="bg-blue-900/20 border border-blue-700/50 rounded-xl p-4 mb-6">
                <h4 className="font-bold text-blue-400 mb-2">📚 Currently Enrolled</h4>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-white font-medium">
                      {EDUCATION_OPTIONS.find(e => e.id === gameState.education.currentlyEnrolled?.educationId)?.name}
                    </p>
                    <p className="text-slate-400 text-sm">
                      {gameState.education.currentlyEnrolled.monthsRemaining} months remaining
                    </p>
                  </div>
                  <div className="text-right">
                    {/* Show student loan info if exists */}
                    {gameState.liabilities.find(l => l.name?.includes('Student Loan') && l.name?.includes(
                      EDUCATION_OPTIONS.find(e => e.id === gameState.education.currentlyEnrolled?.educationId)?.name || ''
                    )) && (
                      <p className="text-amber-400 text-sm">
                        Loan: {formatMoney(gameState.liabilities.find(l => l.name?.includes('Student Loan'))?.monthlyPayment || 0)}/mo
                      </p>
                    )}
                  </div>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden mt-3">
                  <div className="h-full bg-blue-500 transition-all" style={{ 
                    width: `${100 - (gameState.education.currentlyEnrolled.monthsRemaining / (EDUCATION_OPTIONS.find(e => e.id === gameState.education.currentlyEnrolled?.educationId)?.duration || 1)) * 100}%` 
                  }} />
                </div>
              </div>
            )}
            
            {/* Completed Degrees */}
            {gameState.education.degrees.length > 0 && (
              <div className="bg-emerald-900/20 border border-emerald-700/50 rounded-xl p-4 mb-6">
                <h4 className="font-bold text-emerald-400 mb-2">🎓 Completed Degrees</h4>
                <div className="flex flex-wrap gap-2">
                  {gameState.education.degrees.map(degId => {
                    const deg = EDUCATION_OPTIONS.find(e => e.id === degId);
                    const isRelevant = deg?.relevantCareers.includes(careerPath);
                    return (
                      <span key={degId} className={`px-3 py-1 rounded-full text-sm ${
                        isRelevant ? 'bg-emerald-600/30 text-emerald-400' : 'bg-slate-700 text-slate-400'}`}>
                        {deg?.icon} {deg?.name} {isRelevant ? '✓' : '(not relevant)'}
                      </span>
                    );
                  })}
                </div>
              </div>
            )}
            
            <h3 className="text-lg font-bold text-white mb-4">Available Programs</h3>
            <div
              ref={coachLifestyleGridRef}
              className={`grid grid-cols-1 md:grid-cols-2 gap-4 ${coachHighlight('lifestyle-grid')}`}
            >
              {EDUCATION_OPTIONS.map(edu => {
                const isRelevant = edu.relevantCareers.includes(careerPath);
                const alreadyHave = gameState.education.degrees.includes(edu.id);
                const isEnrolled = !!(gameState.education.currentlyEnrolled?.educationId);
                const isExpensive = edu.cost > 20000;
                const deposit = isExpensive ? Math.round(edu.cost * 0.1) : edu.cost;
                const canAfford = gameState.cash >= deposit;
                
                // Check prerequisites
                const hasPrerequisites = !edu.requirements || edu.requirements.some(req => 
                  gameState.education.degrees.some(d => {
                    const degree = EDUCATION_OPTIONS.find(e => e.id === d);
                    return degree && degree.level === req;
                  })
                );
                
                return (
                  <div key={edu.id} className={`rounded-xl p-4 border transition-all ${
                    alreadyHave ? 'bg-slate-800/30 border-slate-700 opacity-60' :
                    !hasPrerequisites ? 'bg-slate-800/30 border-slate-700 opacity-60' :
                    isRelevant ? 'bg-emerald-900/10 border-emerald-700/50 hover:border-emerald-600/50' : 
                    'bg-slate-800/50 border-slate-700 hover:border-slate-600'}`}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{edu.icon}</span>
                        <div>
                          <h4 className="text-white font-bold">{edu.name}</h4>
                          <p className="text-slate-400 text-xs">{edu.category} • {edu.duration} months</p>
                        </div>
                      </div>
                      {alreadyHave ? (
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded text-xs">✓ Completed</span>
                      ) : isRelevant ? (
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded text-xs">✓ Relevant</span>
                      ) : (
                        <span className="px-2 py-0.5 bg-red-500/20 text-red-400 rounded text-xs">✗ Not Relevant</span>
                      )}
                    </div>
                    
                    <p className="text-slate-400 text-xs mb-2">{edu.description}</p>
                    
                    {edu.requirements && (
                      <p className={`text-xs mb-2 ${hasPrerequisites ? 'text-emerald-400' : 'text-red-400'}`}>
                        Requires: {edu.requirements.join(' or ')} degree {hasPrerequisites ? '✓' : '✗'}
                      </p>
                    )}
                    
                    <div className="flex justify-between text-xs mb-3">
                      <span className="text-slate-500">Cost: {formatMoney(edu.cost)} ({formatMoney(deposit)} deposit)</span>
                      <span className={isRelevant ? 'text-emerald-400' : 'text-slate-500'}>
                        Salary Boost: {isRelevant ? `+${((edu.salaryBoost - 1) * 100).toFixed(0)}%` : 'None'}
                      </span>
                    </div>
                    
                    <button onClick={() => handleEnrollEducation(edu)} 
                      disabled={alreadyHave || isEnrolled || !canAfford || !hasPrerequisites}
                      className={`w-full py-2 rounded-lg text-sm font-medium transition-all ${
                        alreadyHave ? 'bg-slate-700 text-slate-500 cursor-not-allowed' : 
                        !hasPrerequisites ? 'bg-slate-700 text-slate-500 cursor-not-allowed' :
                        isEnrolled ? 'bg-slate-700 text-slate-500 cursor-not-allowed' : 
                        !canAfford ? 'bg-slate-700 text-slate-500 cursor-not-allowed' :
                        isRelevant ? 'bg-emerald-600 hover:bg-emerald-500 text-white' : 
                        'bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 border border-amber-600/50'}`}>
                      {alreadyHave ? '✓ Completed' : 
                       !hasPrerequisites ? `Need ${edu.requirements?.join(' or ')} first` :
                       isEnrolled ? 'Already Enrolled' : 
                       !canAfford ? `Need ${formatMoney(deposit)} deposit` :
                       isRelevant ? 'Enroll Now' : '⚠️ Enroll (Not Recommended)'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ============================================ */}
        {/* UPGRADE EQ TAB */}
        {/* ============================================ */}
        {activeTab === 'eq' && (
          <div className="max-w-4xl mx-auto">
            <UpgradeEQTab gameState={gameState} setGameState={setGameState} />
          </div>
        )}

        {/* ============================================ */}
        {/* SIDE HUSTLES TAB */}
        {/* ============================================ */}
        {activeTab === 'sidehustle' && (
          <div className="max-w-4xl mx-auto">
            {/* Active Side Hustles */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 mb-6">
              <h3 className="font-bold text-white mb-3 flex items-center gap-2">
                <Coffee className="text-amber-400" size={20} />
                Your Active Side Hustles
              </h3>
              {gameState.activeSideHustles.length === 0 ? (
                <p className="text-slate-400 text-sm">No active side hustles. Start one below to earn extra income!</p>
              ) : (
                <div className="space-y-3">
                  {gameState.activeSideHustles.map(hustle => {
                    const aiPenalty = hustle.aiVulnerability * (gameState.aiDisruption?.disruptionLevel || 0) / 100;
                    const adjustedMin = Math.round(hustle.incomeRange.min * (1 - aiPenalty * 0.5));
                    const adjustedMax = Math.round(hustle.incomeRange.max * (1 - aiPenalty * 0.5));
                    
                    return (
                      <div key={hustle.id} className="flex items-center justify-between p-3 bg-emerald-900/20 border border-emerald-700/50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{hustle.icon}</span>
                          <div>
                            <p className="text-white font-medium">{hustle.name}</p>
                            <p className="text-emerald-400 text-sm">
                              {formatMoney(adjustedMin)}-{formatMoney(adjustedMax)}/mo
                              {aiPenalty > 0.1 && <span className="text-amber-400 ml-1">(AI impact: -{Math.round(aiPenalty * 50)}%)</span>}
                            </p>
                          </div>
                        </div>
                        <button onClick={() => handleStopSideHustle(hustle.id)} 
                          className="px-4 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded-lg text-sm border border-red-600/30 transition-all">
                          <Minus size={16} />
                        </button>
                      </div>
                    );
                  })}
                  
                  <div className="mt-4 p-3 bg-slate-700/30 rounded-lg">
                    <p className="text-sm text-slate-400">
                      Estimated monthly side hustle income: <span className="text-emerald-400 font-bold">{formatMoney(cashFlow.sideHustleIncome)}</span>
                    </p>
                  </div>
                </div>
              )}
            </div>
            
            <h3 className="text-lg font-bold text-white mb-4">Available Side Hustles</h3>
            <div
              ref={coachSideHustlesRef}
              className={`grid grid-cols-1 md:grid-cols-2 gap-4 ${coachHighlight('sidehustles-list')}`}
            >
              {SIDE_HUSTLES.map(hustle => {
                const isActive = !!gameState.activeSideHustles.find(h => h.id === hustle.id);
                const aiRisk = hustle.aiVulnerability > 0.6 ? 'HIGH' : hustle.aiVulnerability > 0.3 ? 'MEDIUM' : 'LOW';
                const canAfford = gameState.cash >= hustle.startupCost;
                const hasEducation = !hustle.requiredEducation || hustle.requiredEducation.length === 0 || 
                  hustle.requiredEducation.some(reqCat => 
                    gameState.education.degrees.some(d => EDUCATION_OPTIONS.find(e => e.id === d)?.category === reqCat)
                  );
                
                return (
                  <div key={hustle.id} className={`rounded-xl p-4 border transition-all ${
                    isActive ? 'bg-emerald-900/20 border-emerald-700/50' : 
                    'bg-slate-800/50 border-slate-700 hover:border-slate-600'}`}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{hustle.icon}</span>
                        <div>
                          <h4 className="text-white font-bold">{hustle.name}</h4>
                          <p className="text-slate-400 text-xs">{hustle.hoursPerWeek} hrs/week</p>
                        </div>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        aiRisk === 'LOW' ? 'bg-emerald-500/20 text-emerald-400' : 
                        aiRisk === 'MEDIUM' ? 'bg-amber-500/20 text-amber-400' : 
                        'bg-red-500/20 text-red-400'}`}>
                        AI Risk: {aiRisk}
                      </span>
                    </div>
                    
                    <p className="text-slate-400 text-xs mb-2">{hustle.description}</p>
                    
                    {hustle.requiredEducation && hustle.requiredEducation.length > 0 && (
                      <p className={`text-xs mb-2 ${hasEducation ? 'text-emerald-400' : 'text-red-400'}`}>
                        {hasEducation ? '✓' : '✗'} Requires: {hustle.requiredEducation.join(' or ')} education
                      </p>
                    )}
                    
                    <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                      <div>
                        <span className="text-slate-500">Income:</span>{' '}
                        <span className="text-emerald-400">{formatMoney(hustle.incomeRange.min)}-{formatMoney(hustle.incomeRange.max)}/mo</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Startup:</span>{' '}
                        <span className="text-white">{hustle.startupCost > 0 ? formatMoney(hustle.startupCost) : 'Free'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Energy:</span>{' '}
                        <span className="text-amber-400">-{hustle.energyCost}/mo</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Stress:</span>{' '}
                        <span className="text-red-400">+{hustle.stressIncrease}</span>
                      </div>
                    </div>
                    
                    <button onClick={() => handleStartSideHustle(hustle)} 
                      disabled={isActive || !canAfford || !hasEducation}
                      className={`w-full py-2 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                        isActive ? 'bg-emerald-600/20 text-emerald-400 cursor-not-allowed' : 
                        !canAfford ? 'bg-slate-700 text-slate-500 cursor-not-allowed' :
                        !hasEducation ? 'bg-slate-700 text-slate-500 cursor-not-allowed' :
                        'bg-emerald-600 hover:bg-emerald-500 text-white'}`}>
                      {isActive ? '✓ Active' : 
                       !canAfford ? `Need ${formatMoney(hustle.startupCost)}` :
                       !hasEducation ? 'Education Required' :
                       <><Plus size={16} /> Start Hustle</>}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ============================================ */}
        {/* LIFESTYLE TAB */}
        {/* ============================================ */}
        {activeTab === 'lifestyle' && (
          <div className="max-w-3xl mx-auto">
            <h2 className="text-xl font-bold text-white mb-4">Choose Your Lifestyle</h2>
            <p className="text-slate-400 mb-6">Your lifestyle determines your monthly expenses and happiness.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(Object.entries(LIFESTYLE_OPTS) as [Lifestyle, typeof LIFESTYLE_OPTS[Lifestyle]][]).map(([key, opt]) => (
                <motion.div key={key} whileHover={{ scale: 1.02 }} 
                  onClick={() => handleChangeLifestyle(key)}
                  className={`p-4 rounded-xl cursor-pointer transition-all ${
                    gameState.lifestyle === key 
                      ? 'bg-emerald-600/20 border-2 border-emerald-500' 
                      : 'bg-slate-800/50 border border-slate-700 hover:border-slate-600'}`}>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-3xl">{opt.icon}</span>
                    <div>
                      <h3 className="text-white font-bold capitalize">{key.toLowerCase()}</h3>
                      <p className="text-slate-400 text-sm">{opt.description}</p>
                    </div>
                  </div>
                  <div className="flex justify-between mt-3 text-sm">
                    <span className="text-slate-400">Monthly Cost:</span>
                    <span className="text-white font-medium">{formatMoney(opt.cost)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Happiness:</span>
                    <span className={opt.happiness >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                      {opt.happiness >= 0 ? '+' : ''}{opt.happiness}
                    </span>
                  </div>
                  {gameState.lifestyle === key && (
                    <div className="mt-3 text-center">
                      <span className="px-3 py-1 bg-emerald-600/30 text-emerald-400 rounded-full text-sm">Current Lifestyle</span>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
            
            {/* Stats Overview */}
            <div className="mt-8 bg-slate-800/50 border border-slate-700 rounded-xl p-4">
              <h3 className="font-bold text-white mb-4">Your Stats</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {[
                  {
                    label: 'Happiness',
                    value: gameState.stats.happiness,
                    color: 'emerald',
                    tipId: 'stat-happiness',
                    tipText:
                      'Happiness affects promotions: above ~50 increases promotion chance, below ~50 reduces it.',
                  },
                  {
                    label: 'Health',
                    value: gameState.stats.health,
                    color: 'red',
                    tipId: 'stat-health',
                    tipText:
                      'Health affects productivity: Health < 30 reduces Monthly Actions by 1. Low health also increases the chance of costly medical events.',
                  },
                  {
                    label: 'Energy',
                    value: gameState.stats.energy,
                    color: 'amber',
                    tipId: 'stat-energy',
                    tipText:
                      'Energy drives productivity: Energy < 35 reduces Monthly Actions by 1. Energy ≥ 70 and Stress ≤ 60 gives +1 Monthly Action.',
                  },
                  {
                    label: 'Stress',
                    value: gameState.stats.stress,
                    color: 'purple',
                    invert: true,
                    tipId: 'stat-stress',
                    tipText:
                      'Stress reduces promotions and productivity: above ~30 lowers promotion chance; Stress ≥ 85 reduces Monthly Actions by 1. High stress drains health over time.',
                  },
                  {
                    label: 'Networking',
                    value: gameState.stats.networking,
                    color: 'blue',
                    tipId: 'stat-networking',
                    tipText:
                      'Networking improves promotion odds. Networking actions raise this stat, helping you grow salary faster.',
                  },
                  {
                    label: 'Financial IQ',
                    value: gameState.stats.financialIQ,
                    color: 'cyan',
                    tipId: 'stat-financialiq',
                    tipText:
                      'Financial IQ boosts passive income (up to ~5%) and helps you make better investment decisions over time.',
                  },
                ].map(stat => (
                  <div key={stat.label} className="bg-slate-900/50 rounded-lg p-3">
                    <p className="text-slate-400 text-xs mb-1 flex items-center gap-1">
                      <span>{stat.label}</span>
                      <InfoTip id={stat.tipId} text={stat.tipText} />
                    </p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div className={`h-full bg-${stat.color}-500 transition-all`} 
                          style={{ width: `${stat.value}%` }} />
                      </div>
                      <span className="text-white text-sm font-medium w-8">{stat.value}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick feedback on impact */}
              <div className="mt-4 bg-slate-900/40 border border-slate-700/60 rounded-lg p-3">
                <p className="text-white text-sm font-semibold mb-1">How this impacts you</p>
                <ul className="text-slate-400 text-xs space-y-1">
                  <li>
                    • Monthly Actions: <span className="text-white font-medium">{gameState.monthlyActionsMax}</span> (energy/health/stress thresholds apply)
                  </li>
                  <li>
                    • Promotion odds are driven by Networking + Happiness − Stress (higher stats = faster salary growth)
                  </li>
                  <li>
                    • Low Health / high Stress increases the chance of expensive medical events
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Re-open Preview Pill (Step 12) */}
      <AnimatePresence>
        {showReopenPreviewPill && !showTurnPreview && !gameState.pendingScenario && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="fixed right-4 bottom-24 md:bottom-6 z-40"
          >
            <div className="bg-slate-800/90 backdrop-blur border border-slate-700 rounded-2xl shadow-2xl px-4 py-3 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center">
                <Sparkles size={16} className="text-emerald-300" />
              </div>
              <div className="leading-tight">
                <p className="text-white text-sm font-semibold">Want to re-check cashflow?</p>
                <p className="text-slate-400 text-xs">Re-open the Next Month preview.</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={openTurnPreviewNow}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                >
                  Open
                </button>
                <button
                  onClick={() => setShowReopenPreviewPill(false)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-700/40"
                  aria-label="Dismiss preview shortcut"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>


      {/* Batch Buy Cart Bar */}
      <AnimatePresence>
        {activeTab === 'invest' && batchBuyMode && batchBuyCart.totalUnits > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 16 }}
            transition={{ duration: 0.18 }}
            className="fixed left-1/2 -translate-x-1/2 bottom-[calc(env(safe-area-inset-bottom)+5.25rem)] md:bottom-6 z-[45] w-[min(42rem,calc(100vw-2rem))]"
          >
            <div
              className={`rounded-2xl border backdrop-blur px-4 py-3 flex flex-col sm:flex-row sm:items-center gap-3 ${
                batchBuyCart.canAfford ? 'bg-slate-900/90 border-slate-700' : 'bg-rose-900/30 border-rose-500/50'
              }`}
            >
              <div className="flex-1">
                <div className="text-white font-semibold">Batch Cart</div>
                <div className="text-xs text-slate-300 mt-0.5">
                  {batchBuyCart.totalUnits} units • Total {formatMoneyFull(batchBuyCart.totalCost)} • Cash {formatMoneyFull(gameState.cash)}
                </div>
                {!batchBuyCart.canAfford && (
                  <div className="text-xs text-rose-200 mt-1">
                    You&apos;re short by {formatMoneyFull(batchBuyCart.totalCost - gameState.cash)}.
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={clearBatchBuyCart}
                  className="px-4 py-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-white font-semibold transition"
                >
                  Clear
                </button>
                <button
                  onClick={openBatchBuyConfirm}
                  disabled={!batchBuyCart.canAfford}
                  className={`px-4 py-2 rounded-xl font-semibold transition ${
                    batchBuyCart.canAfford ? 'bg-emerald-500 hover:bg-emerald-600 text-white' : 'bg-slate-700 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  Review &amp; Buy
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Bottom Stats Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 px-4 py-3 z-30">
        <div className="flex justify-around">
          <div className="text-center">
            <p className="text-xs text-slate-400">Cash</p>
            <p className="text-emerald-400 font-bold">{formatMoney(gameState.cash)}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-slate-400">Net Worth</p>
            <p className="text-white font-bold">{formatMoney(netWorth)}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-slate-400">Passive</p>
            <p className="text-amber-400 font-bold">{formatMoney(cashFlow.passive)}/mo</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
