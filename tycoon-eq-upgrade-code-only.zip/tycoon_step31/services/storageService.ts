import { GameState, PrestigeData } from '../types';
import { KidsGameState } from '../kidsTypes';
import { calculateMonthlyCashFlowEstimate, calculateNetWorth, calculateMonthlyActionsMax } from './gameLogic';
import { INITIAL_QUEST_STATE } from '../constants';

const normalizeAdultState = (state: GameState): GameState => {
  // Add defaults for newer fields so older saves keep working.
  const inferredMax = calculateMonthlyActionsMax(state);
  const monthlyActionsMax = typeof (state as any).monthlyActionsMax === 'number' ? (state as any).monthlyActionsMax : inferredMax;
  const monthlyActionsRemaining = typeof (state as any).monthlyActionsRemaining === 'number'
    ? (state as any).monthlyActionsRemaining
    : monthlyActionsMax;

  // Goals / quests (Step 5+)
  const rawQuests = (state as any).quests;
  const quests = {
    active: (Array.isArray(rawQuests?.active) ? rawQuests.active.filter((id: any) => typeof id === 'string') : [...INITIAL_QUEST_STATE.active]).slice(0, 3),
    readyToClaim: Array.isArray(rawQuests?.readyToClaim) ? rawQuests.readyToClaim.filter((id: any) => typeof id === 'string') : [],
    completed: Array.isArray(rawQuests?.completed) ? rawQuests.completed.filter((id: any) => typeof id === 'string') : [],
    track: typeof rawQuests?.track === 'string' ? rawQuests.track : undefined
  };

  // Upgrade EQ defaults
  const rawEqCourse = (state as any).eqCourse;
  const eqCourse = {
    failedAttempts: typeof rawEqCourse?.failedAttempts === 'number' ? rawEqCourse.failedAttempts : 0,
    bestScore: typeof rawEqCourse?.bestScore === 'number' ? rawEqCourse.bestScore : 0,
    certified: typeof rawEqCourse?.certified === 'boolean' ? rawEqCourse.certified : false,
    rewardClaimed: typeof rawEqCourse?.rewardClaimed === 'boolean' ? rawEqCourse.rewardClaimed : false,
  };

  const rawEqPerks = (state as any).eqPerks;
  const eqPerks = {
    careerXpMultiplier: typeof rawEqPerks?.careerXpMultiplier === 'number' ? rawEqPerks.careerXpMultiplier : 1,
    careerXpCarry: typeof rawEqPerks?.careerXpCarry === 'number' ? rawEqPerks.careerXpCarry : 0,
  };

return {
    ...state,
    monthlyActionsMax,
    monthlyActionsRemaining,
    tempSalaryBonus: typeof (state as any).tempSalaryBonus === 'number' ? (state as any).tempSalaryBonus : 0,
    tempSideHustleMultiplier: typeof (state as any).tempSideHustleMultiplier === 'number' ? (state as any).tempSideHustleMultiplier : 1,
    quests,
    eqCourse,
    eqPerks
  };
};

// ============================================
// SAVE / LOAD (Single Player)
//
// v2 save schema supports:
// - Adult + Kids modes
// - 1 autosave + 3 manual slots
// - Lightweight summaries for menu + slot UI
// ============================================

export type SaveMode = 'adult' | 'kids';
export type SaveSlotId = 'autosave' | 'slot1' | 'slot2' | 'slot3';

export interface SaveSummary {
  mode: SaveMode;
  slotId: SaveSlotId;
  updatedAt: number;
  label?: string;

  // Adult metrics
  month?: number;
  year?: number;
  cash?: number;
  netWorth?: number;
  passiveIncome?: number;
  expenses?: number;

  // Kids metrics
  week?: number;
  cashOnHand?: number;
  totalEarned?: number;
  totalSaved?: number;
  savingsGoalName?: string;
  savingsGoalTarget?: number;
  savingsGoalCompleted?: boolean;
}

interface SaveEntry {
  schema: 2;
  gameVersion?: string;
  summary: SaveSummary;
  state: unknown;
}

type SaveDB = Record<string, SaveEntry>;

const SAVE_DB_KEY = 'tycoon_saves_v2';
const LEGACY_ADULT_KEY = 'tycoon_save';

const PRESTIGE_KEY = 'tycoon_prestige';

const slotOrder: SaveSlotId[] = ['autosave', 'slot1', 'slot2', 'slot3'];

const makeKey = (mode: SaveMode, slotId: SaveSlotId) => `${mode}:${slotId}`;

const safeParse = <T>(raw: string | null): T | null => {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
};

const readDBRaw = (): SaveDB => {
  try {
    const raw = localStorage.getItem(SAVE_DB_KEY);
    const parsed = safeParse<SaveDB>(raw);
    return parsed || {};
  } catch {
    return {};
  }
};

const writeDB = (db: SaveDB) => {
  try {
    localStorage.setItem(SAVE_DB_KEY, JSON.stringify(db));
  } catch (e) {
    console.error('Failed to write save database', e);
  }
};

const migrateLegacyAdultSaveIfNeeded = () => {
  try {
    const legacyRaw = localStorage.getItem(LEGACY_ADULT_KEY);
    if (!legacyRaw) return;

    const legacyStateRaw = safeParse<GameState>(legacyRaw);
    const legacyState = legacyStateRaw ? normalizeAdultState(legacyStateRaw) : null;
    if (!legacyState) {
      // If it cannot parse, just remove to prevent repeated attempts
      localStorage.removeItem(LEGACY_ADULT_KEY);
      return;
    }

    const db = readDBRaw();
    const key = makeKey('adult', 'autosave');

    // Only migrate if autosave doesn't already exist
    if (!db[key]) {
      db[key] = {
        schema: 2,
        gameVersion: '3.4.3',
        summary: buildAdultSummary(legacyState, 'autosave', 'Autosave', Date.now()),
        state: legacyState,
      };
      writeDB(db);
    }

    localStorage.removeItem(LEGACY_ADULT_KEY);
  } catch (e) {
    console.error('Failed to migrate legacy save', e);
  }
};

const buildAdultSummary = (
  state: GameState,
  slotId: SaveSlotId,
  label: string | undefined,
  updatedAt: number
): SaveSummary => {
  const cashFlow = calculateMonthlyCashFlowEstimate(state);
  const netWorth = calculateNetWorth(state);

  return {
    mode: 'adult',
    slotId,
    updatedAt,
    label,
    month: state.month,
    year: state.year,
    cash: state.cash,
    netWorth,
    passiveIncome: cashFlow.passive,
    expenses: cashFlow.expenses,
  };
};

const buildKidsSummary = (
  state: KidsGameState,
  slotId: SaveSlotId,
  label: string | undefined,
  updatedAt: number
): SaveSummary => {
  return {
    mode: 'kids',
    slotId,
    updatedAt,
    label,
    week: state.week,
    cashOnHand: state.cash,
    totalEarned: state.totalEarned,
    totalSaved: state.totalSaved,
    savingsGoalName: state.savingsGoal?.name,
    savingsGoalTarget: state.savingsGoal?.targetAmount,
    savingsGoalCompleted: state.savingsGoal?.completed,
  };
};

// ============================================
// Public API
// ============================================

export const saveAdultGame = (state: GameState, slotId: SaveSlotId = 'autosave', label?: string): void => {
  migrateLegacyAdultSaveIfNeeded();

  try {
    const db = readDBRaw();
    const key = makeKey('adult', slotId);
    const updatedAt = Date.now();

    const existingLabel = db[key]?.summary?.label;
    const finalLabel = slotId === 'autosave' ? 'Autosave' : (label ?? existingLabel ?? `Save ${slotId.replace('slot', '')}`);

    db[key] = {
      schema: 2,
      gameVersion: '3.4.3',
      summary: buildAdultSummary(state, slotId, finalLabel, updatedAt),
      state,
    };

    writeDB(db);
  } catch (e) {
    console.error('Failed to save adult game', e);
  }
};

export const loadAdultGame = (slotId: SaveSlotId = 'autosave'): GameState | null => {
  migrateLegacyAdultSaveIfNeeded();

  try {
    const db = readDBRaw();
    const key = makeKey('adult', slotId);
    const entry = db[key];
    if (!entry) return null;
    return normalizeAdultState(entry.state as GameState);
  } catch (e) {
    console.error('Failed to load adult game', e);
    return null;
  }
};

export const saveKidsGame = (state: KidsGameState, slotId: SaveSlotId = 'autosave', label?: string): void => {
  try {
    const db = readDBRaw();
    const key = makeKey('kids', slotId);
    const updatedAt = Date.now();

    const existingLabel = db[key]?.summary?.label;
    const finalLabel = slotId === 'autosave' ? 'Autosave' : (label ?? existingLabel ?? `Save ${slotId.replace('slot', '')}`);

    db[key] = {
      schema: 2,
      gameVersion: '3.4.3',
      summary: buildKidsSummary(state, slotId, finalLabel, updatedAt),
      state,
    };

    writeDB(db);
  } catch (e) {
    console.error('Failed to save kids game', e);
  }
};

export const loadKidsGame = (slotId: SaveSlotId = 'autosave'): KidsGameState | null => {
  try {
    const db = readDBRaw();
    const key = makeKey('kids', slotId);
    const entry = db[key];
    if (!entry) return null;
    return entry.state as KidsGameState;
  } catch (e) {
    console.error('Failed to load kids game', e);
    return null;
  }
};

export const deleteSaveSlot = (mode: SaveMode, slotId: SaveSlotId): void => {
  try {
    const db = readDBRaw();
    const key = makeKey(mode, slotId);
    if (db[key]) {
      delete db[key];
      writeDB(db);
    }
  } catch (e) {
    console.error('Failed to delete save slot', e);
  }
};

export const renameSaveSlot = (mode: SaveMode, slotId: SaveSlotId, newLabel: string): void => {
  try {
    const db = readDBRaw();
    const key = makeKey(mode, slotId);
    const entry = db[key];
    if (!entry) return;

    entry.summary = { ...entry.summary, label: newLabel };
    db[key] = entry;
    writeDB(db);
  } catch (e) {
    console.error('Failed to rename save slot', e);
  }
};

export const getSaveSummaries = (mode?: SaveMode): SaveSummary[] => {
  migrateLegacyAdultSaveIfNeeded();

  const db = readDBRaw();
  const entries = Object.values(db)
    .map(e => e.summary)
    .filter(s => (mode ? s.mode === mode : true));

  // Provide a stable ordering for UI: mode then slot order, but keep updatedAt for easy "Continue".
  return entries.sort((a, b) => {
    if (a.mode !== b.mode) return a.mode.localeCompare(b.mode);
    return slotOrder.indexOf(a.slotId) - slotOrder.indexOf(b.slotId);
  });
};

export const getSaveSummary = (mode: SaveMode, slotId: SaveSlotId): SaveSummary | null => {
  migrateLegacyAdultSaveIfNeeded();

  try {
    const db = readDBRaw();
    const entry = db[makeKey(mode, slotId)];
    return entry?.summary || null;
  } catch {
    return null;
  }
};

export const getMostRecentSave = (mode?: SaveMode): SaveSummary | null => {
  const all = getSaveSummaries(mode);
  if (all.length === 0) return null;
  return all.reduce((latest, s) => (s.updatedAt > latest.updatedAt ? s : latest), all[0]);
};

export const hasAnySaves = (mode?: SaveMode): boolean => {
  return getSaveSummaries(mode).length > 0;
};

// ============================================
// Backward-compatible wrappers (legacy API)
// ============================================
export const saveGame = (state: GameState): void => saveAdultGame(state, 'autosave');
export const loadGame = (): GameState | null => loadAdultGame('autosave');
export const deleteSave = (): void => deleteSaveSlot('adult', 'autosave');

// ============================================
// Prestige
// ============================================
export const savePrestige = (prestige: PrestigeData): void => {
  try {
    localStorage.setItem(PRESTIGE_KEY, JSON.stringify(prestige));
  } catch (e) {
    console.error('Failed to save prestige', e);
  }
};

export const loadPrestige = (): PrestigeData | null => {
  try {
    const data = localStorage.getItem(PRESTIGE_KEY);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    console.error('Failed to load prestige', e);
    return null;
  }
};
